#!/usr/bin/env python3
"""Self-contained regression suite for the india-itr-tax skill.

Runs the engine (../scripts/build_return.py) OFFLINE against synthetic fixtures in
./cases and asserts the recommended ITR form, the cheaper regime, total income,
business income and net tax against hand-verified golden values. No network, no PII.

Usage:
    python run_selftests.py            # run all cases, print PASS/FAIL table
    python run_selftests.py -v         # also print the full bundle line per case

Exit code 0 = all passed, 1 = at least one failure (CI-friendly).
"""
import importlib.util
import json
import os
import shutil
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
ENGINE = os.path.join(SKILL, "scripts", "build_return.py")
VERIFY = os.path.join(SKILL, "scripts", "verify_against_portal.py")
CASES = os.path.join(HERE, "cases")
EXAMPLE = os.path.join(SKILL, "scripts", "inputs.example.json")
TMP = os.path.join(HERE, "_selftest_tmp")

# Golden expectations (hand-verified, senior-CA cross-checked). tol = +/- Rs.1 rounding.
#   file : (form, cheaper, total_income, net_tax, biz_income)
GOLDEN = {
    "case_itr1_simple.json":     ("ITR-1", "new", 1183000,      0,       0),
    "case_itr2_capgains.json":   ("ITR-2", "new", 2130000, 188630,       0),
    "case_itr2_foreign_fx.json": ("ITR-2", "new", 1739750, 139700,       0),
    "case_itr3_regular.json":    ("ITR-3", "new", 1800000, 166400, 1800000),
    "case_itr4_44ad.json":       ("ITR-4", "new", 1500000, 109200, 1500000),
    "case_itr4_44ada.json":      ("ITR-4", "new", 2000000, 208000, 2000000),
    "case_itr4_44ae.json":       ("ITR-4", "new",  405000,      0,  405000),
    "case_letout_hp.json":       ("ITR-1", "new", 1516000, 111700,       0),
}
TOL = 1


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_engine():
    return load_module("build_return", ENGINE)


def run_case(engine, path):
    b = engine.build(path, os.path.join(HERE, "_selftest_tmp"), offline=True, write=False)
    R = b["results"][b["cheaper"]]
    return {
        "form": b["itr_rec"]["form"],
        "cheaper": b["cheaper"],
        "total_income": R["total_income"],
        "net_tax": R["net_tax"],
        "biz_income": R.get("biz_income", 0),
        "conf": b["overall_conf"],
        "bundle": b,
    }


def check(name, got, exp):
    fails = []
    if got["form"] != exp[0]:
        fails.append(f"form {got['form']}!={exp[0]}")
    if got["cheaper"] != exp[1]:
        fails.append(f"regime {got['cheaper']}!={exp[1]}")
    if abs(got["total_income"] - exp[2]) > TOL:
        fails.append(f"TI {got['total_income']}!={exp[2]}")
    if abs(got["net_tax"] - exp[3]) > TOL:
        fails.append(f"net_tax {got['net_tax']}!={exp[3]}")
    if abs(got["biz_income"] - exp[4]) > TOL:
        fails.append(f"biz {got['biz_income']}!={exp[4]}")
    return fails


def check_perform_excel(engine):
    """The per-form workbook must lead with Filing_Guide, drop the verbose How-computed sheet,
    trim schedules a form cannot carry (ITR-1 no FA/FSI/Business; ITR-4 keeps Business),
    and apply the AY2026-27 Schedule AL threshold correctly (> Rs.1 crore, not > Rs.50L)."""
    import openpyxl
    os.makedirs(TMP, exist_ok=True)
    fails = []
    expect = {
        "case_itr1_simple.json":   (lambda s: not any(x.startswith("FA_") for x in s)
                                     and "FSI_TR_FTC" not in s and "Business" not in s),
        "case_itr2_capgains.json": (lambda s: "1_How_Computed" not in s and s[0] == "Filing_Guide"),
        "case_itr4_44ad.json":     (lambda s: "Business" in s and s[0] == "Filing_Guide"),
    }
    for name, ok_fn in expect.items():
        b = engine.build(os.path.join(CASES, name), os.path.join(TMP, "x"), offline=True, write=False)
        p = os.path.join(TMP, "form.xlsx")
        engine.write_form_excel(b, p)
        sheets = openpyxl.load_workbook(p).sheetnames
        if sheets[0] != "Filing_Guide":
            fails.append(f"{name}: first sheet {sheets[0]}")
        if not ok_fn(sheets):
            fails.append(f"{name}: sheet set {sheets}")
        if name == "case_itr2_capgains.json" and "Schedule_AL" in sheets:
            fails.append(f"{name}: Schedule_AL should not appear below Rs.1 crore")
        os.remove(p)
    high_income = json.load(open(os.path.join(CASES, "case_itr2_capgains.json"), encoding="utf-8"))
    high_income["salary"]["sec17_1"] = 12500000
    high_path = os.path.join(TMP, "case_itr2_schedule_al_high_income.json")
    with open(high_path, "w", encoding="utf-8") as f:
        json.dump(high_income, f)
    b = engine.build(high_path, os.path.join(TMP, "x"), offline=True, write=False)
    p = os.path.join(TMP, "form_al.xlsx")
    engine.write_form_excel(b, p)
    wb = openpyxl.load_workbook(p)
    sheets = wb.sheetnames
    if "Schedule_AL" not in sheets:
        fails.append("high-income ITR-2: Schedule_AL missing above Rs.1 crore")
    guide_values = [str(c.value) for row in wb["Filing_Guide"].iter_rows() for c in row if c.value is not None]
    if not any("Schedule AL" in v for v in guide_values):
        fails.append("high-income ITR-2: Filing_Guide missing Schedule AL row")
    os.remove(p)
    return fails


def check_verifier():
    """The portal verifier must parse the synthetic portal JSON, match the engine to the rupee,
    and never surface PersonalInfo (dummy name/PAN in the fixture must not appear anywhere)."""
    v = load_module("verify_against_portal", VERIFY)
    portal = os.path.join(CASES, "portal_itr2_capgains.json")
    inputs = os.path.join(CASES, "case_itr2_capgains.json")
    rows, form, regime, ay = v.verify(portal, inputs, offline=True)
    fails = []
    if form != "ITR-2":
        fails.append(f"form {form}")
    if regime != "new":
        fails.append(f"regime {regime}")
    ndiff = sum(1 for r in rows if r["status"].startswith("DIFF"))
    nmiss = sum(1 for r in rows if r["status"] == "NOT IN JSON")
    if ndiff or nmiss:
        fails.append(f"{ndiff} diff / {nmiss} missing")
    if len(rows) < 13:
        fails.append(f"only {len(rows)} figures reconciled")
    blob = repr(rows)
    if "AAAAA0000A" in blob or "USER" in blob:
        fails.append("PII leaked into report")
    return fails


def main():
    verbose = "-v" in sys.argv
    engine = load_engine()
    total = passed = 0
    print("=" * 96)
    print(f"  india-itr-tax self-test  |  engine: {os.path.relpath(ENGINE, SKILL)}  |  OFFLINE  |  synthetic data")
    print("=" * 96)
    print(f"  {'case':<28}{'form':<8}{'regime':<8}{'total income':>14}{'net tax':>12}{'biz inc':>12}  result")
    print("-" * 96)
    for name, exp in GOLDEN.items():
        total += 1
        path = os.path.join(CASES, name)
        try:
            got = run_case(engine, path)
        except Exception:
            print(f"  {name:<28}{'-':<8}{'-':<8}{'-':>14}{'-':>12}{'-':>12}  ERROR")
            traceback.print_exc()
            continue
        fails = check(name, got, exp)
        status = "PASS" if not fails else "FAIL: " + "; ".join(fails)
        if not fails:
            passed += 1
        print(f"  {name:<28}{got['form']:<8}{got['cheaper']:<8}"
              f"{got['total_income']:>14,}{got['net_tax']:>12,}{got['biz_income']:>12,}  {status}")
        if verbose:
            ir = got["bundle"]["itr_rec"]
            print(f"       reasons: {ir['reasons']}")

    # smoke test: the shipped example must run and resolve to ITR-2
    print("-" * 96)
    try:
        ex = run_case(engine, EXAMPLE)
        ok = ex["form"] == "ITR-2"
        total += 1
        passed += 1 if ok else 0
        print(f"  {'inputs.example.json (smoke)':<28}{ex['form']:<8}{ex['cheaper']:<8}"
              f"{ex['total_income']:>14,}{ex['net_tax']:>12,}{ex['biz_income']:>12,}  "
              f"{'PASS' if ok else 'FAIL: expected ITR-2'}")
    except Exception:
        total += 1
        print(f"  inputs.example.json (smoke)  ERROR")
        traceback.print_exc()

    # per-form Excel structure + portal verifier (both synthetic, offline)
    for label, fn in (("per-form Excel (ITR-1/2/4)", lambda: check_perform_excel(engine)),
                      ("verify vs portal JSON (synthetic)", check_verifier)):
        total += 1
        try:
            fails = fn()
            if not fails:
                passed += 1
            print(f"  {label:<40}{'PASS' if not fails else 'FAIL: ' + '; '.join(fails)}")
        except Exception:
            print(f"  {label:<40}ERROR")
            traceback.print_exc()

    shutil.rmtree(TMP, ignore_errors=True)
    print("=" * 96)
    print(f"  {passed}/{total} passed"
          + ("  -> ALL GREEN" if passed == total else "  -> FAILURES PRESENT"))
    print("=" * 96)
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
