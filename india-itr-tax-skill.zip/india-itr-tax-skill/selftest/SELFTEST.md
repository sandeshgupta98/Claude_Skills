# Self-test — battle-testing the india-itr-tax engine

A self-contained regression suite for `scripts/build_return.py`. **Synthetic data only, no PII, fully offline** (no network — FX is supplied inline via `ttbr`). It is the safety net that proves a change to the engine did not break any ITR form's computation.

## Run it

```bash
# from the skill root
python selftest/run_selftests.py        # PASS/FAIL table; exit 0 = all green, 1 = a failure
python selftest/run_selftests.py -v     # also prints the form-selection reasons per case
```

The runner imports the engine, calls `build(..., write=False)` on each fixture (so nothing is written to disk), and compares **recommended form · cheaper regime · total income · business income · net tax** against hand-verified golden values (tolerance ±₹1 for rounding). It then runs two extra checks — the **per-form Excel** structure and the **portal verifier** — for **11 checks total**; any temp workbook it writes is removed automatically.

## What each case proves

| Fixture | Proves |
|---|---|
| `cases/case_itr1_simple.json` | Salaried ROR, 1 house, savings interest, **LTCG 112A ≤ ₹1.25L** ⇒ stays **ITR-1**; 87A zeroes the tax. |
| `cases/case_itr2_capgains.json` | **STCG 111A + LTCG 112A > ₹1.25L** ⇒ escalates to **ITR-2**; 112A nil-band + 111A @20% + cess. |
| `cases/case_itr2_foreign_fx.json` | **Foreign-share sales in USD** via Rule 115(1)(f) (>24m ⇒ §112 12.5%; ≤24m ⇒ slab) ⇒ **ITR-2**. |
| `cases/case_itr3_regular.json` | **Regular business net profit** ⇒ **ITR-3**; slab tax in both regimes. |
| `cases/case_itr4_44ad.json` | **§44AD** 6% of digital turnover ⇒ **ITR-4**. |
| `cases/case_itr4_44ada.json` | **§44ADA** 50% of professional gross receipts ⇒ **ITR-4**. |
| `cases/case_itr4_44ae.json` | **§44AE** ₹1,000/ton/month (heavy) + ₹7,500/month (light), part-month = full month ⇒ **ITR-4**. |
| `cases/case_letout_hp.json` | **Let-out HP** (NAV − 30% − interest) + regime comparison; single HP ⇒ **ITR-1**. |
| `scripts/inputs.example.json` (smoke) | The shipped template runs end-to-end and resolves to **ITR-2** (foreign assets). |
| **per-form Excel** (ITR-1/2/4) | `write_form_excel` leads with **`Filing_Guide`**, drops `1_How_Computed`, trims schedules the form can't carry (ITR-1: no `FA_*`/`FSI_TR_FTC`/`Business`; ITR-4: keeps `Business`), and regression-tests **Schedule AL**: no AL below ₹1 crore; AL + Filing_Guide row above ₹1 crore. |
| **portal verifier** + `cases/portal_itr2_capgains.json` | `verify_against_portal.py` parses a **synthetic portal-export JSON** (real ITR-2 key paths), reconciles all 16 figures to the rupee, picks the filed regime, and **never surfaces the dummy name/PAN** in the report. |

## Golden values (hand-verified, senior-CA cross-checked)

| Case | Form | Regime | Total income | Net tax | Business income |
|---|---|---|--:|--:|--:|
| case_itr1_simple | ITR-1 | new | 11,83,000 | 0 | 0 |
| case_itr2_capgains | ITR-2 | new | 21,30,000 | 1,88,630 | 0 |
| case_itr2_foreign_fx | ITR-2 | new | 17,39,750 | 1,39,700 | 0 |
| case_itr3_regular | ITR-3 | new | 18,00,000 | 1,66,400 | 18,00,000 |
| case_itr4_44ad | ITR-4 | new | 15,00,000 | 1,09,200 | 15,00,000 |
| case_itr4_44ada | ITR-4 | new | 20,00,000 | 2,08,000 | 20,00,000 |
| case_itr4_44ae | ITR-4 | new | 4,05,000 | 0 | 4,05,000 |
| case_letout_hp | ITR-1 | new | 15,16,000 | 1,11,700 | 0 |

Worked check (44AD): turnover ₹2.5cr all-digital × 6% = ₹15,00,000 → new-regime slab 20k+40k+45k = ₹1,05,000 (>₹12L so no 87A) + 4% cess = **₹1,09,200**.

## Refresh the goldens each year

When the Budget changes slabs / rates / limits:
1. Run the **annual web-search protocol** in `SKILL.md` and update `regime_overrides` / rate fields.
2. Re-run `python selftest/run_selftests.py` — cases will FAIL with the *actual* vs *old* numbers.
3. Re-verify the new figures by hand (the math is in `SKILL.md`), then update the `GOLDEN` dict in `run_selftests.py` to the new expected values.
4. Keep all checks green before filing.

> Synthetic only: every number here is invented for testing. No taxpayer data is in this folder.
