---
name: india-itr-tax
description: >-
  Prepare and compute an India ITR-2 income-tax return end to end — Salary,
  Capital Gains (LTCG 112A), Other Sources, and Schedule FA (Foreign Assets:
  foreign shares/RSU/ESPP via overseas share-plan or custodial accounts). Computes
  initial/peak/closing foreign-asset values and foreign dividend using exact SBI
  TT-buying rates (Rule 115) and daily stock prices, computes tax under BOTH new
  and old regimes, and emits an Excel workbook (all schedules) + a markdown that
  explains every figure. Use when someone mentions an Indian income-tax return,
  ITR-2, Schedule FA / foreign assets, RSU/ESPP disclosure, SBI TTBR conversion,
  LTCG 112A, or new-vs-old regime comparison.
---

# India ITR-2 + Schedule FA — Tax Computation Skill

Builds an audit-ready India ITR-2 working paper for a salaried individual who also has
capital gains, other-sources income, and/or **foreign assets** (foreign shares, RSUs, ESPP
held via an overseas share-plan/custodial account such as a UK/US broker). It computes
every schedule, compares **both tax regimes**, and produces an **Excel + markdown** at the end.

**This is a disclosure-and-computation aid, not tax advice.** Foreign-asset non-disclosure
carries Black Money Act consequences — always have a practising CA sign off, and re-verify
every figure in the live ITR e-filing utility before submitting.

---

## Documents you need (collect these first)

| Document | Where from | Gives you |
|---|---|---|
| **Form 16 (Part A + B)** | employer | salary 17(1), perquisites 17(2), standard deduction, regime opted, salary TDS |
| **Form 12BA** | employer | perquisite break-up — **check the ESOP/RSU rows**; if 0, nothing vested this year |
| **Form 26AS** | TRACES / e-filing portal | total TDS (salary + non-salary), TCS on foreign remittance (LRS) |
| **AIS (Annual Information Statement)** | e-filing portal | savings-bank interest (SFT-016), MF/equity sale & purchase (SFT-18), other income |
| **Broker / MF capital-gains report** | broker (e.g. consolidated tax P&L) | LTCG/STCG, F&O, intraday, dividends, interest |
| **Foreign share-plan portfolio export** | share-plan provider | every lot: grant/purchase date, units, cost; which RSUs are **unvested** |
| **Foreign transactions export** | share-plan provider | proves whether there were **sales** (→ capital gains) or only dividend reinvestments |
| **Dividend vouchers** | share-plan provider / registrar | gross dividend, **withholding tax**, payment date, reinvested? |
| **Bank interest certificates** (optional) | banks | cross-check savings/FD interest |

> If F&O or intraday turnover is non-zero, the return becomes **ITR-3** (business income) — out of scope here; this skill targets **ITR-2**.

---

## The method (what the engine encodes)

### 1. Two periods — never mix them
- **Schedule FA** (foreign-asset disclosure) = **Calendar Year** (01-Jan → 31-Dec) ending in the FY.
- **Income** (salary, dividend, capital gains) = **Financial Year** (01-Apr → 31-Mar).
- A dividend paid Jan–Mar falls in a different CY and FY → the FA dividend total and the OS dividend total then differ. **If every dividend is paid Apr–Dec, the two coincide** — don't manufacture a difference.

### 2. FX = SBI TT-BUYING rate (Rule 115 / Explanation to Rule 26)
Use the **exact published daily** SBI TT-buy rate for the relevant date; if SBI didn't publish that day (Sunday/holiday), fall back to the most recent prior working day.
- **Initial value** → acquisition date · **Closing value** → 31-Dec · **Peak value** → the peak-*value* day.
- **Dividend** → Rule 115: the **last day of the month immediately preceding the month of payment** (e.g. dividend paid 24-Sep → use 31-Aug → prior working day if a holiday). Use the same figure in both Schedule FA and Schedule OS.

### 3. Foreign-equity valuations
- **Initial** = Σ(units × cost/share in foreign currency) × TTBR on each lot's acquisition date.
- **Closing** = total units × stock close on 31-Dec × TTBR on 31-Dec.
- **Peak** = a **daily scan**: for every trading day in the calendar year compute `units held that day × intraday HIGH × TTBR that day`, take the maximum. **The peak-VALUE day is usually NOT the peak-PRICE day** — a weaker rupee can make a lower-price day the peak. Compute the **account-level (A2)** peak the same way over the whole holding.
- Report **per-lot A3 rows** (each acquisition = one row with its own date/initial/peak/closing). Aggregating into one row is widely called defective.
- **Unvested RSUs / matching shares are NOT reported** — a contingent promise, not owned property (they usually pay no dividend either). Report each only after it vests.
- Report **both** Table **A3** (the equity) **and** Table **A2** (the custodial/share-plan account that holds it).

### 4. Foreign dividend is taxable — even when reinvested
A resident (ROR) is taxed on **global income**. A reinvested (DRIP) dividend is two events: (a) income **received** → taxable under **Other Sources** at slab on the **gross** amount (constructive receipt — taxable even though no cash reached the bank), and (b) cash **used to buy shares** → a fresh acquisition (new FA lots). It will **not** appear in AIS (foreign payers don't report to the ITD) → **enter it manually**; this creates no mismatch. **FSI/TR/Form 67 are needed only to claim a foreign-tax credit** — if withholding tax is 0 (e.g. UK dividends), none are required; if there is WHT (e.g. US 25%), file Form 67 before the return.

### 5. Capital gains — LTCG u/s 112A
Listed-equity / equity-MF LTCG (STT paid) is exempt up to the 112A cap (₹1,25,000 from FY2024-25) and taxed at 12.5% above it. **Even a fully-exempt gain MUST be reported** — AIS shows the redemption (SFT-18); omitting it triggers a mismatch notice. Answer the "acquired on/before 31-01-2018?" grandfathering question per lot.

### 6. Tax computation (both regimes)
- **New regime (FY2025-26 default):** slabs 0-4L (0), 4-8L (5%), 8-12L (10%), 12-16L (15%), 16-20L (20%), 20-24L (25%), >24L (30%); standard deduction ₹75,000; rebate 87A up to ₹12L income; surcharge 10% (50L-1cr) / 15% (1-2cr) / 25% (>2cr); cess 4%.
- **Old regime:** 0-2.5L (0), 2.5-5L (5%), 5-10L (20%), >10L (30%); std deduction ₹50,000; 87A up to ₹5L; Chapter VI-A deductions (80C/80D/…) allowed; surcharge up to 37%; cess 4%.
- **Surcharge marginal relief** is applied automatically: tax+surcharge cannot exceed `tax at the threshold + (income − threshold)`.
- Special-rate income (112A LTCG, 111A STCG) is taxed at its own rate and excluded from the slab base.
- Pay any balance via **Challan 280 (minor head 300, self-assessment)** before filing so the return shows zero balance (the utility adds small 234B/234C interest).

### 7. Other rules baked in
- **Schedule AL** (assets & liabilities) is required only when **total income > ₹1 crore** (raised from ₹50L for AY 2025-26 onward — verify on the live form each year).
- **Country code = the ITR code**, not always the ISD code: e.g. United Kingdom = 44, USA = 2 (not "1"), Others = 9999 — confirm from the current ITR schema.
- Eligibility: Schedule FA is mandatory only for **Resident & Ordinarily Resident (ROR)**; NR/RNOR skip it.

---

## How to run

1. **Install the one dependency:** `pip install openpyxl` (auto-fetch uses only the Python standard library).
2. **Copy `scripts/inputs.example.json` to `inputs.json`** and fill it with your own figures (see the inline comments; delete the `_comment` keys or leave them — the engine ignores any key starting with `_`).
3. **Generate the return:**
   ```bash
   python scripts/build_return.py inputs.json --out MyReturn
   # add --offline to skip the internet and use only the manual_fx / manual_close / manual_high you provided
   ```
4. **Outputs:**
   - `MyReturn.xlsx` — one sheet per schedule (Summary, Salary, Schedule_OS, Schedule_CG_112A, FA_A3_Equity, FA_A2_Account, FA_Dividends_Rule115, any other FA tables you supplied, Tax_Both_Regimes).
   - `MyReturn.md` — every figure explained, with the new-vs-old regime comparison and the cheaper regime flagged.
5. **File:** use the figures to fill ITR-2 on the portal (or the offline utility — recommended for Schedule FA, which has an Excel-import path). Re-tick everything; pay self-assessment tax; submit **and e-verify**.

### Auto-fetched data sources (override-able)
- **SBI TT-buy rates:** `github.com/sahilgupta/sbi-fx-ratekeeper` (a mirror of the official SBI FOREX CARD RATE PDFs), via the GitHub API (proxy-safe). TT BUY is CSV column index 2; multiple intraday rows per day → take the last.
- **Daily stock prices:** the Yahoo Finance chart API (`interval=1d`), intraday high + close. `price_unit: "pence"` divides by 100.
- Any rate/price you put in `manual_fx` / `manual_close` / `manual_high` overrides the fetch, and `--offline` relies on them entirely. **Keep the official SBI rate PDFs as evidence** beside your return.

---

## Verification discipline (if asked to re-check a prepared return)

- **Verify, don't re-state.** Re-derive every figure from the source documents independently, then compare. (`openpyxl data_only=True` returns `None` for un-recalculated formula cells — recompute, don't trust cached values.)
- **Dual-source the FX** (local SBI PDFs + the GitHub mirror). Two agreeing authoritative sources is enough — don't burn time chasing more.
- **The peak-VALUE-≠-peak-PRICE check is the #1 real error to look for.** Run the full daily scan; re-scan the account-level peak across late-year lots too.
- **Confirm the tax YEAR's rules** (slabs change year to year) and test **surcharge marginal relief** at each threshold even if it doesn't bind.
- **Re-running this engine against the real data and reproducing the workbook to the rupee is the strongest cross-check.**
- **Rank discrepancies by ₹ materiality.** Don't flag immaterial rounding as an error; don't highlight correct values just to look thorough.

---

## Files in this skill
- `SKILL.md` — this file.
- `scripts/build_return.py` — the computation engine (Excel + markdown generator).
- `scripts/inputs.example.json` — generic, dummy-data template (runs offline out of the box).

## Re-google every year
Slabs, surcharge bands, the 112A cap, the Schedule AL threshold, country codes and the FA layout all change. Re-verify against the **current-year** official ITR utility and CBDT guidance — blogs are direction, not authority.
