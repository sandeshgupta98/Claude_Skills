---
name: india-itr-tax
description: >-
  Prepare and compute an India income-tax return end to end and pick the correct form —
  it recommends ITR-1 / ITR-2 / ITR-3 / ITR-4 from the CBDT-notified eligibility, then
  computes Salary (incl. ESOP/RSU perquisite and leave encashment §10(10AA)), House
  Property, Capital Gains (LTCG 112A, STCG 111A, LTCG 112, and foreign shares via
  INDmoney/Interactive Brokers/EquatePlus → LTCG §112 / STCG slab), Other Sources,
  Schedule FA (Foreign Assets), and the Foreign Tax Credit (DTAA, Form 67, Schedule
  FSI/TR). Computes initial/peak/closing foreign-asset values and foreign dividend using
  exact SBI TT-buying rates (Rule 115, incl. 115(1)(f) for capital gains) and daily stock
  prices, computes tax under BOTH new and old regimes (15% surcharge cap on capital
  gains/dividends, surcharge & 87A marginal relief), emits a per-schedule + overall
  confidence %, and writes an Excel workbook (all schedules + a "how computed" sheet +
  ITR-form selection + Confidence) plus a markdown that explains every figure and lists
  the official rules to re-verify each year. Use when someone mentions an Indian
  income-tax return, ITR-1/2/3/4 (which form to file), Sahaj/Sugam, Schedule FA / foreign
  assets, RSU/ESOP/ESPP, US equity (INDmoney/IBKR), SBI TTBR conversion, LTCG 112A / STCG
  111A, leave encashment, DTAA / foreign tax credit / Form 67, or new-vs-old regime comparison.
---

# India ITR (1 / 2 / 3 / 4) + Schedule FA — Tax Computation Skill

Builds an audit-ready India income-tax working paper for an individual. It **first decides
the correct form** — **ITR-1 (Sahaj), ITR-2, ITR-3, or ITR-4 (Sugam)** — from the
CBDT-notified eligibility, then computes every applicable schedule: Salary, House Property,
Capital Gains, Other Sources, and (for ITR-2/3) **foreign assets** (foreign shares, RSUs,
ESPP held via an overseas share-plan/custodial account such as a UK/US broker) and the
Foreign Tax Credit. It compares **both tax regimes** and produces an **Excel + markdown**
that explains how each figure was derived. A simple salaried return resolves to **ITR-1**;
the moment there is foreign-asset, capital-gains-beyond-112A, business, or DTAA exposure it
escalates to **ITR-2/3/4** and tells you why.

**This is a disclosure-and-computation aid, not tax advice.** Foreign-asset non-disclosure
carries Black Money Act consequences — always have a practising CA sign off, and re-verify
every figure in the live ITR e-filing utility before submitting.

---

## Next year: file in 5 steps (just gather the documents)

1. **Drop the documents** (list below) into one folder.
2. **Copy `scripts/inputs.example.json` → `inputs.json`** and transcribe the figures (the
   inline `_comment` keys say exactly where each number comes from). Don't invent anything.
3. **Run** `python scripts/build_return.py inputs.json --out MyReturn` (add `--offline` if
   you'll paste the SBI rates / prices yourself).
4. **File** from `MyReturn.<FORM>.xlsx` → **`Filing_Guide`** sheet (it lists every value in
   portal-navigation order, mapped to its schedule/field). Enter them in the ITR utility, pay any
   self-assessment balance via Challan 280, submit **and e-verify**.
5. **Verify**: at the portal's final stage **Download JSON**, then run
   `python scripts/verify_against_portal.py --portal <downloaded>.json --inputs inputs.json --offline`
   and reconcile any DIFF before submitting. (The skill never makes an *upload* JSON — the portal
   rejects external files; you only ever download from it to cross-check.)

That's it — the engine does FX conversion, the peak-value scan, both regimes, surcharge/87A
relief, and the explanations. Your only job is accurate transcription + a CA sign-off.

---

## Documents you need (collect these first)

| Document | Where from | Gives you |
|---|---|---|
| **Form 16 (Part A + B)** | employer | salary 17(1), perquisites 17(2), standard deduction, regime opted, salary TDS |
| **Form 12BA** | employer | perquisite break-up — **check the ESOP/RSU rows**; if 0, nothing vested this year |
| **Form 26AS** | TRACES / e-filing portal | total TDS (salary + non-salary), TCS on foreign remittance (LRS) |
| **AIS (Annual Information Statement)** | e-filing portal | savings interest (SFT-016), MF/equity sale & purchase (SFT-18), Indian dividends, other income |
| **Broker / MF capital-gains report** | broker (consolidated tax P&L) | LTCG 112A, STCG 111A, other CG, dividends, interest |
| **Home-loan interest certificate** (if any) | lender | house-property interest (self-occupied → old-regime only; let-out → both) |
| **Foreign share-plan portfolio export** | share-plan provider (EquatePlus, E*TRADE, Computershare) | every lot: grant/purchase date, units, cost; which RSUs are **unvested** |
| **US-broker statements & realised-gains report** | INDmoney / Interactive Brokers (IBKR) / Vested / Groww | US share buys & sells, realised P&L (often already in INR), dividends, fees |
| **Form 1042-S** (US dividends) | US broker | gross US dividend + **US withholding tax** (25% with W-8BEN) → drives the Foreign Tax Credit |
| **Foreign transactions export** | share-plan / broker | proves whether there were **sales** (→ capital gains) or only dividend reinvestments |
| **Dividend vouchers** | share-plan provider / registrar | gross dividend, **withholding tax**, payment date, reinvested? |
| **Leave-encashment statement** (if you changed jobs / retired) | employer | amount paid + unutilised leave days + avg salary → §10(10AA) exemption |
| **Business turnover / receipts summary** (presumptive) | your books / bank | §44AD turnover (digital vs cash split), §44ADA professional gross receipts, §44AE vehicle list (tonnage + months owned) → ITR-4 |
| **Profit & Loss account** (regular business) | your books / accountant | net profit, partner remuneration/interest, F&O/speculative P&L → ITR-3 |
| **Bank interest certificates** (optional) | banks | cross-check savings/FD interest |

> The engine reads your data + the `business` block / `profile` flags and **recommends the form** (next section). It now **computes business/profession income** too: **presumptive §44AD/44ADA/44AE** (→ ITR-4) and **regular net profit** (→ ITR-3), folded into both regimes. The detailed P&L / Balance-Sheet *schedules* of ITR-3 are still filled in the ITR utility — but the taxable figure is computed here. For ITR-4 add the **business statement** (turnover / gross receipts / vehicle list); for ITR-3 add the **P&L net profit** (and any partner remuneration/interest, F&O/speculative income).

---

## Which ITR form to file — ITR-1 / 2 / 3 / 4 (decided automatically)

The engine recommends the form from the **CBDT-notified AY2026-27 eligibility** (Notification **45/2026**, 30-Mar-2026) and prints it in the Summary, the `ITR_Form` Excel sheet, and the markdown — with the **reasons**. Verify the current-AY notification each year (the limits below changed for AY2025-26 and again for AY2026-27).

| Form | Who can use it (AY2026-27) | Hard limits / triggers |
|---|---|---|
| **ITR-1 (Sahaj)** | **Resident & ordinarily resident** individual: Salary/pension + **up to 2 house properties** + Other Sources + **LTCG §112A ≤ ₹1.25 lakh** + agri ≤ ₹5,000 | Total income **≤ ₹50 lakh**; **no** other capital gains (no STCG, no §112, no foreign, no 112A > ₹1.25L) and **no capital loss**; not a director; no unlisted shares; **no foreign asset/income**; not claiming DTAA relief; no VDA; no ESOP tax deferral; no TDS u/s 194N |
| **ITR-2** | Individual / HUF with **no business income** | Use when you have **capital gains** (beyond the ITR-1 112A carve-out), **foreign assets/income**, **DTAA/FTC** (§90/90A), total income **> ₹50L**, more than 2 house properties, director, unlisted shares, VDA, or **RNOR/NRI** |
| **ITR-3** | Individual / HUF with **business or profession** income (non-presumptive), **F&O / intraday**, or **partner in a firm** | Books/audit as applicable; also where you have business income **plus** any ITR-4 disqualifier |
| **ITR-4 (Sugam)** | **Resident** with **presumptive** business/profession **§44AD / 44ADA / 44AE** | Total income **≤ ₹50 lakh**; LTCG §112A **≤ ₹1.25L** only; same director/unlisted/foreign-asset/agri>₹5,000 exclusions as ITR-1 |

**Key AY2025-26+ change baked in:** ITR-1 and ITR-4 now allow **LTCG §112A up to ₹1.25 lakh** (previously any capital gain forced ITR-2). The instant the gain exceeds ₹1.25L, or there's **any** STCG / §112 / foreign-share gain / capital loss, it's **ITR-2**. **Holding foreign assets (Schedule FA) or claiming a foreign tax credit always forces ITR-2** — this is why a salaried person with RSUs abroad cannot use ITR-1.

**Regime opt-out:** the new regime is the default. **ITR-1/ITR-2** filers opt for the **old** regime by ticking it **inside the ITR** — *no Form 10-IEA*. Only **ITR-3/ITR-4** filers (business income) must file **Form 10-IEA** before the §139(1) due date to use the old regime (official: Income-Tax Dept "New vs Old Regime" FAQ; Rule 21AGA).

Set the things the engine can't infer in the `profile` block of `inputs.json` (`director_in_company`, `holds_unlisted_shares`, `residential_status`, `agricultural_income`, `capital_loss_carry`, `has_vda_income`, `esop_tax_deferred`, `tds_194n`). **Filling the `business` block (next section) auto-sets the business flags** — `type: 44ad/44ada/44ae` ⇒ presumptive ⇒ **ITR-4**; `type: regular` ⇒ **ITR-3** — so you don't also need `has_business_income`/`presumptive_44ad_44ada_44ae` (they remain as manual overrides). Foreign assets, capital-gains type, house-property count, and total income are detected from your figures.

---

## The method (what the engine encodes)

### 1. Two periods — never mix them
- **Schedule FA** (foreign-asset disclosure) = **Calendar Year** (01-Jan → 31-Dec) ending in the FY.
- **Income** (salary, dividend, capital gains) = **Financial Year** (01-Apr → 31-Mar).
- A dividend paid **Jan–Mar** falls in a different CY and FY → the engine reports the FA dividend total (calendar-year) and the OS dividend total (financial-year) **separately**. If every dividend is paid Apr–Dec, the two coincide — the engine won't manufacture a difference.

### 2. FX = SBI TT-BUYING rate (Rule 115 / Explanation to Rule 26)
Use the **exact published daily** SBI TT-buy rate for the relevant date; if SBI didn't publish that day (Sunday/holiday), fall back to the most recent prior working day.
- **Initial value** → acquisition date · **Closing value** → 31-Dec · **Peak value** → the peak-*value* day.
- **Dividend** → Rule 115: the **last day of the month immediately preceding the month of payment** (e.g. dividend paid 24-Sep → use 31-Aug → prior working day if a holiday).
- **Do not use broker/EquatePlus INR values** for Schedule FA. Share-plan portals often display an indicative INR value using their own FX rate; that is evidence, not the ITR conversion. For filing, recompute from foreign-currency units/prices × SBI TT-buy on the statutory date.

### 3. Foreign-equity valuations
- **Initial** = Σ(units × cost/share in foreign currency) × TTBR on each lot's acquisition date.
- **Closing** = total units × stock close on 31-Dec × TTBR on 31-Dec.
- **Peak** = a **daily scan**: for every trading day in the calendar year compute `units held that day × intraday HIGH × TTBR that day`, take the maximum. **The peak-VALUE day is usually NOT the peak-PRICE day** — a weaker rupee can make a lower-price day the peak. The **account-level (A2)** peak is scanned the same way over the whole holding.
- Report **per-lot A3 rows** (each acquisition = one row). Aggregating into one row is widely called defective.
- **Unvested RSUs / matching shares are NOT reported** — a contingent promise, not owned property (they usually pay no dividend either). Report each only after it vests.
- Report **both** Table **A3** (the equity) **and** Table **A2** (the custodial/share-plan account that holds it).

### 4. Foreign dividend is taxable — even when reinvested
A resident (ROR) is taxed on **global income**. A reinvested (DRIP) dividend is two events: (a) income **received** → taxable under **Other Sources** at slab on the **gross** amount (constructive receipt — taxable even though no cash reached the bank), and (b) cash **used to buy shares** → a fresh acquisition (new FA lots). It will **not** appear in AIS (foreign payers don't report to the ITD) → **enter it manually**; this creates no mismatch. **FSI/TR/Form 67 are needed only to claim a foreign-tax credit** — if withholding tax is 0 (e.g. UK dividends), none are required; if there is WHT (e.g. US 25%), file Form 67 before the return.

### 5. Capital gains
- **LTCG u/s 112A** (listed Indian equity / equity-MF, STT paid): the **full gain is included in total income**; the first **₹1,25,000** is a **nil-rate band (not a deduction from total income)**; the balance is taxed at **12.5%**. **Even a fully-exempt gain MUST be reported** — AIS shows the redemption (SFT-18). Answer the "acquired on/before 31-01-2018?" grandfathering question per lot.
- **STCG u/s 111A** (same Indian assets, held ≤ 12 months): **20%** (raised from 15% **w.e.f. 23-Jul-2024**).
- **LTCG u/s 112** (other assets): **12.5% without indexation** (post 23-Jul-2024).
- **Foreign shares (US/UK) are NOT 112A/111A.** They are **unlisted** from India's view (no Indian STT). Held **> 24 months → LTCG u/s 112 @ 12.5%** without indexation and with **no ₹1.25L exemption**; held **≤ 24 months → STCG at your SLAB rate** (the engine adds it to normal income, NOT the 20% 111A rate). Convert sale/cost/expenses to INR per **Rule 115(1)(f)** (SBI TT-buy, last day of the month before the sale). Report in **Schedule CG** under *unlisted shares*. Capital **losses** need separate carry-forward (Schedule CFL) — the engine taxes only positive net gains and flags the rest.

### 5a. Leave encashment — §10(10AA)
- **Government employee:** fully exempt.
- **Non-government, on retirement/resignation:** exempt = **least of** (a) **₹25,00,000** lifetime cap *less* any §10(10AA) exemption used in earlier years (CBDT **Notification 31/2023**, w.e.f. 01-04-2023), (b) actual encashment, (c) **10 × average monthly salary** (basic + DA + commission), (d) **cash-equivalent of unutilised leave** (max **30 days/year** × completed years).
- **During service** (not on exit): **fully taxable**. The exemption is available under **both** regimes. Put the total in `salary.leave_encashment` (it must also sit inside `sec17_1`); the engine subtracts only the exempt part.

### 5b. ESOP / RSU / ESPP — two taxable stages
- **Stage 1 — vesting (RSU) / exercise (ESOP):** perquisite u/s **17(2)(vi)** = FMV (RSU: full FMV; ESOP: FMV − exercise price) × shares, taxed as **salary**; the employer deducts TDS and it shows in **Form 12BA** (already inside `sec17_2` — don't add it again).
- **Stage 2 — sale:** capital gain = sale price − **cost = the FMV taxed at vesting** (**§49(2AA)**, prevents double taxation); the **holding period runs from the vest/exercise date**. Foreign-employer shares then follow §5 foreign-share rules (>24m §112 / ≤24m slab); Indian listed shares follow 112A/111A.
- **Schedule ESOP (deferral)** applies **only** to employees of DPIIT-recognised **eligible start-ups (§80-IAC)** who deferred the perquisite tax — see the "schedules to file vs remove" table. Normal RSUs/ESPP do **not** use it.

### 5c. US equity via INDmoney / Interactive Brokers
- The shares (e.g. AAPL, MSFT) → **Schedule FA Table A3**; the **broker/custodial account** (IBKR LLC, or INDmoney's US custodian e.g. DriveWealth) → **Schedule FA Table A2**. Country = **United States (code 2)**, currency **USD**.
- **Sales** → §5 foreign-share capital gains (most India-facing brokers' realised-gains reports already give the INR gain per Rule 115 — feed it into `foreign_capital_gains`).
- **Dividends** → Schedule OS (gross), **US WHT 25%** → claim the Foreign Tax Credit (§5d).

### 5d. Foreign Tax Credit (DTAA) — when foreign tax was withheld
- **US dividends** are withheld at **25%** when you've filed a **W-8BEN** (India-US DTAA **Article 10**; 30% without). Include the **gross** dividend in Indian income, then claim a credit under **§90 + Rule 128** = the **lower of** the foreign tax paid and the **Indian tax on that income** (average-rate method).
- You **must e-file Form 67** *before/with* the return (outer limit: **end of the AY**, Rule 128(9)). Report **Schedule FSI** (foreign income + tax) and **Schedule TR** (relief). Convert the foreign tax to INR with the SBI TT-buy rate on the last day of the month **before** payment (Rule 128).
- The engine auto-counts dividend WHT (`wht_fx`) and any `foreign_capital_gains.foreign_tax_inr`; add anything else via `foreign_tax_credit`. Excess foreign tax above the Indian tax on that income is **not** refundable.

### 5e. Business / profession income — ITR-3 (regular) and ITR-4 (presumptive)
Set `business.type` in `inputs.json`. The computed income is added to **normal slab income in BOTH regimes** (it is **not** special-rate). Presumptive figures are the **statutory minimum** — you may always declare higher via `declared_income`.

- **§44AD — small business (→ ITR-4).** Resident individual/HUF/firm (not LLP), eligible business (**not** a profession, **not** goods transport u/s 44AE, **not** agency/commission/brokerage). Income = **6% of digital turnover + 8% of cash turnover** (or higher declared). Turnover limit **₹2 crore**, raised to **₹3 crore** if cash receipts ≤ 5% of turnover. **5-year lock-in.** Declaring below 6%/8% (with total income above the basic exemption) ⇒ tax audit u/s 44AB + **ITR-3**.
- **§44ADA — specified profession (→ ITR-4).** Professions u/s 44AA(1): legal, medical, engineering, architecture, accountancy, technical consultancy, interior decoration, plus notified IT / film artists / company secretary. Income = **50% of gross receipts** (or higher declared). Limit **₹50 lakh**, raised to **₹75 lakh** if cash receipts ≤ 5%. Declaring below 50% (income above basic exemption) ⇒ audit u/s 44AB(d) + **ITR-3**.
- **§44AE — goods carriage (→ ITR-4).** Owner of **≤ 10** goods vehicles. Per vehicle per month (or **part of a month = full month**): **₹1,000 × tonnage** if gross vehicle weight **> 12 tonnes**, else **₹7,500** flat. No expense deduction.
- **Regular business / profession (→ ITR-3).** `business.type: regular` — supply the **net profit** from your P&L (after expenses), plus any **partner remuneration/interest** from a firm and **speculative/F&O** income. The engine taxes the net figure; the ITR-3 P&L/Balance-Sheet schedules are completed in the utility.
- **Losses:** a business **loss** cannot be set off against salary (§71(2A)) and needs Schedule **BFLA/CFL** — out of scope; the engine clamps the slab base at ≥ 0 and notes it. Old-regime opt-out for business filers needs **Form 10-IEA** before the due date (see form-selection section).

### 6. Tax computation (both regimes)
- **New regime (FY2025-26 default):** slabs 0-4L (0), 4-8L (5%), 8-12L (10%), 12-16L (15%), 16-20L (20%), 20-24L (25%), >24L (30%); standard deduction ₹75,000.
- **Old regime:** 0-2.5L (0), 2.5-5L (5%), 5-10L (20%), >10L (30%); std deduction ₹50,000; Chapter VI-A deductions (80C/80D/…) allowed.
- **§87A rebate** — *new*: up to **₹60,000** if total income ≤ **₹12,00,000**, with **12L→~12.75L marginal relief**; *old*: up to ₹12,500 if income ≤ ₹5L. **Not available against special-rate (112A/111A/112) tax.**
- **Surcharge** by total-income band (10% 50L-1cr, 15% 1-2cr, 25% >2cr; old regime adds 37% >5cr) with **marginal relief** at each threshold. **Surcharge on 111A/112/112A capital gains AND dividend income is capped at 15%** even above ₹2cr; the new regime's overall max surcharge is **25%**.
- **Cess** 4% on (tax + surcharge).
- Pay any balance via **Challan 280 (minor head 300, self-assessment)** before filing; the engine prints an indicative **234B** estimate (the live utility computes the exact 234B/234C).

### 7. House Property
- **Self-occupied:** annual value 0; home-loan interest is deductible **up to ₹2,00,000 only in the OLD regime** (NEW regime: nil). A self-occupied nil property is still disclosed.
- **Let-out:** (rent − municipal taxes) − 30% standard deduction − loan interest.
- **Set-off:** OLD regime caps an HP loss set off against other heads at ₹2,00,000; **NEW regime does not allow an HP loss to be set off against other heads at all**.

### 8. Other rules baked in
- **Schedule AL** (assets & liabilities) is required for AY2026-27 only when **total income > ₹1 crore** (Notification **46/2026**, ITR-2). Older portal help / old ITR-2 instructions may still say ₹50 lakh — verify the **current AY notified form or schema** each year.
- **Country code = the ITR code**, not the ISD code: e.g. United Kingdom = 44, USA = 2, Others = 9999 — confirm from the current ITR schema.
- Eligibility: Schedule FA is mandatory only for **Resident & Ordinarily Resident (ROR)**; NR/RNOR skip it.

### 9. Confidence scoring
The engine prints a **per-schedule confidence %** and an **overall %** (the lowest schedule = the weakest link) in both the Excel `Confidence` sheet and the markdown. Defaults are a preparer self-assessment (**Salary 100, House Property 99, Business/Profession 99, Schedule OS 99, CG-domestic 99, Foreign CG 98, Schedule FA 99, FTC/DTAA 97, ITR form selection 99, Tax computation 99**) — **override any value via the `confidence` map** in your inputs after your own review. Read them as: **≥95% file · 90–94% re-check the flagged input · <90% get a CA sign-off.**

**Why it isn't a flat 100% (by design, and honest):** every computation rule is grounded in the statute/CBDT source (see the references table), so the engine is at/near 100 on the *math*. The residual reflects three things it **cannot** know in advance: (1) whether the **current-year** rates/limits changed — run the annual web-search protocol and override; (2) the **exact interest u/s 234A/B/C**, which depends on your real payment dates (the engine shows a 234B *estimate* — the live utility computes the exact figure); (3) for FTC, that **Form 67 is actually filed in time** and the DTAA article is read correctly. Close those three for your year and each applicable schedule sits at its stated %. Accurate transcription from your documents is assumed — garbage in, garbage out.

---

## Which schedules to FILE vs REMOVE (common ITR-2 mistakes)

| Schedule | File it when… | Remove / leave blank when… |
|---|---|---|
| **Schedule S (Salary)** | always (if salaried) | — |
| **Schedule HP** | you own property (self-occupied **nil** is still disclosed) | you own none |
| **Schedule CG + 112A** | any equity/MF sale — **even if the gain is fully exempt** (AIS shows it) | no transfers at all |
| **Schedule OS** | any interest/dividend/other income | none |
| **Schedule FA** | ROR with any foreign asset in the calendar year | NR/RNOR, or no foreign asset |
| **Schedule ESOP (deferred tax, §80-IAC)** | **only** if your employer is a DPIIT-recognised **eligible start-up** and you deferred the perquisite tax | **almost everyone else — REMOVE it.** A normal RSU/ESPP perquisite from a listed multinational is **not** §80-IAC; a stray ESOP-deferral schedule with dummy data will block or flag the return. |
| **Schedule AL** | AY2026-27: total income > ₹1 crore | total income ≤ ₹1 crore |
| **Schedule FSI / TR / Form 67** | you're claiming **foreign tax credit** (WHT was deducted abroad) | foreign WHT = 0 (e.g. UK dividends) |
| **Schedule TDS** | always reconcile to 26AS | — |

> **The §80-IAC ESOP-deferral trap:** that schedule exists only for employees of DPIIT-recognised eligible start-ups who *deferred* the tax on the ESOP perquisite. If you just received RSUs/ESPP from a normal (esp. listed/foreign) employer, you do **not** use it — delete any ESOP-deferral rows before filing.

---

## How to run

1. **Install the one dependency:** `pip install openpyxl` (auto-fetch uses only the Python standard library).
2. **Copy `scripts/inputs.example.json` to `inputs.json`** and fill in your figures (keep or delete the `_comment` keys — the engine ignores any key starting with `_`).
3. **Generate the return:**
   ```bash
   python scripts/build_return.py inputs.json --out MyReturn
   # add --offline to skip the internet and use only the manual_fx / manual_close / manual_high you provided
   ```
4. **Outputs (three files):**
   - `MyReturn.xlsx` — **combined working paper**: `0_Summary` (recommended form + overall confidence), `1_How_Computed` (plain-English derivation of every figure), `Salary` (incl. leave encashment), `House_Property`, **`Business`** (44AD/44ADA/44AE or regular, only if provided), `Schedule_OS`, `Schedule_CG` (incl. foreign-share sales), `FA_A3_Equity`, `FA_A2_Account`, `FA_Dividends_Rule115`, any verbatim FA tables you supplied, `Tax_Both_Regimes`, `FSI_TR_FTC` (only if foreign tax was paid), **`ITR_Form`** (which form + reasons), and `Confidence`. Headline sheets use Indian (lakh/crore) number formatting.
   - `MyReturn.<FORM>.xlsx` — **lean per-form filing workbook** (e.g. `MyReturn.ITR2.xlsx`): only the schedules that form carries, led by a **`Filing_Guide`** sheet that lists every figure in portal-navigation order mapped to its schedule/field, ending with the download-JSON verify step. The verbose `1_How_Computed` and any schedule the form cannot hold (ITR-1/4 never carry Schedule FA/FSI; ITR-1/2 carry no Business) are dropped.
   - `MyReturn.md` — the **recommended ITR form with reasons** + a 4-form decision table, every figure explained, the new-vs-old regime comparison with the cheaper regime flagged, the FTC/DTAA working, a **per-schedule + overall confidence %**, a **"how to file & verify (no JSON upload)"** section, and a **"verify every year (official sources)"** checklist.
5. **File:** enter the figures from the **`Filing_Guide`** sheet into the **recommended form** on the portal (or the offline utility). Re-tick everything; pay self-assessment tax; submit **and e-verify**.
6. **Verify what you filed (no upload JSON):** this skill never produces an *uploadable* ITR JSON — the portal validates its own schema and rejects external files. Instead, at the portal's final/pre-submit stage choose **Download JSON**, then run:
   ```bash
   python scripts/verify_against_portal.py --portal portal_download.json --inputs inputs.json --offline
   ```
   It reads only the computed totals (`PartB-TI` / `PartB_TTI`) — **never name/PAN/address/bank** — and writes a PII-free `VerifyReport.md` + `.xlsx` MATCH/DIFF table (add `--show-paths` to include the matched JSON path). Reconcile every DIFF before submitting.

### Auto-fetched data sources (override-able)
- **SBI TT-buy rates:** `github.com/sahilgupta/sbi-fx-ratekeeper` (a mirror of the official SBI FOREX CARD RATE PDFs), via the GitHub API (proxy-safe). TT BUY is CSV column index 2.
- **Daily stock prices:** the Yahoo Finance chart API (`interval=1d`), intraday high + close. `price_unit: "pence"` divides by 100.
- Any rate/price you put in `manual_fx` / `manual_close` / `manual_high` overrides the fetch, and `--offline` relies on them entirely. **Keep the official SBI rate PDFs as evidence** beside your return.

---

## Verification discipline (if asked to re-check a prepared return)

- **Verify, don't re-state.** Re-derive every figure from the source documents independently, then compare. (`openpyxl data_only=True` returns `None` for un-recalculated formula cells — recompute, don't trust cached values.)
- **Dual-source the FX** (local SBI PDFs + the GitHub mirror). Two agreeing authoritative sources is enough.
- **The peak-VALUE-≠-peak-PRICE check is the #1 real error to look for.** Run the full daily scan; re-scan the account-level peak across late-year lots too.
- **Check total income includes the GROSS 112A gain** (the ₹1.25L is a nil-rate band, not a deduction) — a common under-statement.
- **Confirm the tax YEAR's rules** (slabs, 87A, surcharge cap change year to year) and test surcharge/87A marginal relief at each threshold even if it doesn't bind.
- **Re-running this engine against the real data and reproducing the workbook to the rupee is the strongest cross-check** (it reproduces the reference case — salary + foreign RSU + exempt LTCG — to ₹1).
- **Use the current notified form/schema when a portal help page conflicts.** Example: some older/static ITR-2 help still says Schedule AL at ₹50 lakh, but AY2026-27 ITR-2 notified form (Notification 46/2026) states **₹1 crore**. The notified form wins.
- **Cross-check against the portal's own JSON.** Once the return is prepared on the portal, **Download JSON** and run `python scripts/verify_against_portal.py --portal <file> --inputs inputs.json --offline`. It reconciles the `PartB-TI` / `PartB_TTI` totals to the rupee and is **PII-free** (reads no PersonalInfo). This is the fastest way to catch a portal typo or a wrong regime/form selection. The skill never *uploads* a JSON — the portal rejects external files; you only download to verify.
- **Rank discrepancies by ₹ materiality.** Don't flag immaterial rounding; don't highlight correct values just to look thorough. A structural defect (e.g. a stray ESOP-deferral schedule) can matter even when every number is right.

---

## Official references (every rule → its source)

Each computed rule traces to a primary source. **Verify these on the official site for your AY** — blogs are direction, the statute/CBDT is authority.

| Rule in this skill | Primary source (official) |
|---|---|
| New-regime slabs & rates (115BAC) | Finance Act for the year + `incometaxindia.gov.in` → Acts/Finance Act; e-filing portal tax calculator |
| Standard deduction (₹75,000 new / ₹50,000 old) | §16(ia), as amended by the relevant Finance Act |
| §87A rebate (new ₹60,000 ≤ ₹12L + marginal relief; old ₹12,500 ≤ ₹5L) | §87A + Finance Act proviso |
| Surcharge bands + **15% cap on 111A/112/112A & dividends** + 25% new-regime cap | Finance Act, First Schedule + provisos |
| Health & education cess 4% | Finance Act |
| LTCG 112A — ₹1,25,000 nil band, 12.5% | §112A; `incometaxindia.gov.in` "income from capital gains" |
| STCG 111A — 20% w.e.f. 23-07-2024 | §111A, Finance (No.2) Act 2024 |
| LTCG 112 — 12.5% no indexation | §112, Finance (No.2) Act 2024 |
| **Foreign shares**: 24-month LT threshold; LTCG 112 12.5%; STCG at slab; Rule 115(1)(f) FX | §2(42A), §48, §112; Rule 115; `incometaxindia.gov.in` capital-gains page |
| **Leave encashment** ₹25,00,000 lifetime cap | §10(10AA)(ii); **CBDT Notification 31/2023** (S.O. 2276(E)) |
| **§44AD** presumptive 6%/8%, ₹2cr/₹3cr limit, 5-yr lock-in | §44AD; Finance Act 2023 (₹3cr cash≤5%); `incometaxindia.gov.in` presumptive page |
| **§44ADA** presumptive 50%, ₹50L/₹75L limit, specified professions | §44ADA + §44AA(1); Finance Act 2023 (₹75L cash≤5%) |
| **§44AE** ₹1,000/ton/month (>12T) / ₹7,500/month, ≤10 vehicles | §44AE (Finance Act 2018 rates) |
| **ESOP/RSU** perquisite + FMV cost basis | §17(2)(vi); **§49(2AA)** |
| **FTC / DTAA**: lower-of, Form 67, deadline | §90; **Rule 128** (sub-rule 9, CBDT **Notif 100/2022**); Form 67; India-US DTAA Art. 10 (rate) & Art. 25 (relief) |
| House Property (self-occupied nil/₹2L; let-out 30%; loss set-off) | §22–24; §71(3A) (new-regime loss set-off bar via 115BAC) |
| Schedule FA = calendar year; ROR only | ITR-2 instructions for the AY |
| Schedule AL threshold (**AY2026-27: > ₹1 crore**) | **CBDT Notification 46/2026** (30-Mar-2026), notified **ITR-2** form: Schedule AL "applicable in a case where total income exceeds Rs. 1 Crore"; Rule 12 |
| **Which ITR form (1/2/3/4) + eligibility** (₹50L limit, 2 house properties, LTCG-112A ≤ ₹1.25L in ITR-1/4) | **CBDT ITR-form notifications for the AY** — AY2026-27 includes **Notification 45/2026** (ITR-1/4) and **Notification 46/2026** (ITR-2); Rule 12 |
| **Old-regime opt-out** (Form 10-IEA only for ITR-3/4 business; ITR-1/2 opt in-form) | §115BAC(1A); **Rule 21AGA**; Income-Tax Dept "New vs Old Regime" / Form 10-IEA FAQ |

## Annual web-search protocol (self-contained — run BEFORE filing each year)

The engine ships **FY2025-26 defaults**. Each Budget can change them, so for any later year **web-search the official figure and override** via `regime_overrides` / input fields. Search the official source first (`incometaxindia.gov.in`, `incometax.gov.in`, the Finance Act, CBDT notifications); use a reputable explainer only to locate the primary source.

Run these queries (replace the year), then confirm against the primary source:
1. `income tax slab rate new regime 115BAC FY<YYYY-YY> site:incometaxindia.gov.in`
2. `section 87A rebate limit FY<YYYY-YY> new regime marginal relief`
3. `surcharge rate FY<YYYY-YY> 15% cap capital gains dividend marginal relief`
4. `LTCG 112A exemption limit rate FY<YYYY-YY>` · `STCG 111A rate FY<YYYY-YY>`
5. `standard deduction salary FY<YYYY-YY> new old regime`
6. `leave encashment exemption section 10(10AA) limit FY<YYYY-YY>`
7. `foreign shares capital gains holding period rate India FY<YYYY-YY>`
8. `Form 67 foreign tax credit Rule 128 deadline AY<YYYY-YY>` · `India US DTAA dividend withholding rate`
9. `Schedule AL applicability threshold ITR-2 AY<YYYY-YY>` · `ITR-2 country code list <year>`
10. `ITR-2 schema / JSON schema AY<YYYY-YY> download` (confirm Schedule FA / FSI / TR layout)
11. `ITR-1 ITR-2 ITR-3 ITR-4 eligibility who can file AY<YYYY-YY> CBDT notification` (confirm the ₹50L limit, house-property count, the LTCG-112A-in-ITR-1/4 carve-out, and separate ITR-2 notification if issued — these changed in AY2025-26 and AY2026-27)
12. `Form 10-IEA opt out new regime AY<YYYY-YY>` (confirm who must file it)
13. `section 44AD 44ADA 44AE presumptive rate turnover limit FY<YYYY-YY>` (confirm 6%/8%, 50%, ₹1,000/₹7,500 and the ₹2cr/₹3cr & ₹50L/₹75L limits — these can move with each Budget)

Then: update `regime_overrides` (slabs/surcharge/cess/std_deduction/rebate_87a), the CG `*_rate` fields, the leave-encashment cap if it changed, the presumptive rates/limits if a Budget moved them, and re-run. The markdown's **"Verify every year"** block and the engine's console reminder restate the assumed numbers so you can eyeball them.

---

## Self-test (battle-test the engine before you trust it)

A self-contained regression suite lives in **`selftest/`** — **synthetic data only, no PII, fully offline**. It runs the engine against fixtures covering **ITR-1, ITR-2 (capital gains + foreign-share FX), ITR-3 (regular business), and ITR-4 (44AD / 44ADA / 44AE)**, plus a let-out-house-property case and a smoke test of the shipped example, and asserts the **recommended form, cheaper regime, total income, business income and net tax** against hand-verified golden values. It also checks the **per-form Excel** trimming (Filing_Guide first; ITR-1 drops FA/FSI/Business; ITR-4 keeps Business), **Schedule AL threshold** (AY2026-27: no AL below ₹1 crore; AL above ₹1 crore), and the **portal verifier** (parses a synthetic portal JSON, reconciles to the rupee, and proves no PersonalInfo leaks into the report).

```bash
python selftest/run_selftests.py        # prints a PASS/FAIL table; exit 0 = all green
python selftest/run_selftests.py -v     # also prints the form-selection reasons per case
```

Run it after **any** change to `build_return.py` / `verify_against_portal.py`, and after the **annual rate update** (update the golden values in `run_selftests.py` to the new year's expected figures, then keep them green). All **11** checks must pass before you file from this skill. See `selftest/SELFTEST.md` for what each case proves.

---

## Files in this skill (self-contained — zip the whole folder)
- `SKILL.md` — this file.
- `README.md` — quick start.
- `scripts/build_return.py` — the computation engine (combined + per-form Excel + markdown generator). **No personal data is embedded.**
- `scripts/verify_against_portal.py` — cross-checks the engine vs the JSON you download from the portal; writes a **PII-free** MATCH/DIFF report.
- `scripts/inputs.example.json` — generic, dummy-data template with every block incl. `business` (runs offline out of the box).
- `selftest/run_selftests.py` — offline regression runner (ITR-1/2/3/4 + per-form Excel + verifier), exit-code friendly.
- `selftest/SELFTEST.md` — what each fixture proves + how to refresh goldens yearly.
- `selftest/cases/*.json` — synthetic fixtures (no PII), incl. `portal_itr2_capgains.json` (synthetic portal-export shape).
