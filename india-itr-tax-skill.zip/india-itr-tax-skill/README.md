# india-itr-tax — India ITR-1/2/3/4 + Schedule FA computation skill

A self-contained, shareable tool that **picks the right form (ITR-1 / ITR-2 / ITR-3 / ITR-4)**
from the CBDT-notified eligibility, then computes the return — Salary (incl. **ESOP/RSU
perquisite** and **leave encashment §10(10AA)**), House Property, **Business/Profession income
(presumptive §44AD/44ADA/44AE → ITR-4, or regular net profit → ITR-3)**, Capital Gains (**LTCG
112A, STCG 111A, LTCG 112**, and **foreign shares** via INDmoney/Interactive Brokers/EquatePlus →
**§112 / slab**), Other Sources, **Schedule FA (Foreign Assets)**, and the **Foreign Tax Credit
(DTAA, Form 67, Schedule FSI/TR)** — under **both the new and old tax regimes**. It produces
**three outputs**: a **combined** Excel working paper (all schedules + a "how computed" sheet +
ITR-form selection + Confidence), a **lean per-form workbook** (`MyReturn.<FORM>.xlsx` — only the
schedules that ITR form carries, led by a portal-order **`Filing_Guide`** that maps each figure to
the exact field you type it into), and a **markdown that explains every figure**. A **synthetic,
offline self-test suite** (`selftest/`) battle-tests all four forms and the portal verifier.

It uses the exact **SBI TT-buying rate (Rule 115)** and **daily stock prices** for foreign-asset
valuation, with a full daily **peak-value scan** (the peak-value day is usually not the
peak-price day). Tax is computed with the **15% surcharge cap** on capital gains/dividends and
**surcharge & §87A marginal relief**. It emits a **per-schedule + overall confidence %**, and
lists the **official rules to re-verify each year**. No personal data is built in — everything
comes from your own `inputs.json`. The engine reproduces the reference case (salary + foreign
RSU + exempt LTCG) **to the rupee**.

> ⚠️ Computation aid, **not tax advice**. Foreign-asset disclosure is governed by the Black Money
> Act — have a practising CA sign off and re-verify in the live ITR utility before filing.

## Quick start
```bash
pip install openpyxl
cp scripts/inputs.example.json inputs.json     # then edit with your figures
python scripts/build_return.py inputs.json --out MyReturn
#   --offline  : skip the internet; use only the rates/prices you put in the JSON
```
Outputs:
- `MyReturn.xlsx` — combined working paper (every schedule + `1_How_Computed` + `Business` if any + `ITR_Form` + `Confidence`).
- `MyReturn.<FORM>.xlsx` — lean filing workbook for the recommended form, led by `Filing_Guide` (portal-order field → value).
- `MyReturn.md` — recommended form with reasons, every figure explained, new-vs-old regime, **how to file & verify**.

The console prints the **recommended ITR form** and warns if it differs from the `meta.form` you declared.

## File it, then verify (no JSON upload)
This skill **does not** create an uploadable ITR JSON — the portal validates its own schema and
rejects external files. Enter the figures from the `Filing_Guide` into the portal, then at the
final/pre-submit stage **Download JSON** from the portal and cross-check it:
```bash
python scripts/verify_against_portal.py --portal portal_download.json --inputs inputs.json --offline
```
It reads only the computed totals (`PartB-TI` / `PartB_TTI`) — **never name/PAN/address/bank** — and
prints a PII-free MATCH/DIFF table (`.md` + `.xlsx`). Reconcile every DIFF before you submit.

## What you need to fill in
Your figures from **Form 16/12BA, Form 26AS, AIS, the broker capital-gains report (incl. US brokers
like INDmoney/IBKR + Form 1042-S for US dividend WHT), your home-loan interest certificate, any
leave-encashment statement, your business turnover/receipts or P&L (for ITR-3/4), and your foreign
share-plan portfolio/transactions/dividend vouchers**. See the inline comments in
`inputs.example.json` and the full method, **official references**, the **annual web-search
protocol**, and the **which-schedules-to-file/remove** guidance in **`SKILL.md`**.

## Battle-tested
```bash
python selftest/run_selftests.py        # offline regression: ITR-1/2/3/4 + per-form Excel + portal verifier
```
Synthetic data only, no PII; exit 0 = all green. See `selftest/SELFTEST.md`.

## Files (self-contained — zip the whole folder)
- `SKILL.md` — required documents, the full computation method (incl. §44AD/44ADA/44AE), official-source references, schedule-selection guidance, the yearly web-search protocol, the verify-against-portal workflow, and run instructions.
- `scripts/build_return.py` — the engine (no personal data embedded).
- `scripts/verify_against_portal.py` — cross-checks the engine vs the JSON you download from the portal (PII-free report).
- `scripts/inputs.example.json` — dummy-data template incl. the `business` block (runs offline out of the box).
- `selftest/run_selftests.py` + `selftest/cases/*.json` + `selftest/SELFTEST.md` — offline regression suite (synthetic, no PII; includes a synthetic portal-JSON fixture).

## Data sources (auto-fetched, override-able)
- SBI TT-buy rates: `github.com/sahilgupta/sbi-fx-ratekeeper` (mirror of official SBI PDFs).
- Daily stock prices: Yahoo Finance chart API.
Keep the official SBI rate PDFs as evidence beside your filed return.
