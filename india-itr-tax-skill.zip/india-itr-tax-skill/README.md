# india-itr-tax — India ITR-2 + Schedule FA computation skill

A self-contained, shareable tool that computes an India **ITR-2** return — Salary, Capital
Gains (LTCG 112A), Other Sources, and **Schedule FA (Foreign Assets)** — under **both the new
and old tax regimes**, and produces an **Excel workbook (all schedules) + a markdown that
explains every figure**.

It uses the exact **SBI TT-buying rate (Rule 115)** and **daily stock prices** for foreign-asset
valuation, with a full daily **peak-value scan** (the peak-value day is usually not the
peak-price day). No personal data is built in — everything comes from your own `inputs.json`.

> ⚠️ Computation aid, **not tax advice**. Foreign-asset disclosure is governed by the Black Money
> Act — have a practising CA sign off and re-verify in the live ITR utility before filing.

## Quick start
```bash
pip install openpyxl
cp scripts/inputs.example.json inputs.json     # then edit with your figures
python scripts/build_return.py inputs.json --out MyReturn
#   --offline  : skip the internet; use only the rates/prices you put in the JSON
```
Outputs: `MyReturn.xlsx` (one sheet per schedule) and `MyReturn.md` (computation explained,
new-vs-old regime, cheaper regime flagged).

## What you need to fill in
Your figures from **Form 16/12BA, Form 26AS, AIS, broker capital-gains report, and your
foreign share-plan portfolio/transactions/dividend vouchers**. See the inline comments in
`inputs.example.json` and the full method in **`SKILL.md`**.

## Files
- `SKILL.md` — required documents, the full computation method, and run instructions.
- `scripts/build_return.py` — the engine.
- `scripts/inputs.example.json` — dummy-data template (runs offline out of the box).

## Data sources (auto-fetched, override-able)
- SBI TT-buy rates: `github.com/sahilgupta/sbi-fx-ratekeeper` (mirror of official SBI PDFs).
- Daily stock prices: Yahoo Finance chart API.
Keep the official SBI rate PDFs as evidence beside your filed return.
