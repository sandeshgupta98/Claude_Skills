# -*- coding: utf-8 -*-
"""
build_return.py - Generic India ITR-2 + Schedule FA computation engine.

Reads a single inputs.json describing salary / interest / capital gains / foreign
share lots / foreign dividends, then:
  - auto-fetches SBI TT-BUY rates (sahilgupta/sbi-fx-ratekeeper) and daily stock
    prices (Yahoo chart API) for the dates it needs (manual override allowed),
  - computes Schedule FA (A1-G as provided), Schedule OS, Schedule CG/112A, Salary,
  - computes tax under BOTH new and old regimes (FY2025-26 defaults; override in JSON),
  - writes <out>.xlsx (one sheet per schedule) and <out>.md (computation explained).

NO personal data is embedded. Everything comes from inputs.json.

Usage:
    python build_return.py inputs.json                 # auto-fetch online
    python build_return.py inputs.json --offline        # use only rates/prices in JSON
    python build_return.py inputs.json --out MyReturn   # output basename

Requires: openpyxl. Auto-fetch additionally uses urllib (stdlib) - no extra installs.
See inputs.example.json for the schema and SKILL.md for the full method.
"""
import sys, os, json, csv, io, base64, datetime, urllib.request, ssl

# ----------------------------------------------------------------------------- utils
def log(m): print(m, flush=True)

def rupees(n):
    """Indian-format integer rupees, e.g. 7144030 -> '71,44,030'."""
    s = str(int(round(n))); neg = s.startswith('-'); s = s.lstrip('-')
    if len(s) <= 3:
        body = s
    else:
        body = s[-3:]; s = s[:-3]
        while len(s) > 2:
            body = s[-2:] + ',' + body; s = s[:-2]
        if s: body = s + ',' + body
    return ('-' if neg else '') + body

def http_get(url, timeout=60):
    ctx = ssl.create_default_context()
    try:
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE   # tolerate corp proxies
    except Exception:
        pass
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()

# ----------------------------------------------------------------------- FX (SBI TTBR)
SBI_CSV_API = ("https://api.github.com/repos/sahilgupta/sbi-fx-ratekeeper/"
               "contents/csv_files/SBI_REFERENCE_RATES_{cur}.csv")

def fetch_sbi(currency, offline, manual):
    """Return dict {date 'YYYY-MM-DD': tt_buy float}. Manual entries always win."""
    rates = {}
    if not offline:
        try:
            raw = http_get(SBI_CSV_API.format(cur=currency.upper()))
            content = json.loads(raw.decode())['content']
            text = base64.b64decode(content).decode('utf-8', 'replace')
            rd = csv.reader(io.StringIO(text)); next(rd, None)
            for row in rd:
                if len(row) < 3: continue
                d = row[0][:10]
                try: rates[d] = float(row[2])     # col index 2 = TT BUY
                except ValueError: pass
            log(f"  SBI {currency}: fetched {len(rates)} daily rates")
        except Exception as e:
            log(f"  SBI fetch failed ({e}); relying on manual rates")
    for d, v in (manual or {}).items():
        if d.startswith('_'): continue
        rates[d] = float(v)
    return rates

def rate_on(rates, date_str):
    """Exact rate, else most recent prior published working day (up to 14 days back)."""
    d = datetime.date.fromisoformat(date_str)
    for back in range(0, 15):
        k = (d - datetime.timedelta(days=back)).isoformat()
        if k in rates: return rates[k], k
    raise SystemExit(f"No SBI rate on/before {date_str} - add it to inputs 'manual_fx'.")

def prev_month_end(date_str):
    d = datetime.date.fromisoformat(date_str)
    return (d.replace(day=1) - datetime.timedelta(days=1)).isoformat()

# ------------------------------------------------------------------- stock daily prices
YAHOO = ("https://query1.finance.yahoo.com/v8/finance/chart/{sym}"
         "?period1={p1}&period2={p2}&interval=1d")

def fetch_prices(symbol, year, unit, offline, manual_close, manual_high):
    """Return ({date: close}, {date: high}) in MAJOR currency units."""
    close, high = {}, {}
    if not offline and symbol:
        try:
            p1 = int(datetime.datetime(year, 1, 1, tzinfo=datetime.timezone.utc).timestamp())
            p2 = int(datetime.datetime(year + 1, 1, 2, tzinfo=datetime.timezone.utc).timestamp())
            raw = http_get(YAHOO.format(sym=symbol, p1=p1, p2=p2))
            res = json.loads(raw.decode())['chart']['result'][0]
            ts = res['timestamp']; q = res['indicators']['quote'][0]
            cl = q['close']; hi = q.get('high', cl)
            div = 100.0 if unit == 'pence' else 1.0
            for i, t in enumerate(ts):
                d = datetime.datetime.fromtimestamp(t, datetime.timezone.utc).date().isoformat()
                if cl[i] is not None: close[d] = cl[i] / div
                h = hi[i] if (hi and hi[i] is not None) else cl[i]
                if h is not None: high[d] = h / div
            log(f"  {symbol}: fetched {len(close)} daily prices for {year}")
        except Exception as e:
            log(f"  price fetch failed for {symbol} ({e}); relying on manual prices")
    for d, v in (manual_close or {}).items():
        if not d.startswith('_'): close[d] = float(v)
    for d, v in (manual_high or {}).items():
        if not d.startswith('_'): high[d] = float(v)
    return close, high

# --------------------------------------------------------------------------- Schedule FA
def compute_fa_equity(spec, rates, close, high):
    """Per-lot A3-style rows + consolidated account peak. Returns (rows, totals, peak_info)."""
    cy = spec['calendar_year']
    close_date = f"{cy}-12-31"
    # closing price = the close on/just before 31-Dec; closing FX = TTBR on/before 31-Dec
    cd = max([d for d in close if d <= close_date], default=None)
    if cd is None:
        raise SystemExit("No stock close price found for the calendar year - check symbol/manual prices.")
    close_px = close[cd]; close_fx, _ = rate_on(rates, close_date)

    lots = []
    for l in spec['lots']:
        lots.append(dict(l, _d=datetime.date.fromisoformat(l['acq_date'])))

    def qty_on(dstr):
        dd = datetime.date.fromisoformat(dstr)
        return sum(x['units'] for x in lots if x['_d'] <= dd)

    # per-lot initial / peak / closing
    rows = []; tot_init = tot_close = 0.0
    for l in lots:
        init_fx, _ = rate_on(rates, l['acq_date'])
        initial = l['units'] * l['cost_per_share'] * init_fx
        closing = l['units'] * close_px * close_fx
        # lot peak: scan its holding window within CY using intraday HIGH
        best = 0.0; bday = None
        start = max(l['_d'], datetime.date(cy, 1, 1))
        for d in sorted(high):
            if datetime.date.fromisoformat(d) < start: continue
            if d > close_date: break
            fx, _ = rate_on(rates, d)
            v = high[d] * fx
            if v > best: best, bday = v, d
        peak = l['units'] * best
        tot_init += initial; tot_close += closing
        rows.append({
            'acq_date': l['acq_date'], 'units': l['units'],
            'initial': round(initial), 'peak': round(peak), 'closing': round(closing),
            'peak_day': bday})

    # consolidated ACCOUNT peak (qty held that day x high x fx) over the whole CY
    acc_peak = 0.0; acc_day = None
    for d in sorted(high):
        dd = datetime.date.fromisoformat(d)
        if dd.year != cy: continue
        fx, _ = rate_on(rates, d)
        v = qty_on(d) * high[d] * fx
        if v > acc_peak: acc_peak, acc_day = v, d

    totals = {'initial': round(tot_init), 'closing': round(tot_close),
              'units': round(sum(x['units'] for x in lots), 5)}
    peak_info = {'account_peak': round(acc_peak), 'account_peak_day': acc_day,
                 'close_price_used': close_px, 'close_fx_used': close_fx, 'close_date_used': cd}
    return rows, totals, peak_info

def compute_dividends(spec, rates):
    """Rule 115: TTBR on last day of month preceding payment. Returns (rows, total_inr, total_fx)."""
    rows = []; tot_inr = 0.0; tot_fx = 0.0
    for dv in spec.get('dividends', []):
        ref = prev_month_end(dv['pay_date'])
        fx, used = rate_on(rates, ref)
        inr = dv['gross_fx'] * fx
        tot_inr += inr; tot_fx += dv['gross_fx']
        rows.append({'pay_date': dv['pay_date'], 'gross_fx': dv['gross_fx'],
                     'rule115_date': used, 'fx': fx, 'inr': round(inr),
                     'wht_fx': dv.get('wht_fx', 0)})
    return rows, round(tot_inr), round(tot_fx, 2)

# --------------------------------------------------------------------------------- tax
def slab_tax(ti, bands):
    t = 0.0
    for lo, hi, r in bands:
        hi = hi if hi is not None else float('inf')
        t += max(0, min(ti, hi) - lo) * r
    return t

def compute_tax(total_income, special_income, regime_cfg, deductions=0):
    """Generic slab + surcharge (with marginal relief) + cess + 87A rebate."""
    bands = [(b[0], b[1], b[2]) for b in regime_cfg['slabs']]
    base = max(0, total_income - special_income - deductions)
    slab = slab_tax(base, bands)
    special_tax = sum(s['amount'] * s['rate'] for s in regime_cfg.get('special', []))
    # 87A rebate
    rebate = 0.0
    r87 = regime_cfg.get('rebate_87a')
    if r87 and (total_income - deductions) <= r87['income_limit']:
        rebate = min(slab + special_tax, r87['max_rebate'])
    tax_before_sur = slab + special_tax - rebate
    # surcharge (find band by total income) with marginal relief at the threshold
    sur_rate = 0.0; threshold = 0.0
    for lo, rate in regime_cfg['surcharge']:        # ascending [(income_over, rate), ...]
        if total_income > lo: sur_rate = rate; threshold = lo
    surcharge = tax_before_sur * sur_rate
    if sur_rate > 0:
        # tax (incl. surcharge) cannot exceed tax_at_threshold + (income - threshold)
        tax_at_thr = slab_tax(max(0, threshold - special_income - deductions), bands) + special_tax
        ceiling = tax_at_thr + (total_income - threshold)
        if tax_before_sur + surcharge > ceiling:
            surcharge = max(0, ceiling - tax_before_sur)
    cess = (tax_before_sur + surcharge) * regime_cfg.get('cess', 0.04)
    total = tax_before_sur + surcharge + cess
    return {'slab': round(slab), 'special_tax': round(special_tax), 'rebate_87a': round(rebate),
            'tax_before_surcharge': round(tax_before_sur), 'surcharge_rate': sur_rate,
            'surcharge': round(surcharge), 'cess': round(cess),
            'total_tax': round(round(total) / 10) * 10}

# ---------------------------------------------------------------- default regime configs
def default_regimes():
    new = {  # FY2025-26 (AY2026-27) new regime u/s 115BAC
        'slabs': [(0,400000,0),(400000,800000,.05),(800000,1200000,.10),
                  (1200000,1600000,.15),(1600000,2000000,.20),(2000000,2400000,.25),
                  (2400000,None,.30)],
        'surcharge': [(0,0),(5000000,.10),(10000000,.15),(20000000,.25)],
        'cess': 0.04,
        'rebate_87a': {'income_limit': 1200000, 'max_rebate': 60000},
        'std_deduction': 75000}
    old = {  # FY2025-26 old regime
        'slabs': [(0,250000,0),(250000,500000,.05),(500000,1000000,.20),(1000000,None,.30)],
        'surcharge': [(0,0),(5000000,.10),(10000000,.15),(20000000,.25),(50000000,.37)],
        'cess': 0.04,
        'rebate_87a': {'income_limit': 500000, 'max_rebate': 12500},
        'std_deduction': 50000}
    return {'new': new, 'old': old}

# ---------------------------------------------------------------------------- orchestrate
def build(inputs_path, out_base, offline):
    spec = json.load(open(inputs_path, encoding='utf-8'))
    regimes = default_regimes()
    for name in ('new', 'old'):
        ov = spec.get('regime_overrides', {}).get(name)
        if isinstance(ov, dict):
            regimes[name].update({k: v for k, v in ov.items() if not k.startswith('_')})

    # ---- gather FX + prices for the foreign-equity block (if any)
    fa = spec.get('foreign_equity')
    fa_rows = []; fa_tot = {}; peak_info = {}; div_rows = []; div_inr = 0; div_fx = 0
    if fa:
        rates = fetch_sbi(fa['currency'], offline, fa.get('manual_fx'))
        close, high = fetch_prices(fa.get('symbol'), fa['calendar_year'],
                                   fa.get('price_unit', 'major'), offline,
                                   fa.get('manual_close'), fa.get('manual_high'))
        fa_rows, fa_tot, peak_info = compute_fa_equity(fa, rates, close, high)
        div_rows, div_inr, div_fx = compute_dividends(fa, rates)

    # ---- Schedule OS (drop any _comment keys)
    def clean(d): return {k: v for k, v in (d or {}).items() if not k.startswith('_')}
    interest = clean(spec.get('income', {}).get('savings_interest', {}))   # {label: amount}
    other_int = clean(spec.get('income', {}).get('other_interest', {}))
    os_total = sum(interest.values()) + sum(other_int.values()) + div_inr \
               + spec.get('income', {}).get('other_os', 0)

    # ---- Schedule CG / 112A
    cg = spec.get('capital_gains', {})
    ltcg_112a_gain = cg.get('ltcg_112a_sale', 0) - cg.get('ltcg_112a_cost', 0)
    ltcg_112a_exempt = min(cg.get('ltcg_112a_exemption', 125000), max(0, ltcg_112a_gain))
    ltcg_112a_taxable = max(0, ltcg_112a_gain - cg.get('ltcg_112a_exemption', 125000))
    other_special = cg.get('other_special_income', [])  # [{label, amount, rate}]

    # ---- Salary
    sal = spec.get('salary', {})
    gross_salary = sal.get('sec17_1', 0) + sal.get('sec17_2', 0) + sal.get('sec17_3', 0)

    # ---- totals per regime
    results = {}
    for rname, rcfg in regimes.items():
        std = rcfg.get('std_deduction', 0) if gross_salary > 0 else 0
        salary_income = max(0, gross_salary - std)
        chvi_a = 0 if rname == 'new' else sum(
            v for k, v in spec.get('deductions_old_regime', {}).items()
            if not k.startswith('_') and isinstance(v, (int, float)))
        special = [{'amount': ltcg_112a_taxable, 'rate': cg.get('ltcg_112a_rate', 0.125)}]
        special += other_special
        gti = salary_income + os_total + ltcg_112a_taxable \
              + sum(s['amount'] for s in other_special)
        total_income = round((gti - chvi_a) / 10) * 10
        rcfg_run = dict(rcfg); rcfg_run['special'] = special
        special_income = ltcg_112a_taxable + sum(s['amount'] for s in other_special)
        tax = compute_tax(total_income, special_income, rcfg_run, deductions=0)
        tds = spec.get('taxes_paid', {}).get('tds_total', 0) \
              + spec.get('taxes_paid', {}).get('advance_self_asst', 0)
        results[rname] = {'salary_income': salary_income, 'std': std, 'chvi_a': chvi_a,
                          'os_total': os_total, 'ltcg_taxable': ltcg_112a_taxable,
                          'total_income': total_income, 'tax': tax,
                          'tds': tds, 'balance': tax['total_tax'] - tds}

    cheaper = 'new' if results['new']['tax']['total_tax'] <= results['old']['tax']['total_tax'] else 'old'

    bundle = {'spec': spec, 'fa_rows': fa_rows, 'fa_tot': fa_tot, 'peak_info': peak_info,
              'div_rows': div_rows, 'div_inr': div_inr, 'div_fx': div_fx,
              'interest': interest, 'other_int': other_int, 'os_total': os_total,
              'ltcg_112a_gain': ltcg_112a_gain, 'ltcg_112a_exempt': ltcg_112a_exempt,
              'ltcg_112a_taxable': ltcg_112a_taxable, 'gross_salary': gross_salary,
              'results': results, 'cheaper': cheaper}
    write_excel(bundle, out_base + '.xlsx')
    write_markdown(bundle, out_base + '.md')
    log(f"\nDONE -> {out_base}.xlsx  and  {out_base}.md")
    log(f"  New regime tax: Rs {rupees(results['new']['tax']['total_tax'])} | "
        f"Old regime tax: Rs {rupees(results['old']['tax']['total_tax'])} | "
        f"cheaper: {cheaper.upper()}")

# ---------------------------------------------------------------------------- Excel out
def write_excel(b, path):
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = openpyxl.Workbook()
    hdr = Font(bold=True, color='FFFFFF'); hfill = PatternFill('solid', fgColor='305496')
    bold = Font(bold=True)
    def sheet(name):
        ws = wb.create_sheet(name); return ws
    def put(ws, r, c, v, head=False, b_=False):
        cell = ws.cell(r, c, v)
        if head: cell.font = hdr; cell.fill = hfill
        elif b_: cell.font = bold
        return cell

    spec = b['spec']; meta = spec.get('meta', {})
    # ----- 0 Summary
    ws = wb.active; ws.title = '0_Summary'
    rows = [
        ['India ITR Tax Computation', ''],
        ['Assessment Year', meta.get('assessment_year', '')],
        ['Financial Year', meta.get('financial_year', '')],
        ['Form', meta.get('form', 'ITR-2')],
        ['Residential status', meta.get('residential_status', '')],
        ['', ''],
        ['Head', 'Amount INR'],
        ['Salary income (new regime)', b['results']['new']['salary_income']],
        ['Income from Other Sources', b['os_total']],
        ['Taxable LTCG 112A', b['ltcg_112a_taxable']],
        ['Total income (new regime)', b['results']['new']['total_income']],
        ['', ''],
        ['Regime', 'Total tax INR'],
        ['New regime', b['results']['new']['tax']['total_tax']],
        ['Old regime', b['results']['old']['tax']['total_tax']],
        ['Cheaper regime', b['cheaper'].upper()],
    ]
    for i, (a, c) in enumerate(rows, 1):
        head = a in ('Head', 'Regime')
        put(ws, i, 1, a, head=head, b_=(i == 1)); put(ws, i, 2, c, head=head)
    ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 22

    # ----- Salary
    ws = sheet('Salary')
    data = [['Component', 'Amount INR'],
            ['Salary u/s 17(1)', spec.get('salary', {}).get('sec17_1', 0)],
            ['Perquisites u/s 17(2)', spec.get('salary', {}).get('sec17_2', 0)],
            ['Profits in lieu u/s 17(3)', spec.get('salary', {}).get('sec17_3', 0)],
            ['Gross salary', b['gross_salary']],
            ['Less: Standard deduction (new regime)', b['results']['new']['std']],
            ['Income chargeable - Salaries (new regime)', b['results']['new']['salary_income']]]
    for i, row in enumerate(data, 1):
        put(ws, i, 1, row[0], head=(i == 1), b_=(row[0].startswith('Gross') or row[0].startswith('Income')))
        put(ws, i, 2, row[1], head=(i == 1))
    ws.column_dimensions['A'].width = 42; ws.column_dimensions['B'].width = 16

    # ----- Schedule OS
    ws = sheet('Schedule_OS')
    put(ws, 1, 1, 'Item', head=True); put(ws, 1, 2, 'Amount INR', head=True); put(ws, 1, 3, 'Source', head=True)
    r = 2
    for label, amt in b['interest'].items():
        put(ws, r, 1, f"Savings interest - {label}"); put(ws, r, 2, amt); put(ws, r, 3, 'AIS SFT-016'); r += 1
    for label, amt in b['other_int'].items():
        put(ws, r, 1, f"Interest - {label}"); put(ws, r, 2, amt); r += 1
    if b['div_inr']:
        put(ws, r, 1, 'Foreign dividend (gross)'); put(ws, r, 2, b['div_inr'])
        put(ws, r, 3, 'Vouchers; Rule 115; report gross even if reinvested'); r += 1
    put(ws, r, 1, 'TOTAL Schedule OS', b_=True); put(ws, r, 2, b['os_total'], b_=True)
    ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 16; ws.column_dimensions['C'].width = 48

    # ----- Schedule CG / 112A
    ws = sheet('Schedule_CG_112A')
    cg = spec.get('capital_gains', {})
    data = [['Item', 'Amount INR'],
            ['LTCG 112A - sale value', cg.get('ltcg_112a_sale', 0)],
            ['Less: cost of acquisition', cg.get('ltcg_112a_cost', 0)],
            ['LTCG gross', b['ltcg_112a_gain']],
            ['Less: 112A exemption', b['ltcg_112a_exempt']],
            ['Taxable LTCG 112A', b['ltcg_112a_taxable']]]
    for i, row in enumerate(data, 1):
        put(ws, i, 1, row[0], head=(i == 1), b_=row[0].startswith('Taxable')); put(ws, i, 2, row[1], head=(i == 1))
    ws.column_dimensions['A'].width = 32; ws.column_dimensions['B'].width = 16

    # ----- Schedule FA A3 (equity) + A2 (account)
    if b['fa_rows']:
        ws = sheet('FA_A3_Equity')
        cols = ['Country (code)', 'Entity', 'Date acquired', 'Units', 'Initial INR',
                'Peak INR', 'Closing INR', 'Gross credited INR', 'Sale proceeds INR']
        for c, h in enumerate(cols, 1): put(ws, 1, c, h, head=True)
        fe = spec['foreign_equity']
        for i, row in enumerate(b['fa_rows'], 2):
            put(ws, i, 1, fe.get('country', '')); put(ws, i, 2, fe.get('entity', ''))
            put(ws, i, 3, row['acq_date']); put(ws, i, 4, row['units'])
            put(ws, i, 5, row['initial']); put(ws, i, 6, row['peak']); put(ws, i, 7, row['closing'])
            put(ws, i, 8, b['div_inr'] if i == 2 else 0); put(ws, i, 9, 0)
        tr = len(b['fa_rows']) + 2
        put(ws, tr, 3, 'TOTAL', b_=True); put(ws, tr, 5, b['fa_tot']['initial'], b_=True)
        put(ws, tr, 6, 'do NOT sum peaks', b_=True); put(ws, tr, 7, b['fa_tot']['closing'], b_=True)
        put(ws, tr, 8, b['div_inr'], b_=True)
        for col, w in zip('ABCDEFGHI', [22, 18, 13, 12, 12, 12, 12, 16, 14]):
            ws.column_dimensions[col].width = w

        ws = sheet('FA_A2_Account')
        a2 = [['Field', 'Value'],
              ['Country (code)', fe.get('country', '')],
              ['Financial institution', fe.get('custodian', '')],
              ['Account number', fe.get('account_number', '')],
              ['Status', fe.get('owner_status', 'Beneficial owner')],
              ['Account opening date', fe.get('account_open_date', '')],
              ['Peak balance INR (account-level)', b['peak_info']['account_peak']],
              ['  (peak day)', b['peak_info']['account_peak_day']],
              ['Closing balance INR', b['fa_tot']['closing']],
              ['Gross dividend credited INR', b['div_inr']],
              ['Sale proceeds INR', 0]]
        for i, row in enumerate(a2, 1):
            put(ws, i, 1, row[0], head=(i == 1), b_=row[0].startswith('Peak')); put(ws, i, 2, row[1], head=(i == 1))
        ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 44

        # dividends detail
        ws = sheet('FA_Dividends_Rule115')
        for c, h in enumerate(['Pay date', 'Gross FX', 'Rule-115 FX date', 'SBI TT-buy', 'INR', 'WHT FX'], 1):
            put(ws, 1, c, h, head=True)
        for i, d in enumerate(b['div_rows'], 2):
            put(ws, i, 1, d['pay_date']); put(ws, i, 2, d['gross_fx']); put(ws, i, 3, d['rule115_date'])
            put(ws, i, 4, d['fx']); put(ws, i, 5, d['inr']); put(ws, i, 6, d['wht_fx'])
        tr = len(b['div_rows']) + 2
        put(ws, tr, 1, 'TOTAL', b_=True); put(ws, tr, 2, b['div_fx'], b_=True); put(ws, tr, 5, b['div_inr'], b_=True)
        for col, w in zip('ABCDEF', [12, 10, 16, 12, 10, 10]): ws.column_dimensions[col].width = w

    # ----- generic FA tables A1,A4,B-G provided verbatim
    for tname, trows in (spec.get('foreign_assets_other') or {}).items():
        if tname.startswith('_') or not isinstance(trows, list) or not trows:
            continue
        ws = sheet(f"FA_{tname}")
        if trows:
            headers = list(trows[0].keys())
            for c, h in enumerate(headers, 1): put(ws, 1, c, h, head=True)
            for i, row in enumerate(trows, 2):
                for c, h in enumerate(headers, 1): put(ws, i, c, row.get(h, ''))

    # ----- Tax (both regimes)
    ws = sheet('Tax_Both_Regimes')
    put(ws, 1, 1, 'Line', head=True); put(ws, 1, 2, 'New regime', head=True); put(ws, 1, 3, 'Old regime', head=True)
    R = b['results']
    lines = [
        ('Salary income', 'salary_income'), ('Other Sources', None), ('Taxable LTCG 112A', 'ltcg_taxable'),
        ('Total income', 'total_income')]
    r = 2
    put(ws, r, 1, 'Salary income'); put(ws, r, 2, R['new']['salary_income']); put(ws, r, 3, R['old']['salary_income']); r += 1
    put(ws, r, 1, 'Other Sources'); put(ws, r, 2, R['new']['os_total']); put(ws, r, 3, R['old']['os_total']); r += 1
    put(ws, r, 1, 'Taxable LTCG 112A'); put(ws, r, 2, R['new']['ltcg_taxable']); put(ws, r, 3, R['old']['ltcg_taxable']); r += 1
    put(ws, r, 1, 'Chapter VI-A deductions'); put(ws, r, 2, R['new']['chvi_a']); put(ws, r, 3, R['old']['chvi_a']); r += 1
    put(ws, r, 1, 'TOTAL INCOME', b_=True); put(ws, r, 2, R['new']['total_income'], b_=True); put(ws, r, 3, R['old']['total_income'], b_=True); r += 1
    for key, lab in [('slab', 'Tax at slab'), ('special_tax', 'Tax on special-rate income'),
                     ('rebate_87a', 'Less: rebate 87A'), ('surcharge', 'Surcharge'),
                     ('cess', 'Cess'), ('total_tax', 'TOTAL TAX')]:
        put(ws, r, 1, lab, b_=(key == 'total_tax'))
        put(ws, r, 2, R['new']['tax'][key], b_=(key == 'total_tax'))
        put(ws, r, 3, R['old']['tax'][key], b_=(key == 'total_tax')); r += 1
    put(ws, r, 1, 'Less: taxes paid (TDS+adv)'); put(ws, r, 2, R['new']['tds']); put(ws, r, 3, R['old']['tds']); r += 1
    put(ws, r, 1, 'BALANCE PAYABLE', b_=True); put(ws, r, 2, R['new']['balance'], b_=True); put(ws, r, 3, R['old']['balance'], b_=True); r += 1
    put(ws, r, 1, 'CHEAPER REGIME', b_=True); put(ws, r, 2, b['cheaper'].upper(), b_=True)
    for col, w in zip('ABC', [34, 16, 16]): ws.column_dimensions[col].width = w

    wb.save(path)

# -------------------------------------------------------------------------- Markdown out
def write_markdown(b, path):
    spec = b['spec']; meta = spec.get('meta', {}); R = b['results']
    L = []
    L.append(f"# India ITR Tax Computation — {meta.get('assessment_year','')}\n")
    L.append(f"**Form:** {meta.get('form','ITR-2')} · **FY:** {meta.get('financial_year','')} · "
             f"**Status:** {meta.get('residential_status','')}\n")
    L.append("> Generated by the india-itr-tax-skill. Disclosure-sensitive — re-verify in the "
             "live ITR utility and have a CA sign off. No figure here is invented; all come from your inputs.\n")
    L.append("---\n")

    # Salary
    L.append("## Salary")
    L.append("| Component | INR |")
    L.append("|---|--:|")
    s = spec.get('salary', {})
    L.append(f"| Salary u/s 17(1) | {rupees(s.get('sec17_1',0))} |")
    L.append(f"| Perquisites u/s 17(2) | {rupees(s.get('sec17_2',0))} |")
    L.append(f"| Profits in lieu 17(3) | {rupees(s.get('sec17_3',0))} |")
    L.append(f"| **Gross salary** | **{rupees(b['gross_salary'])}** |")
    L.append(f"| Less: standard deduction (new) | {rupees(R['new']['std'])} |")
    L.append(f"| **Income chargeable (new regime)** | **{rupees(R['new']['salary_income'])}** |\n")

    # OS
    L.append("## Schedule OS — Income from Other Sources")
    L.append("| Item | INR |")
    L.append("|---|--:|")
    for label, amt in b['interest'].items(): L.append(f"| Savings interest — {label} | {rupees(amt)} |")
    for label, amt in b['other_int'].items(): L.append(f"| Interest — {label} | {rupees(amt)} |")
    if b['div_inr']:
        L.append(f"| Foreign dividend (gross, Rule 115) | {rupees(b['div_inr'])} |")
    L.append(f"| **Total Schedule OS** | **{rupees(b['os_total'])}** |\n")
    if b['div_inr']:
        L.append("**Foreign dividend is taxable even if reinvested** (constructive receipt) and is reported "
                 "**gross** under Other Sources. It won't appear in AIS (foreign payer) → enter manually.\n")

    # CG
    if b['ltcg_112a_gain']:
        cg = spec.get('capital_gains', {})
        L.append("## Schedule CG → 112A (LTCG on listed equity / equity MF)")
        L.append("| Item | INR |")
        L.append("|---|--:|")
        L.append(f"| Sale value | {rupees(cg.get('ltcg_112a_sale',0))} |")
        L.append(f"| Less: cost | {rupees(cg.get('ltcg_112a_cost',0))} |")
        L.append(f"| LTCG gross | {rupees(b['ltcg_112a_gain'])} |")
        L.append(f"| Less: 112A exemption | {rupees(b['ltcg_112a_exempt'])} |")
        L.append(f"| **Taxable LTCG 112A** | **{rupees(b['ltcg_112a_taxable'])}** |")
        L.append("\n*112A LTCG is exempt up to the exemption cap but must still be REPORTED (AIS shows the redemption).*\n")

    # FA
    if b['fa_rows']:
        fe = spec['foreign_equity']
        L.append(f"## Schedule FA — Foreign Assets (Calendar Year {fe['calendar_year']})")
        L.append(f"**Entity:** {fe.get('entity','')} · **Country:** {fe.get('country','')} · "
                 f"**Held via:** {fe.get('custodian','')}\n")
        L.append("### Table A3 — Foreign Equity (per-lot rows)")
        L.append("| Date acquired | Units | Initial INR | Peak INR | Closing INR | Peak day |")
        L.append("|---|--:|--:|--:|--:|---|")
        for row in b['fa_rows']:
            L.append(f"| {row['acq_date']} | {row['units']} | {rupees(row['initial'])} | "
                     f"{rupees(row['peak'])} | {rupees(row['closing'])} | {row['peak_day']} |")
        L.append(f"| **TOTAL** | {b['fa_tot']['units']} | **{rupees(b['fa_tot']['initial'])}** | "
                 f"*not additive* | **{rupees(b['fa_tot']['closing'])}** | |\n")
        L.append(f"- Dividend **{rupees(b['div_inr'])}** entered **once** (row 1); sale proceeds 0 on all rows. "
                 "Never sum the peak column; never file a consolidated row.\n")
        pi = b['peak_info']
        L.append("### Table A2 — Foreign Custodial Account (file in addition to A3)")
        L.append(f"- Institution: {fe.get('custodian','')} · Account: {fe.get('account_number','')} · "
                 f"Status: {fe.get('owner_status','Beneficial owner')}")
        L.append(f"- **Account-level peak: {rupees(pi['account_peak'])}** (on {pi['account_peak_day']}) · "
                 f"Closing: {rupees(b['fa_tot']['closing'])} · Dividend credited: {rupees(b['div_inr'])}\n")
        L.append("### How the peak was computed")
        L.append(f"Closing = total units × close price {pi['close_price_used']} (on {pi['close_date_used']}) "
                 f"× SBI TT-buy {pi['close_fx_used']}. **Peak = full daily scan** of "
                 "`units held × intraday HIGH × SBI TT-buy` over the whole calendar year — the peak-VALUE day "
                 "is often NOT the peak-PRICE day (a weaker rupee can win).\n")
        if b['div_rows']:
            L.append("### Dividends — Rule 115 (SBI TT-buy on last day of month before payment)")
            L.append("| Pay date | Gross FX | Rule-115 date | SBI TT-buy | INR | WHT FX |")
            L.append("|---|--:|---|--:|--:|--:|")
            for d in b['div_rows']:
                L.append(f"| {d['pay_date']} | {d['gross_fx']} | {d['rule115_date']} | {d['fx']} | "
                         f"{rupees(d['inr'])} | {d['wht_fx']} |")
            L.append(f"| **TOTAL** | {b['div_fx']} | | | **{rupees(b['div_inr'])}** | |\n")

    # Tax both regimes
    L.append("## Tax computation — both regimes")
    L.append("| Line | New regime | Old regime |")
    L.append("|---|--:|--:|")
    L.append(f"| Total income | {rupees(R['new']['total_income'])} | {rupees(R['old']['total_income'])} |")
    for key, lab in [('slab','Tax at slab'),('special_tax','Tax on special-rate income'),
                     ('rebate_87a','Less: rebate 87A'),('surcharge','Surcharge'),
                     ('cess','Cess'),('total_tax','**TOTAL TAX**')]:
        L.append(f"| {lab} | {rupees(R['new']['tax'][key])} | {rupees(R['old']['tax'][key])} |")
    L.append(f"| Less: taxes paid (TDS+adv) | {rupees(R['new']['tds'])} | {rupees(R['old']['tds'])} |")
    L.append(f"| **Balance payable** | **{rupees(R['new']['balance'])}** | **{rupees(R['old']['balance'])}** |")
    L.append(f"\n**Cheaper regime: {b['cheaper'].upper()}.** "
             "Surcharge marginal relief is applied automatically at each threshold. "
             "Pay any balance via Challan 280 (minor head 300, self-assessment) before filing so the balance shows 0.\n")
    L.append("---\n*Slabs/surcharge/cess are FY2025-26 defaults; override via `regime_overrides` in the inputs for other years. "
             "Re-verify the current-year rules before filing.*")
    open(path, 'w', encoding='utf-8').write('\n'.join(L))

# ----------------------------------------------------------------------------------- CLI
if __name__ == '__main__':
    args = [a for a in sys.argv[1:]]
    if not args or args[0] in ('-h', '--help'):
        print(__doc__); sys.exit(0)
    inp = args[0]; offline = '--offline' in args
    out = 'TaxReturn'
    if '--out' in args: out = args[args.index('--out') + 1]
    build(inp, out, offline)
