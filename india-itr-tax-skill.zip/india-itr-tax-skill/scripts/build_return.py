# -*- coding: utf-8 -*-
"""
build_return.py - Generic India ITR (1/2/3/4) + Schedule FA computation engine.

Reads a single inputs.json describing salary (incl. ESOP/RSU perquisite + leave
encashment) / house property / interest / dividends / capital gains / foreign
share lots / foreign dividends / foreign capital gains / foreign tax, then:
  - recommends the correct form (ITR-1/2/3/4) from the CBDT-notified eligibility,
  - auto-fetches SBI TT-BUY rates (sahilgupta/sbi-fx-ratekeeper) and daily stock
    prices (Yahoo chart API) for the dates it needs (manual override allowed),
  - computes Schedule FA (A2/A3 + any verbatim tables), Schedule OS, Schedule CG
    (LTCG 112A, STCG 111A, LTCG 112, + foreign shares: >24m LTCG 112 @12.5% /
    <=24m STCG at slab), Salary (incl. leave encashment 10(10AA)) and House Property,
  - computes the Foreign Tax Credit (DTAA, Rule 128 lower-of) -> Schedule FSI/TR + Form 67,
  - computes tax under BOTH new and old regimes (FY2025-26 defaults; override in JSON)
    with the 15% surcharge cap on 111A/112/112A/dividend, surcharge marginal relief,
    and the 87A rebate (new-regime 60k + 12L->12.75L marginal relief),
  - emits a per-schedule + overall CONFIDENCE % (editable), and
  - writes THREE outputs:
      <out>.xlsx        - COMBINED working paper (every schedule + How-computed + both regimes),
      <out>.<FORM>.xlsx - LEAN per-form filing workbook (only the schedules that ITR form carries,
                          led by a portal-order "Filing_Guide" that maps each figure to its field),
      <out>.md          - recommended form + every figure explained + how-to-file + verify steps.

This skill does NOT produce an uploadable ITR JSON (the portal validates its own schema and rejects
external files). You enter the figures from the Filing_Guide, then DOWNLOAD the prepared JSON from
the portal and run verify_against_portal.py to cross-check it - see that script and SKILL.md.

NO personal data is embedded. Everything comes from inputs.json.

Usage:
    python build_return.py inputs.json                 # auto-fetch online
    python build_return.py inputs.json --offline        # use only rates/prices in JSON
    python build_return.py inputs.json --out MyReturn   # output basename

Requires: openpyxl. Auto-fetch additionally uses urllib (stdlib) - no extra installs.
See inputs.example.json for the schema and SKILL.md for the full method.
"""
import sys, os, json, csv, io, base64, datetime, urllib.request, ssl

# ----------------------------------------------------------------------------- utils
SCHEDULE_AL_THRESHOLD = 10000000

def log(m): print(m, flush=True)

def rupees(n):
    """Indian-format integer rupees, e.g. 7144030 -> '71,44,030'."""
    s = str(int(round(n))); neg = s.startswith('-'); s = s.lstrip('-')
    if len(s) <= 3:
        body = s
    else:
        body = s[-3:]; s = s[:-3]
        while len(s) > 2:
            body = s[-2:] + ',' + body; s = s[:-2]
        if s: body = s + ',' + body
    return ('-' if neg else '') + body

def clean(d):
    """Drop any key starting with '_' (used for inline _comment docs)."""
    return {k: v for k, v in (d or {}).items() if not str(k).startswith('_')}

def schedule_al_required(b):
    """AY2026-27 Schedule AL is mandatory when total income exceeds Rs.1 crore (Notification 46/2026, ITR-2)."""
    return b['results'][b['cheaper']]['total_income'] > SCHEDULE_AL_THRESHOLD

def http_get(url, timeout=60):
    ctx = ssl.create_default_context()
    try:
        ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE   # tolerate corp proxies
    except Exception:
        pass
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()

# ----------------------------------------------------------------------- FX (SBI TTBR)
SBI_CSV_API = ("https://api.github.com/repos/sahilgupta/sbi-fx-ratekeeper/"
               "contents/csv_files/SBI_REFERENCE_RATES_{cur}.csv")

def fetch_sbi(currency, offline, manual):
    """Return dict {date 'YYYY-MM-DD': tt_buy float}. Manual entries always win."""
    rates = {}
    if not offline:
        try:
            raw = http_get(SBI_CSV_API.format(cur=currency.upper()))
            content = json.loads(raw.decode())['content']
            text = base64.b64decode(content).decode('utf-8', 'replace')
            rd = csv.reader(io.StringIO(text)); next(rd, None)
            for row in rd:
                if len(row) < 3: continue
                d = row[0][:10]
                try: rates[d] = float(row[2])     # col index 2 = TT BUY
                except ValueError: pass
            log(f"  SBI {currency}: fetched {len(rates)} daily rates")
        except Exception as e:
            log(f"  SBI fetch failed ({e}); relying on manual rates")
    for d, v in clean(manual).items():
        rates[d] = float(v)
    return rates

def rate_on(rates, date_str):
    """Exact rate, else most recent prior published working day (up to 14 days back)."""
    d = datetime.date.fromisoformat(date_str)
    for back in range(0, 15):
        k = (d - datetime.timedelta(days=back)).isoformat()
        if k in rates: return rates[k], k
    raise SystemExit(f"No SBI rate on/before {date_str} - add it to inputs 'manual_fx'.")

def prev_month_end(date_str):
    d = datetime.date.fromisoformat(date_str)
    return (d.replace(day=1) - datetime.timedelta(days=1)).isoformat()

# ------------------------------------------------------------------- stock daily prices
YAHOO = ("https://query1.finance.yahoo.com/v8/finance/chart/{sym}"
         "?period1={p1}&period2={p2}&interval=1d")

def fetch_prices(symbol, year, unit, offline, manual_close, manual_high):
    """Return ({date: close}, {date: high}) in MAJOR currency units."""
    close, high = {}, {}
    if not offline and symbol:
        try:
            p1 = int(datetime.datetime(year, 1, 1, tzinfo=datetime.timezone.utc).timestamp())
            p2 = int(datetime.datetime(year + 1, 1, 2, tzinfo=datetime.timezone.utc).timestamp())
            raw = http_get(YAHOO.format(sym=symbol, p1=p1, p2=p2))
            res = json.loads(raw.decode())['chart']['result'][0]
            ts = res['timestamp']; q = res['indicators']['quote'][0]
            cl = q['close']; hi = q.get('high', cl)
            div = 100.0 if unit == 'pence' else 1.0
            for i, t in enumerate(ts):
                d = datetime.datetime.fromtimestamp(t, datetime.timezone.utc).date().isoformat()
                if cl[i] is not None: close[d] = cl[i] / div
                h = hi[i] if (hi and hi[i] is not None) else cl[i]
                if h is not None: high[d] = h / div
            log(f"  {symbol}: fetched {len(close)} daily prices for {year}")
        except Exception as e:
            log(f"  price fetch failed for {symbol} ({e}); relying on manual prices")
    for d, v in clean(manual_close).items(): close[d] = float(v)
    for d, v in clean(manual_high).items():  high[d] = float(v)
    # if a day has a close but no high (e.g. offline), fall back to close for the scan
    for d, v in close.items(): high.setdefault(d, v)
    return close, high

# --------------------------------------------------------------------------- Schedule FA
def compute_fa_equity(spec, rates, close, high):
    """Per-lot A3-style rows + consolidated account peak. Returns (rows, totals, peak_info)."""
    cy = spec['calendar_year']
    close_date = f"{cy}-12-31"
    cd = max([d for d in close if d <= close_date], default=None)
    if cd is None:
        raise SystemExit("No stock close price found for the calendar year - check symbol/manual prices.")
    close_px = close[cd]; close_fx, _ = rate_on(rates, close_date)

    lots = [dict(l, _d=datetime.date.fromisoformat(l['acq_date'])) for l in spec['lots']]

    def qty_on(dstr):
        dd = datetime.date.fromisoformat(dstr)
        return sum(x['units'] for x in lots if x['_d'] <= dd)

    rows = []; tot_init = tot_close = 0.0
    for l in lots:
        init_fx, init_fx_day = rate_on(rates, l['acq_date'])
        initial = l['units'] * l['cost_per_share'] * init_fx
        closing = l['units'] * close_px * close_fx
        best = 0.0; bday = None
        start = max(l['_d'], datetime.date(cy, 1, 1))
        for d in sorted(high):
            if datetime.date.fromisoformat(d) < start: continue
            if d > close_date: break
            fx, _ = rate_on(rates, d)
            v = high[d] * fx
            if v > best: best, bday = v, d
        peak = l['units'] * best
        tot_init += initial; tot_close += closing
        rows.append({'acq_date': l['acq_date'], 'units': l['units'],
                     'cost_per_share': l['cost_per_share'], 'init_fx': init_fx,
                     'initial': round(initial), 'peak': round(peak),
                     'closing': round(closing), 'peak_day': bday})

    acc_peak = 0.0; acc_day = None
    for d in sorted(high):
        dd = datetime.date.fromisoformat(d)
        if dd.year != cy: continue
        fx, _ = rate_on(rates, d)
        v = qty_on(d) * high[d] * fx
        if v > acc_peak: acc_peak, acc_day = v, d

    totals = {'initial': round(tot_init), 'closing': round(tot_close),
              'units': round(sum(x['units'] for x in lots), 5)}
    peak_info = {'account_peak': round(acc_peak), 'account_peak_day': acc_day,
                 'close_price_used': close_px, 'close_fx_used': close_fx, 'close_date_used': cd}
    return rows, totals, peak_info

def compute_dividends(spec, rates, fy_start, fy_end):
    """Rule 115: TTBR on last day of month preceding payment.
    Splits totals into CY (Schedule FA) and FY (Schedule OS) buckets by pay_date."""
    cy = spec['calendar_year']
    cy_start, cy_end = f"{cy}-01-01", f"{cy}-12-31"
    rows = []; fa_inr = fa_fx = os_inr = os_fx = os_wht = 0.0
    for dv in spec.get('dividends', []):
        ref = prev_month_end(dv['pay_date'])
        fx, used = rate_on(rates, ref)
        inr = dv['gross_fx'] * fx
        wht_inr = dv.get('wht_fx', 0) * fx                     # foreign withholding tax in INR (for FTC)
        in_cy = cy_start <= dv['pay_date'] <= cy_end
        in_fy = fy_start <= dv['pay_date'] <= fy_end
        if in_cy: fa_inr += inr; fa_fx += dv['gross_fx']
        if in_fy: os_inr += inr; os_fx += dv['gross_fx']; os_wht += wht_inr
        rows.append({'pay_date': dv['pay_date'], 'gross_fx': dv['gross_fx'],
                     'rule115_date': used, 'fx': fx, 'inr': round(inr),
                     'wht_fx': dv.get('wht_fx', 0), 'wht_inr': round(wht_inr),
                     'in_cy': in_cy, 'in_fy': in_fy})
    return rows, {'fa_inr': round(fa_inr), 'fa_fx': round(fa_fx, 2),
                  'os_inr': round(os_inr), 'os_fx': round(os_fx, 2), 'os_wht_inr': round(os_wht)}

# --------------------------------------------------------------------- House Property
def compute_hp(props, regime):
    """Return (income_for_TI, detail_rows). Applies regime set-off rules.
    self_occupied: GAV 0; interest allowed up to 2L only in OLD regime (new regime: 0).
    let_out: NAV - 30% std deduction - loan interest.
    OLD regime: net HP loss set off against other heads capped at 2,00,000.
    NEW regime: HP loss cannot be set off against other heads (contributes 0)."""
    rows = []; total = 0.0
    for p in (props or []):
        if str(p.get('type', '')).startswith('_'):
            continue
        interest = p.get('interest_on_loan', 0)
        if p.get('type') == 'self_occupied':
            allowed = 0 if regime == 'new' else min(interest, 200000)
            inc = -allowed
            rows.append({'type': 'Self-occupied', 'gav': 0, 'std30': 0,
                         'interest': allowed, 'income': round(inc)})
        else:  # let_out / deemed_let_out
            rent = p.get('annual_rent', 0); muni = p.get('municipal_taxes', 0)
            nav = max(0, rent - muni); std30 = round(0.30 * nav)
            inc = nav - std30 - interest
            rows.append({'type': 'Let-out', 'gav': rent, 'muni': muni, 'nav': nav,
                         'std30': std30, 'interest': interest, 'income': round(inc)})
        total += inc
    if regime == 'new':
        ti = total if total > 0 else 0          # loss not set off against other heads
    else:
        ti = max(total, -200000) if total < 0 else total
    return round(ti), rows

# ----------------------------------------------------------------- leave encashment 10(10AA)
def compute_leave_encashment(le):
    """Section 10(10AA) exemption. Govt employee: fully exempt. Non-govt on retirement:
    least of (a) Rs.25,00,000 lifetime cap less already-used, (b) actual, (c) 10 x avg
    monthly salary, (d) cash-equivalent of unutilised leave (<=30 days/yr). During service:
    fully taxable. Returns (exempt, taxable, detail) where 'amount' is already inside sec17_1."""
    le = clean(le)
    if not le or not le.get('amount'):
        return 0, 0, {}
    amount = le['amount']
    if le.get('govt_employee'):
        return amount, 0, {'basis': 'Government employee - fully exempt', 'amount': amount}
    if not le.get('on_retirement', True):
        return 0, amount, {'basis': 'Received during service - fully taxable', 'amount': amount}
    cap = max(0, 2500000 - le.get('lifetime_exemption_used', 0))
    avg = le.get('avg_monthly_salary', 0)
    ten_month = 10 * avg
    days = min(le.get('unutilised_leave_days', 0), 30 * le.get('completed_years', 0))
    cash_equiv = round((avg / 30.0) * days) if avg else amount
    candidates = {'actual': amount, 'lifetime_cap_25L': cap,
                  '10x_avg_monthly': ten_month, 'cash_equiv_unutilised': cash_equiv}
    exempt = min(v for v in candidates.values() if v is not None)
    return round(exempt), round(amount - exempt), {'basis': 'Non-govt on retirement - least of four',
                                                   'amount': amount, **candidates, 'exempt': round(exempt)}

# --------------------------------------------------------- foreign capital gains (US/UK shares)
def months_between(d1, d2):
    a = datetime.date.fromisoformat(d1); b = datetime.date.fromisoformat(d2)
    m = (b.year - a.year) * 12 + (b.month - a.month)
    if b.day < a.day: m -= 1
    return m

def compute_foreign_cg(items, lt_rate):
    """Foreign shares = unlisted treatment. Holding > 24 months -> LTCG u/s 112 @12.5%
    (no 1.25L exemption); <= 24 months -> STCG at SLAB (NOT 111A). Returns
    (ltcg_total, stcg_total, rows, foreign_tax_inr, taxed_gain) where taxed_gain is the
    sum of gains that actually bore foreign tax (the FTC doubly-taxed base for CG)."""
    rows = []; ltcg = stcg = ftax = taxed_gain = 0.0
    for it in (items or []):
        if str(it.get('label', '')).startswith('_'):
            continue
        gain = it.get('sale_inr', 0) - it.get('cost_inr', 0)
        hm = it.get('holding_months')
        if hm is None and it.get('acq_date') and it.get('sale_date'):
            hm = months_between(it['acq_date'], it['sale_date'])
        hm = hm or 0
        kind = 'LTCG 112' if hm > 24 else 'STCG slab'
        if kind == 'LTCG 112': ltcg += gain
        else: stcg += gain
        ft = it.get('foreign_tax_inr', 0)
        ftax += ft
        if ft > 0: taxed_gain += max(0, gain)
        rows.append({'label': it.get('label', ''), 'acq_date': it.get('acq_date', ''),
                     'sale_date': it.get('sale_date', ''), 'holding_months': hm,
                     'sale_inr': round(it.get('sale_inr', 0)), 'cost_inr': round(it.get('cost_inr', 0)),
                     'gain': round(gain), 'kind': kind, 'foreign_tax_inr': round(ft),
                     'ttbr': it.get('_ttbr'), 'ttbr_date': it.get('_ttbr_date')})
    return round(ltcg), round(stcg), rows, round(ftax), round(taxed_gain)

def resolve_foreign_cg_fx(items, offline, manual_map):
    """Rule 115(1)(f): for a foreign-share sale given in foreign currency (sale_fx/cost_fx
    [/expenses_fx]), convert sale, cost AND expenses at ONE rate - the SBI TT-buy rate on the
    LAST DAY OF THE MONTH IMMEDIATELY PRECEDING the month of sale (the single 'specified date'
    for capital gains). Sets sale_inr/cost_inr in place. Rate priority: entry 'ttbr' ->
    manual_map[ref] -> auto-fetch by entry 'currency' (default USD)."""
    cache = {}
    for it in (items or []):
        if str(it.get('label', '')).startswith('_'):
            continue
        if 'sale_inr' in it or 'cost_inr' in it:                      # already INR - leave as is
            continue
        if 'sale_fx' not in it and 'cost_fx' not in it:
            continue
        ref = prev_month_end(it['sale_date']) if it.get('sale_date') else None
        fx = it.get('ttbr')
        if fx is None and ref and manual_map and ref in manual_map:
            fx = manual_map[ref]
        if fx is None and ref:
            cur = it.get('currency', 'USD')
            if cur not in cache:
                try: cache[cur] = fetch_sbi(cur, offline, None)
                except Exception: cache[cur] = {}
            if cache[cur]:
                fx, _ = rate_on(cache[cur], ref)
        if fx is None:
            log(f"  [foreign CG] no TTBR for '{it.get('label','')}' on {ref}; "
                "set entry 'ttbr' or give 'sale_inr'/'cost_inr'. Treated as 0.")
            it['sale_inr'] = 0; it['cost_inr'] = 0; continue
        exp = it.get('expenses_fx', 0)
        it['sale_inr'] = round(it.get('sale_fx', 0) * fx)
        it['cost_inr'] = round((it.get('cost_fx', 0) + exp) * fx)
        it['_ttbr'] = round(fx, 4); it['_ttbr_date'] = ref

# ---------------------------------------------------- Business / profession income (ITR-3 / ITR-4)
def compute_business_income(business):
    """Presumptive (44AD/44ADA/44AE) or regular (ITR-3) business income.
    Returns (income, rows, kind, audit_required, notes). All amounts INR.
      - 44AD : 6% of digital turnover + 8% of cash turnover (or higher declared); limit Rs.2cr (Rs.3cr if cash<=5%)
      - 44ADA: 50% of gross receipts (or higher declared); limit Rs.50L (Rs.75L if cash<=5%)
      - 44AE : Rs.1,000/ton/month if GVW>12T else Rs.7,500/vehicle/month; part-month=full month; <=10 vehicles
      - regular: net profit from P&L (+ partner remuneration/interest + speculative/F&O) -> ITR-3"""
    b = clean(business or {})
    kind = str(b.get('type', 'none')).lower()
    rows = []; notes = []
    if kind in ('none', ''):
        return 0, [], 'none', False, []
    if kind == '44ad':
        s = clean(b.get('section_44ad', {}))
        td = s.get('turnover_digital', 0); tc = s.get('turnover_cash', 0); total_to = td + tc
        presumptive = round(0.06 * td + 0.08 * tc)
        declared = s.get('declared_income', 0)
        income = max(presumptive, declared)
        rows = [('Digital turnover (6%)', td, round(0.06 * td)),
                ('Cash turnover (8%)', tc, round(0.08 * tc)),
                ('Presumptive minimum', total_to, presumptive),
                ('Declared income (if higher)', '', declared),
                ('Business income u/s 44AD', '', income)]
        limit = 30000000 if (total_to == 0 or tc <= 0.05 * total_to) else 20000000
        if total_to > limit:
            notes.append(f"Turnover Rs.{rupees(total_to)} exceeds the 44AD limit Rs.{rupees(limit)} -> "
                         "presumptive not allowed; file ITR-3 with audited books.")
        if declared and declared < presumptive:
            notes.append("Declared income is below 6%/8% -> tax audit u/s 44AB + ITR-3 required.")
        return income, rows, '44ad', bool(declared and declared < presumptive), notes
    if kind == '44ada':
        s = clean(b.get('section_44ada', {}))
        gr = s.get('gross_receipts', 0); declared = s.get('declared_income', 0)
        presumptive = round(0.5 * gr); income = max(presumptive, declared)
        rows = [('Gross receipts', gr, ''), ('Presumptive (50%)', '', presumptive),
                ('Declared income (if higher)', '', declared), ('Business income u/s 44ADA', '', income)]
        if gr > 7500000:
            notes.append(f"Gross receipts Rs.{rupees(gr)} exceed the 44ADA limit Rs.75,00,000 -> file ITR-3.")
        if declared and declared < presumptive:
            notes.append("Declared income is below 50% -> tax audit u/s 44AB(d) + ITR-3 required.")
        return income, rows, '44ada', bool(declared and declared < presumptive), notes
    if kind == '44ae':
        s = clean(b.get('section_44ae', {}))
        total = 0; nveh = 0
        for v in s.get('vehicles', []):
            if not isinstance(v, dict):
                continue
            v = clean(v); t = v.get('tonnage_mt', 0); m = v.get('months', 0); n = v.get('count', 1)
            per = (1000 * t) if t > 12 else 7500
            inc = per * m * n; total += inc; nveh += n
            rows.append((f"{n} x {'heavy '+str(t)+'T @Rs1000/T' if t > 12 else 'light @Rs7500'} x {m} mo", '', inc))
        rows.append(('Business income u/s 44AE', '', round(total)))
        notes.append("44AE: must own <= 10 goods vehicles at any time; part of a month counts as a full month.")
        if nveh > 10:
            notes.append(f"{nveh} vehicles > 10 -> 44AE not allowed; file ITR-3.")
        return round(total), rows, '44ae', False, notes
    # regular business / profession (ITR-3)
    s = clean(b.get('regular', {}))
    np_ = s.get('net_profit', 0); partner = s.get('partner_remuneration_interest', 0)
    specu = s.get('speculative_income', 0); income = np_ + partner + specu
    rows = [('Net profit (P&L)', '', np_), ('Partner remuneration/interest', '', partner),
            ('Speculative / F&O', '', specu), ('Business income (ITR-3)', '', round(income))]
    notes.append("Regular business/profession -> ITR-3; maintain books; audit u/s 44AB if limits breached. "
                 "A business LOSS cannot be set off against salary (s.71(2A)) and needs Schedule BFLA/CFL - out of scope here.")
    return round(income), rows, 'regular', False, notes

# ---------------------------------------------------------------- ITR form selector (1/2/3/4)
def recommend_itr_form(spec, total_income, ror, foreign_assets, foreign_income, ftc_claim,
                       cg_beyond_112a_small, capital_loss):
    """Decide ITR-1/2/3/4 from the AY2026-27 CBDT-notified eligibility (Notif 45/2026).
    ITR-1/4 are resident-ROR, total income <= 50L, allow LTCG 112A <= 1.25L only.
    Returns (form, reasons, note)."""
    p = clean(spec.get('profile', {}))
    director = bool(p.get('director_in_company'))
    unlisted = bool(p.get('holds_unlisted_shares'))
    vda = bool(p.get('has_vda_income'))
    esop_deferred = bool(p.get('esop_tax_deferred'))
    tds_194n = bool(p.get('tds_194n'))
    agri = p.get('agricultural_income', 0)
    num_hp = len([x for x in (spec.get('house_property') or []) if not str(x.get('type', '')).startswith('_')])
    btype = str(clean(spec.get('business', {})).get('type', 'none')).lower()
    has_business = bool(p.get('has_business_income')) or btype in ('44ad', '44ada', '44ae', 'regular')
    presumptive = bool(p.get('presumptive_44ad_44ada_44ae')) or btype in ('44ad', '44ada', '44ae')

    # disqualifiers shared by ITR-1 and ITR-4 (push to ITR-2, or ITR-3 if business)
    block = []
    if not ror: block.append('NRI / RNOR (ITR-1/4 are for resident & ordinarily resident only)')
    if foreign_assets: block.append('holds assets/financial interest outside India (Schedule FA)')
    if foreign_income: block.append('income from outside India (foreign dividend/CG)')
    if ftc_claim: block.append('claiming foreign tax credit / DTAA relief (Form 67, Schedule FSI/TR)')
    if cg_beyond_112a_small: block.append('capital gains other than LTCG 112A <= 1.25L (STCG / 112 / foreign / 112A > 1.25L)')
    if capital_loss: block.append('capital loss to set off or carry forward')
    if director: block.append('director in a company')
    if unlisted: block.append('held unlisted equity shares during the year')
    if vda: block.append('income from virtual digital assets (crypto/NFT)')
    if esop_deferred: block.append('ESOP perquisite tax deferred (eligible start-up)')
    if tds_194n: block.append('TDS deducted u/s 194N (cash withdrawal)')
    if agri > 5000: block.append('agricultural income > Rs.5,000')
    if total_income > 5000000: block.append('total income > Rs.50 lakh')
    if num_hp > 2: block.append('more than 2 house properties')

    note = ('Old-regime opt-out: ITR-1/2 filers tick "opting out" in the ITR (no Form 10-IEA); '
            'only ITR-3/4 filers with business income file Form 10-IEA before the due date.')
    if has_business:
        if presumptive and not block:
            return 'ITR-4', ['resident, total income <= 50L, presumptive business/profession u/s 44AD/44ADA/44AE '
                             '(LTCG 112A <= 1.25L allowed)'], note + ' Use ITR-3 instead if you keep regular books, '\
                             'are a partner in a firm, or want to carry forward losses.'
        reasons = (['business/profession income not under presumptive (or partner in a firm / books / audit)']
                   if not presumptive else []) + block
        return 'ITR-3', reasons or ['business or professional income'], note
    if block:
        return 'ITR-2', block, note
    return 'ITR-1', ['resident ROR, total income <= Rs.50 lakh, only Salary + up to 2 house properties + Other '
                     'Sources + LTCG 112A <= Rs.1.25 lakh, no other capital gains and no capital losses'], note

# --------------------------------------------------------------------------------- tax
def slab_tax(ti, bands):
    t = 0.0
    for lo, hi, r in bands:
        hi = hi if hi is not None else float('inf')
        t += max(0, min(ti, hi) - lo) * r
    return t

def compute_tax(normal_income, dividend_income, special_items, regime_cfg, regime_name):
    """Slab tax + special-rate tax + surcharge (15% cap on 111A/112/112A/dividend,
    with marginal relief) + 87A rebate (new-regime 60k & 12L->12.75L marginal relief) + cess.
    normal_income INCLUDES dividend_income (dividend is taxed at slab); special_items is a
    list of {label, amount, rate, cap15}. Returns a breakdown dict."""
    bands = [(b[0], b[1], b[2]) for b in regime_cfg['slabs']]
    normal_income = max(0, normal_income)
    slab_full = slab_tax(normal_income, bands)
    slab_excl_div = slab_tax(max(0, normal_income - max(0, dividend_income)), bands)
    div_tax = max(0.0, slab_full - slab_excl_div)              # tax attributable to dividend
    special_tax = sum(s.get('taxable', s['amount']) * s['rate'] for s in special_items)
    special_amt = sum(s['amount'] for s in special_items)      # GROSS, included in total income
    total_income = normal_income + special_amt

    # ---- 87A rebate (on normal-rate tax only; special-rate tax never rebated)
    rebate = 0.0
    r87 = regime_cfg.get('rebate_87a')
    if r87:
        lim = r87['income_limit']; mx = r87['max_rebate']
        if total_income <= lim:
            rebate = min(slab_full, mx)
        elif regime_name == 'new':                            # 12L -> ~12.75L marginal relief
            rebate = max(0.0, slab_full - (total_income - lim))
    tax_before_sur = slab_full + special_tax - rebate

    # ---- surcharge: capped income (dividend + 111A/112/112A) limited to 15%
    sur_rate = 0.0; threshold = 0.0
    for lo, rate in regime_cfg['surcharge']:                  # ascending [(income_over, rate)]
        if total_income > lo: sur_rate = rate; threshold = lo
    surcharge = 0.0
    if sur_rate > 0:
        capped_rate = min(sur_rate, 0.15)
        capped_tax = div_tax + sum(s.get('taxable', s['amount']) * s['rate'] for s in special_items if s.get('cap15'))
        uncapped_tax = (slab_full - div_tax - rebate) \
                       + sum(s.get('taxable', s['amount']) * s['rate'] for s in special_items if not s.get('cap15'))
        uncapped_tax = max(0.0, uncapped_tax)
        surcharge = uncapped_tax * sur_rate + capped_tax * capped_rate
        # surcharge marginal relief at the threshold
        tax_at_thr = slab_tax(max(0, threshold - special_amt), bands) + special_tax
        ceiling = tax_at_thr + (total_income - threshold)
        if tax_before_sur + surcharge > ceiling:
            surcharge = max(0.0, ceiling - tax_before_sur)
    cess = (tax_before_sur + surcharge) * regime_cfg.get('cess', 0.04)
    total = tax_before_sur + surcharge + cess
    return {'slab': round(slab_full), 'div_tax': round(div_tax),
            'special_tax': round(special_tax), 'rebate_87a': round(rebate),
            'tax_before_surcharge': round(tax_before_sur), 'surcharge_rate': sur_rate,
            'surcharge': round(surcharge), 'cess': round(cess),
            'total_tax': round(round(total) / 10) * 10}

def interest_234b(total_tax, tds_plus_adv, months):
    """Simplified 234B estimate: 1%/month on the assessed-tax shortfall, only if
    advance/TDS paid < 90% of total tax. The live utility computes the exact figure."""
    if total_tax <= 0 or tds_plus_adv >= 0.9 * total_tax:
        return 0
    shortfall = (int((total_tax - tds_plus_adv) // 100)) * 100      # rounded down to 100
    return max(0, round(shortfall * 0.01 * max(0, months)))

# ---------------------------------------------------------------- default regime configs
def default_regimes():
    new = {  # FY2025-26 (AY2026-27) new regime u/s 115BAC(1A)
        'slabs': [(0,400000,0),(400000,800000,.05),(800000,1200000,.10),
                  (1200000,1600000,.15),(1600000,2000000,.20),(2000000,2400000,.25),
                  (2400000,None,.30)],
        'surcharge': [(0,0),(5000000,.10),(10000000,.15),(20000000,.25)],
        'cess': 0.04,
        'rebate_87a': {'income_limit': 1200000, 'max_rebate': 60000},
        'std_deduction': 75000}
    old = {  # FY2025-26 old regime
        'slabs': [(0,250000,0),(250000,500000,.05),(500000,1000000,.20),(1000000,None,.30)],
        'surcharge': [(0,0),(5000000,.10),(10000000,.15),(20000000,.25),(50000000,.37)],
        'cess': 0.04,
        'rebate_87a': {'income_limit': 500000, 'max_rebate': 12500},
        'std_deduction': 50000}
    return {'new': new, 'old': old}

# ---------------------------------------------------------------------------- orchestrate
def build(inputs_path, out_base, offline, write=True):
    spec = json.load(open(inputs_path, encoding='utf-8'))
    meta = spec.get('meta', {})
    regimes = default_regimes()
    for name in ('new', 'old'):
        ov = spec.get('regime_overrides', {}).get(name)
        if isinstance(ov, dict):
            regimes[name].update(clean(ov))

    # ---- financial-year window (for the dividend OS/FA split)
    fy = str(meta.get('financial_year', '')).strip()
    if '-' in fy:
        y0 = int(fy.split('-')[0]); fy_start, fy_end = f"{y0}-04-01", f"{y0+1}-03-31"
    else:
        fy_start, fy_end = '1900-01-01', '2999-12-31'

    # ---- foreign-equity block (Schedule FA) + dividends
    fa = spec.get('foreign_equity')
    fa_rows = []; fa_tot = {}; peak_info = {}; div_rows = []
    div = {'fa_inr':0,'os_inr':0,'fa_fx':0,'os_fx':0,'os_wht_inr':0}
    if fa:
        rates = fetch_sbi(fa['currency'], offline, fa.get('manual_fx'))
        close, high = fetch_prices(fa.get('symbol'), fa['calendar_year'],
                                   fa.get('price_unit', 'major'), offline,
                                   fa.get('manual_close'), fa.get('manual_high'))
        fa_rows, fa_tot, peak_info = compute_fa_equity(fa, rates, close, high)
        if not fy.strip() or '-' not in fy:           # derive FY from CY if meta missing
            cy = fa['calendar_year']; fy_start, fy_end = f"{cy}-04-01", f"{cy+1}-03-31"
        div_rows, div = compute_dividends(fa, rates, fy_start, fy_end)

    # ---- Schedule OS
    inc = spec.get('income', {})
    interest = clean(inc.get('savings_interest', {}))
    other_int = clean(inc.get('other_interest', {}))
    indian_div = clean(inc.get('indian_dividends', {}))
    foreign_div_os = div['os_inr']
    dividend_income = sum(indian_div.values()) + foreign_div_os     # slab income, 15% surcharge cap
    os_total = sum(interest.values()) + sum(other_int.values()) + dividend_income + inc.get('other_os', 0)

    # ---- Schedule CG
    cg = spec.get('capital_gains', {})
    ltcg_112a_gain = cg.get('ltcg_112a_sale', 0) - cg.get('ltcg_112a_cost', 0)
    ltcg_112a_exemption = cg.get('ltcg_112a_exemption', 125000)
    ltcg_112a_exempt = min(ltcg_112a_exemption, max(0, ltcg_112a_gain))
    ltcg_112a_taxable = max(0, ltcg_112a_gain - ltcg_112a_exemption)
    stcg_111a = max(0, cg.get('stcg_111a', 0))
    ltcg_112 = max(0, cg.get('ltcg_112', 0))
    ltcg_112a_gross = max(0, ltcg_112a_gain)        # full gain sits in total income; 1.25L is a nil-rate band

    # ---- foreign capital gains (US/UK shares via INDmoney/IBKR): >24m LTCG 112 @12.5%; <=24m STCG slab
    #      Rule 115(1)(f): foreign-currency lots convert sale+cost+expenses at ONE rate = SBI TT-buy on the
    #      last day of the month BEFORE the sale. (Entries already in INR are left untouched.)
    resolve_foreign_cg_fx(spec.get('foreign_capital_gains'), offline,
                          clean(spec.get('foreign_cg_manual_fx', {})))
    f_ltcg, f_stcg, fcg_rows, fcg_foreign_tax, fcg_taxed_gain = compute_foreign_cg(
        spec.get('foreign_capital_gains'), cg.get('foreign_ltcg_rate', 0.125))
    f_ltcg_tax = max(0, f_ltcg)                      # positive LTCG taxed; losses need CFL (see SKILL)
    f_stcg_slab = max(0, f_stcg)                     # STCG on foreign shares is SLAB income (not 111A)

    def special_items(cfg):
        # 'amount' = gross included in TOTAL INCOME; 'taxable' = portion actually taxed at 'rate'.
        items = [{'label': 'LTCG 112A', 'amount': ltcg_112a_gross, 'taxable': ltcg_112a_taxable,
                  'rate': cg.get('ltcg_112a_rate', 0.125), 'cap15': True}]
        if stcg_111a:
            items.append({'label': 'STCG 111A', 'amount': stcg_111a, 'taxable': stcg_111a,
                          'rate': cg.get('stcg_111a_rate', 0.20), 'cap15': True})
        if ltcg_112:
            items.append({'label': 'LTCG 112', 'amount': ltcg_112, 'taxable': ltcg_112,
                          'rate': cg.get('ltcg_112_rate', 0.125), 'cap15': True})
        if f_ltcg_tax:
            items.append({'label': 'LTCG 112 (foreign shares)', 'amount': f_ltcg_tax, 'taxable': f_ltcg_tax,
                          'rate': cg.get('foreign_ltcg_rate', 0.125), 'cap15': True})
        for s in cg.get('other_special_income', []):
            if isinstance(s, dict) and s.get('amount'):
                items.append({'label': s.get('label', 'Other special'), 'amount': s['amount'],
                              'taxable': s.get('taxable', s['amount']),
                              'rate': s.get('rate', 0.30), 'cap15': bool(s.get('cap15', False))})
        return items

    # ---- Salary (with leave encashment 10(10AA) exemption)
    sal = spec.get('salary', {})
    gross_salary = sal.get('sec17_1', 0) + sal.get('sec17_2', 0) + sal.get('sec17_3', 0)
    le_exempt, le_taxable, le_detail = compute_leave_encashment(sal.get('leave_encashment'))

    # ---- Business / profession income (ITR-3 regular, or ITR-4 presumptive 44AD/44ADA/44AE)
    biz_income, biz_rows, biz_kind, biz_audit, biz_notes = compute_business_income(spec.get('business'))
    biz_income_taxable = max(0, biz_income)        # losses need Schedule BFLA/CFL (out of scope); slab base >= 0

    # ---- Foreign Tax Credit (DTAA): doubly-taxed foreign income + foreign tax paid (Rule 128)
    foreign_tax_paid = div['os_wht_inr'] + fcg_foreign_tax \
                       + clean(spec.get('foreign_tax_credit', {})).get('other_foreign_tax_inr', 0)
    doubly_taxed_income = (div['os_inr'] if div['os_wht_inr'] else 0) + fcg_taxed_gain \
                          + clean(spec.get('foreign_tax_credit', {})).get('other_foreign_income_inr', 0)

    # ---- totals per regime
    results = {}
    for rname, rcfg in regimes.items():
        std = rcfg.get('std_deduction', 0) if gross_salary > 0 else 0
        salary_income = max(0, gross_salary - std - le_exempt)
        hp_income, hp_rows = compute_hp(spec.get('house_property'), rname)
        chvi_a = 0 if rname == 'new' else sum(
            v for v in clean(spec.get('deductions_old_regime', {})).values()
            if isinstance(v, (int, float)))
        items = special_items(rcfg)
        special_amt = sum(s['amount'] for s in items)
        normal_income = salary_income + hp_income + os_total + f_stcg_slab + biz_income_taxable - chvi_a
        total_income = round((normal_income + special_amt) / 10) * 10
        normal_rounded = total_income - special_amt
        tax = compute_tax(normal_rounded, dividend_income, items, rcfg, rname)
        # Foreign Tax Credit = lower of foreign tax paid and Indian tax on that income (Rule 128 avg-rate)
        avg_rate = (tax['total_tax'] / total_income) if total_income > 0 else 0
        ftc = round(min(foreign_tax_paid, doubly_taxed_income * avg_rate)) if foreign_tax_paid else 0
        net_tax = tax['total_tax'] - ftc
        tds = spec.get('taxes_paid', {}).get('tds_total', 0) \
              + spec.get('taxes_paid', {}).get('advance_self_asst', 0)
        balance = net_tax - tds
        months = spec.get('taxes_paid', {}).get('months_to_filing', 4)
        i234b = interest_234b(net_tax, tds, months)
        results[rname] = {'salary_income': salary_income, 'std': std, 'chvi_a': chvi_a,
                          'le_exempt': le_exempt, 'le_taxable': le_taxable,
                          'hp_income': hp_income, 'hp_rows': hp_rows, 'os_total': os_total,
                          'biz_income': biz_income_taxable,
                          'f_stcg_slab': f_stcg_slab, 'special_amt': special_amt, 'items': items,
                          'ltcg_taxable': ltcg_112a_taxable, 'total_income': total_income,
                          'tax': tax, 'ftc': ftc, 'net_tax': net_tax, 'tds': tds, 'balance': balance,
                          'interest_234b': i234b, 'pay_now': max(0, balance) + i234b}

    cheaper = 'new' if results['new']['net_tax'] <= results['old']['net_tax'] else 'old'

    # ---- ITR form recommendation (1/2/3/4) from AY2026-27 CBDT-notified eligibility (Notif 45/2026)
    p = clean(spec.get('profile', {}))
    status = str(p.get('residential_status') or meta.get('residential_status', '')).lower()
    is_nri = ('non-resident' in status) or ('non resident' in status) or status.strip() in ('nri', 'nr')
    is_rnor = ('not ordinarily' in status) or ('rnor' in status)
    ror = not (is_nri or is_rnor)
    foreign_assets = bool(fa) or any(isinstance(v, list) and len(v) > 0
                                     for v in clean(spec.get('foreign_assets_other', {})).values())
    foreign_income = bool(div['os_inr']) or bool(fcg_rows)
    cg_beyond_112a_small = bool(stcg_111a or ltcg_112 or fcg_rows) or ltcg_112a_gross > ltcg_112a_exemption
    capital_loss = bool(p.get('capital_loss_carry')) or (f_ltcg < 0) or (f_stcg < 0) or (ltcg_112a_gain < 0)
    itr_form, itr_reasons, itr_note = recommend_itr_form(
        spec, results[cheaper]['total_income'], ror, foreign_assets, foreign_income,
        foreign_tax_paid > 0, cg_beyond_112a_small, capital_loss)
    declared = str(meta.get('form', '')).replace(' ', '').upper()
    itr_rec = {'form': itr_form, 'reasons': itr_reasons, 'note': itr_note,
               'declared': meta.get('form', ''),
               'mismatch': bool(declared) and declared != itr_form.replace(' ', '').upper()}

    # ---- confidence (preparer self-assessment; editable via inputs 'confidence')
    #      Not a flat 100 by design: (a) current-year rates/limits must be re-confirmed via the
    #      annual web-search protocol in SKILL.md; (b) interest u/s 234A/B/C is date-of-payment
    #      dependent (estimate only); (c) FTC depends on Form 67 being filed in time + DTAA reading.
    conf_def = {'Salary': 100, 'House Property': 99, 'Business/Profession': 99, 'Schedule OS': 99,
                'Schedule CG (domestic)': 99, 'Foreign capital gains': 98, 'Schedule FA': 99,
                'FTC / DTAA (Form 67)': 97, 'ITR form selection': 99, 'Tax computation': 99}
    present = {'Salary': gross_salary > 0, 'House Property': bool(results['new']['hp_rows']),
               'Business/Profession': biz_kind != 'none', 'Schedule OS': os_total > 0,
               'Schedule CG (domestic)': bool(ltcg_112a_gain or stcg_111a or ltcg_112),
               'Foreign capital gains': bool(fcg_rows), 'Schedule FA': bool(fa_rows),
               'FTC / DTAA (Form 67)': foreign_tax_paid > 0, 'ITR form selection': True,
               'Tax computation': True}
    conf_in = clean(spec.get('confidence', {}))
    confidence = {k: conf_in.get(k, conf_def[k]) for k in conf_def if present.get(k)}
    overall_conf = min(confidence.values()) if confidence else 0

    bundle = {'spec': spec, 'fa_rows': fa_rows, 'fa_tot': fa_tot, 'peak_info': peak_info,
              'div_rows': div_rows, 'div': div, 'fy_window': (fy_start, fy_end),
              'interest': interest, 'other_int': other_int, 'indian_div': indian_div,
              'dividend_income': dividend_income, 'os_total': os_total,
              'ltcg_112a_gain': ltcg_112a_gain, 'ltcg_112a_exempt': ltcg_112a_exempt,
              'ltcg_112a_taxable': ltcg_112a_taxable, 'stcg_111a': stcg_111a, 'ltcg_112': ltcg_112,
              'fcg_rows': fcg_rows, 'f_ltcg': f_ltcg, 'f_stcg': f_stcg,
              'le_detail': le_detail, 'le_exempt': le_exempt, 'le_taxable': le_taxable,
              'biz_income': biz_income, 'biz_rows': biz_rows, 'biz_kind': biz_kind,
              'biz_audit': biz_audit, 'biz_notes': biz_notes,
              'foreign_tax_paid': foreign_tax_paid, 'doubly_taxed_income': doubly_taxed_income,
              'confidence': confidence, 'overall_conf': overall_conf, 'itr_rec': itr_rec,
              'gross_salary': gross_salary, 'results': results, 'cheaper': cheaper}
    if not write:
        return bundle
    write_excel(bundle, out_base + '.xlsx')
    form_slug = itr_rec['form'].replace('-', '').replace(' ', '')
    form_xlsx = f"{out_base}.{form_slug}.xlsx"
    write_form_excel(bundle, form_xlsx)
    write_markdown(bundle, out_base + '.md')
    log(f"\nDONE -> {out_base}.xlsx (combined) · {form_xlsx} (filing) · {out_base}.md")
    log(f"  Recommended form: {itr_rec['form']}"
        + (f"  (you declared {itr_rec['declared']} - MISMATCH!)" if itr_rec['mismatch'] else ""))
    log(f"  New regime net tax: Rs {rupees(results['new']['net_tax'])} | "
        f"Old regime net tax: Rs {rupees(results['old']['net_tax'])} | "
        f"cheaper: {cheaper.upper()} | overall confidence: {overall_conf}%")
    if bundle['foreign_tax_paid']:
        log(f"  FTC (DTAA) claimed [{cheaper}]: Rs {rupees(results[cheaper]['ftc'])} "
            f"-> file Form 67 BEFORE the return")
    return bundle

# ---------------------------------------------------------------------------- Excel out
INDIAN_MONEY_FMT = '#,##,##0'   # Excel renders 1500000 as 15,00,000 (lakh/crore grouping)

def _fmt_money_cols(ws, cols, start_row=2):
    """Apply Indian-grouping number format to the given 1-based columns (numeric cells only)."""
    for row in ws.iter_rows(min_row=start_row):
        for c in cols:
            if c <= len(row):
                cell = row[c - 1]
                if isinstance(cell.value, (int, float)) and not isinstance(cell.value, bool):
                    cell.number_format = INDIAN_MONEY_FMT

def _build_full_workbook(b):
    """Build the COMBINED working-paper workbook (every applicable schedule) and return it.
    write_excel() saves it as-is; write_form_excel() trims it to one ITR form."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = openpyxl.Workbook()
    hdr = Font(bold=True, color='FFFFFF'); hfill = PatternFill('solid', fgColor='305496')
    bold = Font(bold=True); wrap = Alignment(wrap_text=True, vertical='top')
    def sheet(name): return wb.create_sheet(name)
    def put(ws, r, c, v, head=False, b_=False, w=False):
        cell = ws.cell(r, c, v)
        if head: cell.font = hdr; cell.fill = hfill
        elif b_: cell.font = bold
        if w: cell.alignment = wrap
        return cell

    spec = b['spec']; meta = spec.get('meta', {}); R = b['results']; cg = spec.get('capital_gains', {})

    # ----- 0 Summary
    ws = wb.active; ws.title = '0_Summary'
    rows = [
        ['India ITR Tax Computation', ''],
        ['Assessment Year', meta.get('assessment_year', '')],
        ['Financial Year', meta.get('financial_year', '')],
        ['Recommended ITR form', b['itr_rec']['form']],
        ['Form you declared', meta.get('form', '-') + ('  <-- MISMATCH, review' if b['itr_rec']['mismatch'] else '')],
        ['Residential status', meta.get('residential_status', '')],
        ['', ''],
        ['Head (cheaper regime: %s)' % b['cheaper'].upper(), 'Amount INR'],
        ['Salary income', R[b['cheaper']]['salary_income']],
        ['House Property income', R[b['cheaper']]['hp_income']],
        ['Business/Profession income', R[b['cheaper']].get('biz_income', 0)],
        ['Income from Other Sources', b['os_total']],
        ['LTCG 112A (gross, in total income)', max(0, b['ltcg_112a_gain'])],
        ['  of which taxable @12.5%', b['ltcg_112a_taxable']],
        ['STCG 111A', b['stcg_111a']],
        ['LTCG 112', b['ltcg_112']],
        ['Foreign LTCG 112 (shares >24m)', max(0, b['f_ltcg'])],
        ['Foreign STCG (slab, shares <=24m)', max(0, b['f_stcg'])],
        ['Total income', R[b['cheaper']]['total_income']],
        ['', ''],
        ['Regime', 'Total tax INR'],
        ['New regime', R['new']['tax']['total_tax']],
        ['Old regime', R['old']['tax']['total_tax']],
        ['Cheaper regime', b['cheaper'].upper()],
        ['Less: Foreign Tax Credit (DTAA, Form 67)', R[b['cheaper']]['ftc']],
        ['Net tax after FTC', R[b['cheaper']]['net_tax']],
        ['Taxes paid (TDS + advance/SA)', R[b['cheaper']]['tds']],
        ['Balance payable', R[b['cheaper']]['balance']],
        ['Est. 234B interest', R[b['cheaper']]['interest_234b']],
        ['Pay before filing (Challan 280, SA)', R[b['cheaper']]['pay_now']],
        ['Schedule AL required?', 'YES - total income > Rs.1 crore' if schedule_al_required(b) else 'No (AY2026-27 threshold: total income > Rs.1 crore)'],
        ['', ''],
        ['OVERALL CONFIDENCE', f"{b['overall_conf']}%"],
    ]
    for i, (a, c) in enumerate(rows, 1):
        head = a.startswith('Head') or a == 'Regime'
        emph = a in ('OVERALL CONFIDENCE', 'Net tax after FTC', 'Total income')
        put(ws, i, 1, a, head=head, b_=(i == 1 or emph)); put(ws, i, 2, c, head=head, b_=emph)
    ws.column_dimensions['A'].width = 42; ws.column_dimensions['B'].width = 22

    # ----- 1 How computed (explanations)
    ws = sheet('1_How_Computed')
    put(ws, 1, 1, 'Schedule', head=True); put(ws, 1, 2, 'How the figure was computed', head=True)
    ex = [
        ('Salary', 'Gross = 17(1) basic+allowances + 17(2) perquisites (Form 12BA) + 17(3) profits in lieu. '
                   'Less standard deduction (new Rs.75,000 / old Rs.50,000). Source: Form 16 Part B + 12BA.'),
        ('House Property', 'Self-occupied: annual value 0; loan interest allowed up to Rs.2,00,000 only in the OLD '
                           'regime (NEW regime: nil). Let-out: (rent - municipal tax) - 30% std deduction - loan interest. '
                           'New regime: a HP loss cannot be set off against other heads; Old regime: set-off capped at Rs.2,00,000.'),
        ('Other Sources', 'Savings interest (AIS SFT-016) + other interest (FD/bond) + dividends + any other OS income. '
                          'Foreign dividend is taxed at slab on the GROSS amount even if reinvested (constructive receipt) '
                          'and will NOT appear in AIS - enter it manually.'),
        ('Dividend FX (Rule 115)', 'Foreign dividend INR = gross foreign-currency amount x SBI TT-buy rate on the LAST DAY '
                                   'OF THE MONTH BEFORE the payment month (prior working day if a holiday).'),
        ('Dividend CY vs FY', 'Schedule FA dividend uses CALENDAR-YEAR payments; Schedule OS dividend uses FINANCIAL-YEAR '
                              'payments. They differ only if a dividend was paid in Jan-Mar; otherwise they match.'),
        ('LTCG 112A', 'Sale value - cost of acquisition (grandfathered FMV on 31-01-2018 for pre-2018 lots). The FULL gain is '
                      'included in TOTAL INCOME; the first Rs.1,25,000 is a NIL-RATE band (not a deduction from total income) '
                      'and only the balance is taxed at 12.5%. Must be REPORTED even if fully exempt (AIS shows the redemption).'),
        ('STCG 111A', 'Listed equity / equity MF held <= 12 months, STT paid: taxed at 20% (raised from 15% w.e.f. 23-Jul-2024).'),
        ('LTCG 112', 'Long-term gains on other assets: 12.5% without indexation (post 23-Jul-2024).'),
        ('Business/Profession (ITR-3/4)', 'Presumptive: 44AD = 6% of digital turnover + 8% of cash turnover (limit Rs.2cr / Rs.3cr if '
                                          'cash <= 5%); 44ADA = 50% of professional gross receipts (limit Rs.50L / Rs.75L if cash <= 5%); '
                                          '44AE = Rs.1,000/ton/month if GVW > 12T else Rs.7,500/vehicle/month (part-month = full month, <= 10 vehicles). '
                                          'You may always declare a higher income. Regular (ITR-3) = net profit from the P&L (+ partner remuneration/'
                                          'interest + speculative/F&O). Added to normal slab income in BOTH regimes; a business loss is not netted here.'),
        ('Leave encashment 10(10AA)', 'Govt employee: fully exempt. Non-govt on retirement: exemption = LEAST of (a) Rs.25,00,000 '
                                      'lifetime cap less amount already used in earlier years (CBDT Notification 31/2023, w.e.f. 01-04-2023), '
                                      '(b) actual encashment, (c) 10 x average monthly salary (basic+DA+commission), (d) cash equivalent of '
                                      'unutilised leave (max 30 days/year x completed years). During service: fully taxable. Available in BOTH regimes.'),
        ('ESOP / RSU (two stages)', 'Stage 1 - on VESTING (RSU) or EXERCISE (ESOP): perquisite u/s 17(2)(vi) = FMV (RSU: full FMV; ESOP: FMV - '
                                    'exercise price) x shares, taxed as SALARY, TDS by employer (already in 17(2)/Form 12BA). Stage 2 - on SALE: '
                                    'capital gain = sale price - FMV-at-vest; cost of acquisition = that FMV (Section 49(2AA), prevents double tax); '
                                    'holding period counts from the VEST/EXERCISE date. Eligible-startup ESOPs can defer the perquisite tax (Schedule ESOP).'),
        ('Foreign shares CG (US/UK)', 'US/UK shares (INDmoney, Interactive Brokers, EquatePlus, etc.) are treated as UNLISTED in India. Held > 24 '
                                      'months -> LTCG u/s 112 @12.5% without indexation and with NO Rs.1.25L exemption. Held <= 24 months -> STCG at '
                                      'your SLAB rate (NOT the 20% 111A rate). Convert sale, cost and expenses to INR per Rule 115(1)(f). Report in Schedule CG (unlisted).'),
        ('FTC / DTAA (Form 67)', 'US dividend withholding is 25% with a W-8BEN (India-US DTAA Art.10), else 30%. Claim a Foreign Tax Credit u/s 90 + '
                                 'Rule 128 = LOWER of (foreign tax paid) and (Indian tax on that income at the average rate). MUST e-file Form 67 before/with '
                                 'the return (outer limit: end of the AY). Report Schedule FSI (foreign income + tax) and Schedule TR (relief).'),
        ('Confidence %', 'Each schedule carries a preparer self-assessment confidence; overall = the lowest schedule confidence (weakest link). '
                         'Override any value via the inputs "confidence" map after your own review. See the Confidence sheet.'),
        ('Annual rule refresh', 'Slabs, 87A, surcharge bands, the 15% special-income cap, 112A exemption, leave-encashment cap and DTAA rates can change '
                                'every Budget. Before filing, web-search the official incometaxindia.gov.in figures for the year and override via regime_overrides. See the markdown "Verify every year" list.'),
        ('Schedule AL', 'For AY2026-27 ITR-2, fill Schedule AL only if total income exceeds Rs.1 crore '
                        '(Notification 46/2026; older portal help may still show Rs.50 lakh). This is separate from '
                        'Schedule FA: foreign assets may need dual reporting in FA and AL when AL applies.'),
        ('Schedule FA - Initial', 'Per lot: units x cost/share (foreign currency) x SBI TT-buy on the acquisition date.'),
        ('Schedule FA - Closing', 'Total units x stock close on 31-Dec x SBI TT-buy on 31-Dec.'),
        ('Schedule FA - Peak', 'Daily scan over the whole calendar year: units held that day x intraday HIGH x SBI TT-buy '
                               'that day; take the maximum. The peak-VALUE day is usually NOT the peak-PRICE day (a weaker '
                               'rupee can win). Report per-lot A3 rows AND the account-level A2 peak. Never sum the peak column.'),
        ('Unvested RSUs', 'Excluded entirely - a contingent promise is not owned property. Report each lot only after it vests.'),
        ('Tax - slab', 'Slab tax on total income EXCLUDING special-rate income (112A/111A/112).'),
        ('Tax - 87A rebate', 'New regime: up to Rs.60,000 if total income <= Rs.12,00,000, with 12L->12.75L marginal relief; '
                             'NOT available against special-rate (112A/111A) tax. Old regime: up to Rs.12,500 if income <= Rs.5,00,000.'),
        ('Tax - surcharge', 'By total-income band, with marginal relief at each threshold. Surcharge on 111A/112/112A capital '
                            'gains AND dividend income is CAPPED at 15% even above Rs.2cr; new-regime overall cap 25%.'),
        ('Tax - cess', 'Health & education cess 4% on (tax + surcharge).'),
        ('234B/234C', 'Estimate only. 234B ~ 1%/month on the assessed-tax shortfall if TDS+advance < 90% of tax. The live ITR '
                      'utility computes the exact 234B/234C - pay the balance via Challan 280 (minor head 300) before filing.'),
    ]
    for i, (a, c) in enumerate(ex, 2):
        put(ws, i, 1, a, b_=True, w=True); put(ws, i, 2, c, w=True)
    ws.column_dimensions['A'].width = 26; ws.column_dimensions['B'].width = 110

    # ----- Salary
    ws = sheet('Salary')
    data = [['Component', 'Amount INR', 'Source'],
            ['Salary u/s 17(1)', spec.get('salary', {}).get('sec17_1', 0), 'Form 16 Part B'],
            ['Perquisites u/s 17(2) (incl. ESOP/RSU)', spec.get('salary', {}).get('sec17_2', 0), 'Form 12BA'],
            ['Profits in lieu u/s 17(3)', spec.get('salary', {}).get('sec17_3', 0), 'Form 16 Part B'],
            ['Gross salary', b['gross_salary'], '']]
    if b['le_exempt'] or b['le_taxable']:
        data.append(['Less: Leave encashment exempt 10(10AA)', b['le_exempt'], 'Least-of-four; lifetime cap Rs.25L'])
    data += [['Less: Standard deduction (new)', R['new']['std'], 'Rs.75,000 new / Rs.50,000 old'],
             ['Income chargeable - Salaries (new)', R['new']['salary_income'], '']]
    for i, row in enumerate(data, 1):
        bld = row[0].startswith('Gross') or row[0].startswith('Income')
        put(ws, i, 1, row[0], head=(i == 1), b_=bld); put(ws, i, 2, row[1], head=(i == 1))
        put(ws, i, 3, row[2], head=(i == 1))
    ws.column_dimensions['A'].width = 42; ws.column_dimensions['B'].width = 16; ws.column_dimensions['C'].width = 32

    # ----- House Property (only if provided)
    if R['new']['hp_rows']:
        ws = sheet('House_Property')
        put(ws, 1, 1, 'Property', head=True); put(ws, 1, 2, 'Income (new regime)', head=True)
        put(ws, 1, 3, 'Income (old regime)', head=True); put(ws, 1, 4, 'Note', head=True)
        for i, (nr, orow) in enumerate(zip(R['new']['hp_rows'], R['old']['hp_rows']), 2):
            note = ('Self-occupied: new regime nil; old regime interest up to 2L'
                    if nr['type'] == 'Self-occupied' else 'Let-out: NAV - 30% - interest')
            put(ws, i, 1, nr['type']); put(ws, i, 2, nr['income']); put(ws, i, 3, orow['income']); put(ws, i, 4, note, w=True)
        tr = len(R['new']['hp_rows']) + 2
        put(ws, tr, 1, 'HP income after set-off', b_=True)
        put(ws, tr, 2, R['new']['hp_income'], b_=True); put(ws, tr, 3, R['old']['hp_income'], b_=True)
        for col, w in zip('ABCD', [26, 18, 18, 52]): ws.column_dimensions[col].width = w

    # ----- Business / Profession (only if provided; ITR-3 regular or ITR-4 presumptive)
    if b['biz_kind'] != 'none':
        ws = sheet('Business')
        title = {'44ad': 'Presumptive business u/s 44AD', '44ada': 'Presumptive profession u/s 44ADA',
                 '44ae': 'Presumptive goods-carriage u/s 44AE', 'regular': 'Regular business/profession (ITR-3)'}
        put(ws, 1, 1, title.get(b['biz_kind'], 'Business income'), head=True)
        put(ws, 1, 2, 'Basis INR', head=True); put(ws, 1, 3, 'Income INR', head=True)
        r = 2
        for label, basis, inc in b['biz_rows']:
            last = label.lower().startswith('business income')
            put(ws, r, 1, label, b_=last); put(ws, r, 2, basis); put(ws, r, 3, inc, b_=last); r += 1
        put(ws, r, 1, 'Taxable business income (slab, both regimes)', b_=True)
        put(ws, r, 3, R['new'].get('biz_income', 0), b_=True); r += 2
        for note in b['biz_notes']:
            put(ws, r, 1, 'Note: ' + note, w=True); r += 1
        ws.column_dimensions['A'].width = 46; ws.column_dimensions['B'].width = 18; ws.column_dimensions['C'].width = 18

    # ----- Schedule OS
    ws = sheet('Schedule_OS')
    for c, h in enumerate(['Item', 'Amount INR', 'Source / note'], 1): put(ws, 1, c, h, head=True)
    r = 2
    for label, amt in b['interest'].items():
        put(ws, r, 1, f"Savings interest - {label}"); put(ws, r, 2, amt); put(ws, r, 3, 'AIS SFT-016'); r += 1
    for label, amt in b['other_int'].items():
        put(ws, r, 1, f"Interest - {label}"); put(ws, r, 2, amt); put(ws, r, 3, 'FD/RD/bond cert'); r += 1
    for label, amt in b['indian_div'].items():
        put(ws, r, 1, f"Indian dividend - {label}"); put(ws, r, 2, amt); put(ws, r, 3, 'AIS; surcharge cap 15%'); r += 1
    if b['div']['os_inr']:
        put(ws, r, 1, 'Foreign dividend (gross, FY)'); put(ws, r, 2, b['div']['os_inr'])
        put(ws, r, 3, 'Vouchers; Rule 115; gross even if reinvested; surcharge cap 15%'); r += 1
    if spec.get('income', {}).get('other_os', 0):
        put(ws, r, 1, 'Other OS income'); put(ws, r, 2, spec['income']['other_os']); r += 1
    put(ws, r, 1, 'TOTAL Schedule OS', b_=True); put(ws, r, 2, b['os_total'], b_=True)
    ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 16; ws.column_dimensions['C'].width = 56

    # ----- Schedule CG
    ws = sheet('Schedule_CG')
    data = [['Item', 'Amount INR', 'Rate'],
            ['LTCG 112A - sale value', cg.get('ltcg_112a_sale', 0), ''],
            ['Less: cost of acquisition', cg.get('ltcg_112a_cost', 0), ''],
            ['LTCG 112A gross', b['ltcg_112a_gain'], ''],
            ['Less: 112A exemption', b['ltcg_112a_exempt'], 'Rs.1,25,000'],
            ['Taxable LTCG 112A', b['ltcg_112a_taxable'], f"{cg.get('ltcg_112a_rate',0.125)*100:.1f}%"],
            ['STCG 111A', b['stcg_111a'], f"{cg.get('stcg_111a_rate',0.20)*100:.0f}%"],
            ['LTCG 112 (other assets)', b['ltcg_112'], f"{cg.get('ltcg_112_rate',0.125)*100:.1f}%"]]
    if b['fcg_rows']:
        data.append(['Foreign LTCG 112 (shares >24m)', max(0, b['f_ltcg']), f"{cg.get('foreign_ltcg_rate',0.125)*100:.1f}%"])
        data.append(['Foreign STCG (shares <=24m)', max(0, b['f_stcg']), 'slab'])
    for i, row in enumerate(data, 1):
        bld = row[0].startswith('Taxable') or row[0].startswith('STCG') or row[0].startswith('LTCG 112 ') or row[0].startswith('Foreign')
        put(ws, i, 1, row[0], head=(i == 1), b_=bld); put(ws, i, 2, row[1], head=(i == 1)); put(ws, i, 3, row[2], head=(i == 1))
    if b['fcg_rows']:
        r = len(data) + 2
        put(ws, r, 1, 'Foreign share sales (unlisted treatment)', b_=True); r += 1
        for c, h in enumerate(['Label', 'Acquired', 'Sold', 'Months', 'Sale INR', 'Cost INR', 'Gain INR', 'Type'], 1):
            put(ws, r, c, h, head=True)
        r += 1
        for row in b['fcg_rows']:
            for c, v in enumerate([row['label'], row['acq_date'], row['sale_date'], row['holding_months'],
                                   row['sale_inr'], row['cost_inr'], row['gain'], row['kind']], 1):
                put(ws, r, c, v)
            r += 1
    ws.column_dimensions['A'].width = 32; ws.column_dimensions['B'].width = 16; ws.column_dimensions['C'].width = 12
    for col in 'DEFGH': ws.column_dimensions[col].width = 12

    # ----- Schedule FA A3 (equity) + A2 (account) + dividends
    if b['fa_rows']:
        fe = spec['foreign_equity']
        ws = sheet('FA_A3_Equity')
        cols = ['Country (code)', 'Entity', 'Date acquired', 'Units', 'Cost/share',
                'Initial INR', 'Peak INR', 'Closing INR', 'Gross credited INR', 'Sale proceeds INR']
        for c, h in enumerate(cols, 1): put(ws, 1, c, h, head=True)
        for i, row in enumerate(b['fa_rows'], 2):
            put(ws, i, 1, fe.get('country', '')); put(ws, i, 2, fe.get('entity', ''))
            put(ws, i, 3, row['acq_date']); put(ws, i, 4, row['units']); put(ws, i, 5, row['cost_per_share'])
            put(ws, i, 6, row['initial']); put(ws, i, 7, row['peak']); put(ws, i, 8, row['closing'])
            put(ws, i, 9, b['div']['fa_inr'] if i == 2 else 0); put(ws, i, 10, 0)
        tr = len(b['fa_rows']) + 2
        put(ws, tr, 3, 'TOTAL', b_=True); put(ws, tr, 6, b['fa_tot']['initial'], b_=True)
        put(ws, tr, 7, 'do NOT sum peaks', b_=True); put(ws, tr, 8, b['fa_tot']['closing'], b_=True)
        put(ws, tr, 9, b['div']['fa_inr'], b_=True)
        for col, w in zip('ABCDEFGHIJ', [20, 16, 13, 11, 10, 12, 12, 12, 16, 14]):
            ws.column_dimensions[col].width = w

        ws = sheet('FA_A2_Account')
        a2 = [['Field', 'Value'],
              ['Country (code)', fe.get('country', '')],
              ['Financial institution', fe.get('custodian', '')],
              ['Account number', fe.get('account_number', '')],
              ['Status', fe.get('owner_status', 'Beneficial owner')],
              ['Account opening date', fe.get('account_open_date', '')],
              ['Peak balance INR (account-level)', b['peak_info']['account_peak']],
              ['  (peak day)', b['peak_info']['account_peak_day']],
              ['Closing balance INR', b['fa_tot']['closing']],
              ['Gross dividend credited INR (CY)', b['div']['fa_inr']],
              ['Sale proceeds INR', 0]]
        for i, row in enumerate(a2, 1):
            put(ws, i, 1, row[0], head=(i == 1), b_=str(row[0]).startswith('Peak')); put(ws, i, 2, row[1], head=(i == 1))
        ws.column_dimensions['A'].width = 36; ws.column_dimensions['B'].width = 44

        ws = sheet('FA_Dividends_Rule115')
        for c, h in enumerate(['Pay date', 'Gross FX', 'Rule-115 FX date', 'SBI TT-buy', 'INR', 'WHT FX', 'In CY', 'In FY'], 1):
            put(ws, 1, c, h, head=True)
        for i, d in enumerate(b['div_rows'], 2):
            put(ws, i, 1, d['pay_date']); put(ws, i, 2, d['gross_fx']); put(ws, i, 3, d['rule115_date'])
            put(ws, i, 4, d['fx']); put(ws, i, 5, d['inr']); put(ws, i, 6, d['wht_fx'])
            put(ws, i, 7, 'Y' if d['in_cy'] else ''); put(ws, i, 8, 'Y' if d['in_fy'] else '')
        tr = len(b['div_rows']) + 2
        put(ws, tr, 1, 'TOTAL (CY / FY)', b_=True); put(ws, tr, 2, b['div']['fa_fx'], b_=True)
        put(ws, tr, 5, f"{b['div']['fa_inr']} / {b['div']['os_inr']}", b_=True)
        for col, w in zip('ABCDEFGH', [12, 10, 16, 12, 12, 10, 7, 7]): ws.column_dimensions[col].width = w

    # ----- generic FA tables A1,A4,B-G provided verbatim
    for tname, trows in clean(spec.get('foreign_assets_other')).items():
        if not isinstance(trows, list) or not trows: continue
        ws = sheet(f"FA_{tname}"[:31])
        headers = list(trows[0].keys())
        for c, h in enumerate(headers, 1): put(ws, 1, c, h, head=True)
        for i, row in enumerate(trows, 2):
            for c, h in enumerate(headers, 1): put(ws, i, c, row.get(h, ''))

    # ----- Schedule AL (assets/liabilities) - mandatory if total income exceeds Rs.1 crore (AY2026-27)
    if schedule_al_required(b):
        ws = sheet('Schedule_AL')
        rows = clean(spec.get('schedule_al', {})).get('assets', [])
        put(ws, 1, 1, 'Schedule AL required because total income exceeds Rs.1 crore', b_=True)
        put(ws, 2, 1, 'Fill from asset register as at year-end; use cost / prescribed value per ITR instructions.', w=True)
        headers = ['Category', 'Item / description', 'Asset amount INR', 'Liability INR', 'Notes']
        for c, h in enumerate(headers, 1):
            put(ws, 4, c, h, head=True)
        if not rows:
            rows = [
                {'category': 'Immovable property', 'item': 'Land / building', 'asset_amount': '', 'liability': '', 'notes': 'Use cost; include related loan'},
                {'category': 'Financial assets', 'item': 'Bank deposits, shares/securities, insurance, loans/advances', 'asset_amount': '', 'liability': '', 'notes': 'Include Indian + foreign assets if applicable'},
                {'category': 'Movable assets', 'item': 'Jewellery, bullion, vehicles, yachts/boats/aircraft', 'asset_amount': '', 'liability': '', 'notes': 'Report as per ITR instructions'},
                {'category': 'Cash in hand', 'item': 'Cash balance', 'asset_amount': '', 'liability': '', 'notes': ''},
            ]
        for r, row in enumerate(rows, 5):
            put(ws, r, 1, row.get('category', ''))
            put(ws, r, 2, row.get('item', row.get('description', '')), w=True)
            put(ws, r, 3, row.get('asset_amount', row.get('amount', '')))
            put(ws, r, 4, row.get('liability', ''))
            put(ws, r, 5, row.get('notes', ''), w=True)
        for col, w in zip('ABCDE', [24, 42, 18, 16, 54]):
            ws.column_dimensions[col].width = w
        _fmt_money_cols(ws, [3, 4], start_row=5)

    # ----- Tax (both regimes)
    ws = sheet('Tax_Both_Regimes')
    put(ws, 1, 1, 'Line', head=True); put(ws, 1, 2, 'New regime', head=True); put(ws, 1, 3, 'Old regime', head=True)
    r = 2
    def line(lab, nv, ov, bld=False):
        nonlocal r
        put(ws, r, 1, lab, b_=bld); put(ws, r, 2, nv, b_=bld); put(ws, r, 3, ov, b_=bld); r += 1
    line('Salary income', R['new']['salary_income'], R['old']['salary_income'])
    line('House Property income', R['new']['hp_income'], R['old']['hp_income'])
    line('Other Sources', R['new']['os_total'], R['old']['os_total'])
    line('LTCG 112A (gross, in total income)', max(0, b['ltcg_112a_gain']), max(0, b['ltcg_112a_gain']))
    line('STCG 111A', b['stcg_111a'], b['stcg_111a'])
    line('LTCG 112', b['ltcg_112'], b['ltcg_112'])
    line('Chapter VI-A deductions', R['new']['chvi_a'], R['old']['chvi_a'])
    line('TOTAL INCOME', R['new']['total_income'], R['old']['total_income'], bld=True)
    for key, lab in [('slab', 'Tax at slab'), ('special_tax', 'Tax on special-rate income'),
                     ('rebate_87a', 'Less: rebate 87A'), ('surcharge', 'Surcharge'),
                     ('cess', 'Cess'), ('total_tax', 'TOTAL TAX')]:
        line(lab, R['new']['tax'][key], R['old']['tax'][key], bld=(key == 'total_tax'))
    if b['foreign_tax_paid']:
        line('Less: Foreign Tax Credit (Form 67)', R['new']['ftc'], R['old']['ftc'])
        line('NET TAX after FTC', R['new']['net_tax'], R['old']['net_tax'], bld=True)
    line('Less: taxes paid (TDS+adv)', R['new']['tds'], R['old']['tds'])
    line('BALANCE PAYABLE', R['new']['balance'], R['old']['balance'], bld=True)
    line('Est. 234B interest', R['new']['interest_234b'], R['old']['interest_234b'])
    line('PAY BEFORE FILING (SA)', R['new']['pay_now'], R['old']['pay_now'], bld=True)
    line('CHEAPER REGIME', b['cheaper'].upper(), '', bld=True)
    for col, w in zip('ABC', [34, 16, 16]): ws.column_dimensions[col].width = w

    # ----- Schedule FSI / TR (Foreign Tax Credit) - only if foreign tax was paid
    if b['foreign_tax_paid']:
        ws = sheet('FSI_TR_FTC')
        rows = [['Foreign Source Income & Tax Relief (Schedule FSI + TR)', ''],
                ['Country', spec.get('foreign_equity', {}).get('country', 'United States (2)')],
                ['Doubly-taxed foreign income INR', b['doubly_taxed_income']],
                ['Foreign tax paid/withheld INR', b['foreign_tax_paid']],
                ['  - from foreign dividend WHT', b['div']['os_wht_inr']],
                ['Indian avg tax rate (cheaper regime)',
                 f"{(R[b['cheaper']]['tax']['total_tax']/R[b['cheaper']]['total_income']*100):.2f}%"
                 if R[b['cheaper']]['total_income'] else '0%'],
                ['FTC allowed (lower-of, Rule 128)', R[b['cheaper']]['ftc']],
                ['', ''],
                ['Relief section', '90 (DTAA)'],
                ['Form to file BEFORE the return', 'Form 67 (Rule 128)'],
                ['Form 67 outer deadline', f"31-Mar of AY ({meta.get('assessment_year','')})"],
                ['DTAA dividend rate (W-8BEN)', 'US: 25% (Art. 10); else 30%']]
        for i, (a, c) in enumerate(rows, 1):
            put(ws, i, 1, a, head=(i == 1), b_=a.startswith('FTC') or a.startswith('Form to'))
            put(ws, i, 2, c, head=(i == 1))
        ws.column_dimensions['A'].width = 40; ws.column_dimensions['B'].width = 34

    # ----- ITR form selection (which form to file + why)
    ir = b['itr_rec']
    ws = sheet('ITR_Form')
    put(ws, 1, 1, 'ITR form selection (AY2026-27, CBDT Notif 45/2026)', head=True); put(ws, 1, 2, '', head=True)
    put(ws, 2, 1, 'Recommended form', b_=True); put(ws, 2, 2, ir['form'], b_=True)
    put(ws, 3, 1, 'Form you declared'); put(ws, 3, 2, ir.get('declared') or '-')
    put(ws, 4, 1, 'Match?'); put(ws, 4, 2, 'MISMATCH - review' if ir['mismatch'] else 'OK')
    put(ws, 6, 1, 'Reason(s)', head=True); put(ws, 6, 2, '', head=True)
    r = 7
    for reason in ir['reasons']:
        put(ws, r, 1, '- ' + reason, w=True); r += 1
    put(ws, r + 1, 1, 'Regime opt-out', b_=True); put(ws, r + 1, 2, ir['note'], w=True)
    put(ws, r + 3, 1, 'Quick rule', b_=True)
    put(ws, r + 3, 2, 'ITR-1/4: resident-ROR, total income <= Rs.50L, only LTCG 112A <= Rs.1.25L. '
                      'ITR-1 = salary/pension + up to 2 house properties + other sources. '
                      'ITR-4 = presumptive 44AD/44ADA/44AE business. ITR-2 = capital gains / foreign assets / '
                      '> Rs.50L / director / unlisted / RNOR-NRI / DTAA. ITR-3 = business/profession (non-presumptive) or F&O.', w=True)
    ws.column_dimensions['A'].width = 22; ws.column_dimensions['B'].width = 92

    # ----- Confidence (preparer self-assessment, editable)
    ws = sheet('Confidence')
    put(ws, 1, 1, 'Schedule', head=True); put(ws, 1, 2, 'Confidence %', head=True)
    put(ws, 1, 3, 'Meaning', head=True)
    i = 2
    for k, v in b['confidence'].items():
        meaning = ('>=95 ready to file · 90-94 review one input · <90 get CA sign-off')
        put(ws, i, 1, k); put(ws, i, 2, v); put(ws, i, 3, meaning if i == 2 else '', w=True); i += 1
    put(ws, i, 1, 'OVERALL (weakest link)', b_=True); put(ws, i, 2, b['overall_conf'], b_=True)
    ws.column_dimensions['A'].width = 30; ws.column_dimensions['B'].width = 14; ws.column_dimensions['C'].width = 60

    # headline sheets get Indian-grouping number format on their amount columns
    _fmt_money_cols(wb['0_Summary'], [2])
    _fmt_money_cols(wb['Tax_Both_Regimes'], [2, 3])
    return wb

def write_excel(b, path):
    """Combined working-paper workbook: every applicable schedule + How-computed + both regimes."""
    _build_full_workbook(b).save(path)

def write_form_excel(b, path):
    """Lean, form-specific workbook: only the schedules that exist on the recommended ITR form,
    led by a portal-order Filing_Guide. Drops the verbose How-computed sheet and any schedule the
    form cannot contain (e.g. ITR-1/4 never carry Schedule FA / FSI-TR)."""
    wb = _build_full_workbook(b)
    form = b['itr_rec']['form']
    drop = {'1_How_Computed'}
    if form in ('ITR-1', 'ITR-4'):
        drop |= {n for n in wb.sheetnames if n.startswith('FA_')} | {'FSI_TR_FTC'}
    if form in ('ITR-1', 'ITR-2'):
        drop.add('Business')
    for n in list(wb.sheetnames):
        if n in drop and len(wb.sheetnames) > 1:
            del wb[n]
    _add_filing_guide(wb, b)
    wb.save(path)

def _add_filing_guide(wb, b):
    """Front sheet of the per-form workbook: a portal-navigation-order checklist mapping each
    figure to the exact schedule/field you type it into, ending with the download-JSON verify step."""
    from openpyxl.styles import Alignment, Font, PatternFill
    spec = b['spec']; meta = spec.get('meta', {}); cg = spec.get('capital_gains', {})
    R = b['results'][b['cheaper']]; form = b['itr_rec']['form']
    regime = ('NEW (115BAC default - do not opt out)' if b['cheaper'] == 'new'
              else ('OLD - ITR-1/2: tick "opting out of new regime" in the form; '
                    'ITR-3/4: e-file Form 10-IEA FIRST and quote its acknowledgement number'))
    rows = [('STEP / SCHEDULE', 'What to enter on the e-filing portal', 'Value (INR)'),
            ('1. Personal Info', f'AY {meta.get("assessment_year","")} - Form {form} - PAN/Aadhaar/contact/bank (you fill)', ''),
            ('1. Filing status', f'Tax regime: {regime}', '')]
    if b['gross_salary']:
        rows.append(('2. Schedule S (Salary)', 'Gross salary = 17(1) + 17(2) + 17(3)', b['gross_salary']))
        if b['le_exempt']:
            rows.append(('   Allowances exempt u/s 10', 'Leave encashment 10(10AA) exempt', b['le_exempt']))
        rows.append(('   Deduction u/s 16(ia)', 'Standard deduction', R['std']))
        rows.append(('   = Income chargeable', 'Head: Salaries', R['salary_income']))
    for nr in R['hp_rows']:
        rows.append(('3. Schedule HP', f'{nr["type"]} - income / (loss)', nr['income']))
    if R['hp_rows']:
        rows.append(('   = HP after set-off', 'Head: House Property', R['hp_income']))
    if b['biz_kind'] != 'none':
        sec = {'44ad': 'Schedule BP - 44AD presumptive', '44ada': 'Schedule BP - 44ADA presumptive',
               '44ae': 'Schedule BP - 44AE presumptive', 'regular': 'Schedule BP - regular P&L / Balance Sheet'}
        rows.append(('4. ' + sec.get(b['biz_kind'], 'Schedule BP'), 'Presumptive / declared income', R['biz_income']))
    if b['ltcg_112a_gain'] > 0:
        rows.append(('5. Schedule 112A', 'LTCG listed equity/MF - sale value', cg.get('ltcg_112a_sale', 0)))
        rows.append(('   Schedule 112A', 'Less: cost of acquisition', cg.get('ltcg_112a_cost', 0)))
        rows.append(('   Schedule CG', 'LTCG 112A taxable (after 1.25L nil band)', b['ltcg_112a_taxable']))
    if b['stcg_111a']:
        rows.append(('5. Schedule CG', 'STCG 111A (listed, <=12m) @20%', b['stcg_111a']))
    if b['ltcg_112']:
        rows.append(('5. Schedule CG', 'LTCG 112 (other assets) @12.5%', b['ltcg_112']))
    if b['fcg_rows']:
        if b['f_ltcg'] > 0:
            rows.append(('5. Schedule CG (unlisted)', 'Foreign shares LTCG 112 (>24m) @12.5%', max(0, b['f_ltcg'])))
        if b['f_stcg'] > 0:
            rows.append(('5. Schedule CG (unlisted)', 'Foreign shares STCG (<=24m) at SLAB', max(0, b['f_stcg'])))
    si = sum(b['interest'].values()); oi = sum(b['other_int'].values())
    di = sum(b['indian_div'].values()) + b['div']['os_inr']
    if si: rows.append(('6. Schedule OS', 'Interest - savings bank', si))
    if oi: rows.append(('6. Schedule OS', 'Interest - FD/RD/bond/other', oi))
    if di: rows.append(('6. Schedule OS', 'Dividends (Indian + foreign gross)', di))
    if b['os_total']: rows.append(('   = Schedule OS total', 'Head: Other Sources', b['os_total']))
    if b['cheaper'] == 'old' and R['chvi_a']:
        rows.append(('7. Schedule VIA', 'Chapter VI-A deductions (80C / 80D / ...)', R['chvi_a']))
    if b['fa_rows']:
        rows.append(('8. Schedule FA - A2', 'Custodial a/c peak balance (calendar year)', b['peak_info']['account_peak']))
        rows.append(('   Schedule FA - A2', 'Custodial a/c closing balance', b['fa_tot']['closing']))
        rows.append(('   Schedule FA - A2', 'Gross amount credited (CY dividend)', b['div']['fa_inr']))
        rows.append(('   Schedule FA - A3', 'Foreign equity: ONE row per lot (initial/peak/closing) - never sum peaks', ''))
    if b['foreign_tax_paid']:
        rows.append(('9. Form 67 + Schedule FSI/TR', 'FILE FORM 67 BEFORE SUBMITTING - FTC claimed', R['ftc']))
    if schedule_al_required(b):
        rows.append(('9A. Schedule AL', 'MANDATORY: total income exceeds Rs.1 crore. Fill assets/liabilities from the Schedule_AL sheet / your asset register.', ''))
    rows.append(('10. Part B-TI', 'Total income (portal auto-computes; verify it matches)', R['total_income']))
    rows.append(('11. Part B-TTI', 'Total tax (incl. surcharge + 4% cess)', R['tax']['total_tax']))
    if b['foreign_tax_paid']:
        rows.append(('11. Part B-TTI', 'Less: Foreign Tax Credit (s.90)', R['ftc']))
        rows.append(('11. Part B-TTI', 'Net tax liability', R['net_tax']))
    rows.append(('11. Part B-TTI', 'Less: taxes paid (TDS + advance/SA)', R['tds']))
    rows.append(('11. Part B-TTI', 'Balance payable / (refund)', R['balance']))
    if R['interest_234b']:
        rows.append(('11. Part B-TTI', 'Est. interest 234B (utility computes the exact figure)', R['interest_234b']))
    if R['pay_now'] > 0:
        rows.append(('12. Pay before filing', 'Challan 280, minor head 300 (self-assessment tax)', R['pay_now']))
    rows.append(('13. VERIFY', 'After filling, DOWNLOAD the prepared JSON from the portal and run '
                 'scripts/verify_against_portal.py to cross-check every figure above.', ''))

    ws = wb.create_sheet('Filing_Guide')
    wb.move_sheet(ws, -wb.index(ws))
    hdr = Font(bold=True, color='FFFFFF'); hfill = PatternFill('solid', fgColor='1F6F43')
    bold = Font(bold=True); wrap = Alignment(wrap_text=True, vertical='top')
    ws.cell(1, 1, f'HOW TO FILE {form} - enter these on the portal in order').font = Font(bold=True, size=13)
    for c, h in enumerate(rows[0], 1):
        cell = ws.cell(3, c, h); cell.font = hdr; cell.fill = hfill
    for i, (a, c2, v) in enumerate(rows[1:], 4):
        ws.cell(i, 1, a).font = bold if a[:1].isdigit() else Font()
        ws.cell(i, 2, c2).alignment = wrap
        cell = ws.cell(i, 3, v)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            cell.number_format = INDIAN_MONEY_FMT; cell.font = bold
    ws.column_dimensions['A'].width = 30; ws.column_dimensions['B'].width = 66; ws.column_dimensions['C'].width = 16

# -------------------------------------------------------------------------- Markdown out
def write_markdown(b, path):
    spec = b['spec']; meta = spec.get('meta', {}); R = b['results']; cg = spec.get('capital_gains', {})
    L = []
    ir = b['itr_rec']
    L.append(f"# India ITR Tax Computation — {meta.get('assessment_year','')}\n")
    L.append(f"**Recommended form:** {ir['form']} · **FY:** {meta.get('financial_year','')} · "
             f"**Status:** {meta.get('residential_status','')}\n")
    L.append("> Generated by the india-itr-tax skill. Disclosure-sensitive — re-verify in the "
             "live ITR utility and have a CA sign off. No figure here is invented; all come from your inputs.\n")
    L.append("---\n")

    L.append(f"## Which ITR form — **{ir['form']}**")
    if ir['mismatch']:
        L.append(f"> ⚠️ You declared **{ir['declared']}** but the inputs indicate **{ir['form']}**. Review before filing.")
    L.append("Eligibility decided from the CBDT-notified AY2026-27 forms (Notification 45/2026):")
    for reason in ir['reasons']:
        L.append(f"- {reason}")
    L.append(f"\n*Regime opt-out:* {ir['note']}")
    L.append("\n| Form | Who | Key limits |")
    L.append("|---|---|---|")
    L.append("| **ITR-1 Sahaj** | Resident ROR, salary/pension + up to 2 house properties + other sources | "
             "Total income ≤ ₹50L; LTCG 112A ≤ ₹1.25L only; no other CG, no capital loss |")
    L.append("| **ITR-2** | Individual/HUF, no business income | Capital gains, foreign assets/income, > ₹50L, "
             "director, unlisted shares, RNOR/NRI, DTAA relief |")
    L.append("| **ITR-3** | Individual/HUF with business/profession (non-presumptive), F&O, partner in firm | Books/audit as applicable |")
    L.append("| **ITR-4 Sugam** | Resident with presumptive business 44AD/44ADA/44AE | Total income ≤ ₹50L; LTCG 112A ≤ ₹1.25L only |")
    L.append("\n---\n")

    L.append("## Salary")
    L.append("| Component | INR |"); L.append("|---|--:|")
    s = spec.get('salary', {})
    L.append(f"| Salary u/s 17(1) | {rupees(s.get('sec17_1',0))} |")
    L.append(f"| Perquisites u/s 17(2) (incl. ESOP/RSU) | {rupees(s.get('sec17_2',0))} |")
    L.append(f"| Profits in lieu 17(3) | {rupees(s.get('sec17_3',0))} |")
    L.append(f"| **Gross salary** | **{rupees(b['gross_salary'])}** |")
    if b['le_exempt'] or b['le_taxable']:
        L.append(f"| Less: leave encashment exempt 10(10AA) | {rupees(b['le_exempt'])} |")
    L.append(f"| Less: standard deduction (new) | {rupees(R['new']['std'])} |")
    L.append(f"| **Income chargeable (new regime)** | **{rupees(R['new']['salary_income'])}** |\n")
    if b['le_exempt'] or b['le_taxable']:
        L.append("*Leave encashment §10(10AA): non-govt exemption = least of ₹25,00,000 lifetime cap (CBDT Notif "
                 "31/2023), actual, 10× avg monthly salary, and cash-equivalent of unutilised leave (≤30 days/yr). "
                 "Govt employees fully exempt; during-service encashment fully taxable.*\n")
    if s.get('sec17_2', 0):
        L.append("*ESOP/RSU perquisite (FMV at vesting/exercise) is inside 17(2) per Form 12BA. On later sale, "
                 "the capital-gains cost = that FMV (§49(2AA)) and the holding period runs from the vest/exercise date.*\n")

    if b['biz_kind'] != 'none':
        title = {'44ad': 'Business — presumptive §44AD', '44ada': 'Profession — presumptive §44ADA',
                 '44ae': 'Goods carriage — presumptive §44AE', 'regular': 'Business / Profession (regular, ITR-3)'}
        L.append(f"## {title.get(b['biz_kind'], 'Business / Profession')}")
        L.append("| Item | Basis | Income INR |"); L.append("|---|--:|--:|")
        for label, basis, inc in b['biz_rows']:
            bb = f"{rupees(basis)}" if isinstance(basis, (int, float)) and basis else ''
            ii = f"**{rupees(inc)}**" if str(label).lower().startswith('business income') else (rupees(inc) if isinstance(inc, (int, float)) and inc != '' else '')
            L.append(f"| {label} | {bb} | {ii} |")
        L.append(f"| **Taxable business income (slab, both regimes)** | | **{rupees(R['new'].get('biz_income',0))}** |\n")
        for note in b['biz_notes']:
            L.append(f"> {note}")
        L.append("")

    if R['new']['hp_rows']:
        L.append("## House Property")
        L.append("| Property | New regime | Old regime |"); L.append("|---|--:|--:|")
        for nr, orow in zip(R['new']['hp_rows'], R['old']['hp_rows']):
            L.append(f"| {nr['type']} | {rupees(nr['income'])} | {rupees(orow['income'])} |")
        L.append(f"| **HP income after set-off** | **{rupees(R['new']['hp_income'])}** | **{rupees(R['old']['hp_income'])}** |\n")
        L.append("*Self-occupied: new regime nil; old regime allows loan interest up to ₹2,00,000. "
                 "New regime: an HP loss cannot be set off against other heads.*\n")

    L.append("## Schedule OS — Income from Other Sources")
    L.append("| Item | INR |"); L.append("|---|--:|")
    for label, amt in b['interest'].items(): L.append(f"| Savings interest — {label} | {rupees(amt)} |")
    for label, amt in b['other_int'].items(): L.append(f"| Interest — {label} | {rupees(amt)} |")
    for label, amt in b['indian_div'].items(): L.append(f"| Indian dividend — {label} | {rupees(amt)} |")
    if b['div']['os_inr']:
        L.append(f"| Foreign dividend (gross, FY, Rule 115) | {rupees(b['div']['os_inr'])} |")
    if spec.get('income', {}).get('other_os', 0):
        L.append(f"| Other OS income | {rupees(spec['income']['other_os'])} |")
    L.append(f"| **Total Schedule OS** | **{rupees(b['os_total'])}** |\n")
    if b['div']['os_inr'] or b['indian_div']:
        L.append("**Dividends** are taxed at slab; foreign dividend is taxable **gross even if reinvested** "
                 "(constructive receipt) and won't appear in AIS → enter manually. Surcharge on dividend income "
                 "is capped at 15%.\n")
    if b['div']['os_inr'] != b['div']['fa_inr'] and b['fa_rows']:
        L.append(f"> **CY vs FY dividend:** Schedule FA (calendar-year) dividend = **{rupees(b['div']['fa_inr'])}**, "
                 f"Schedule OS (financial-year) dividend = **{rupees(b['div']['os_inr'])}** — they differ because a "
                 "dividend fell in Jan–Mar. This is expected, not an error.\n")

    if b['ltcg_112a_gain'] or b['stcg_111a'] or b['ltcg_112'] or b['fcg_rows']:
        L.append("## Schedule CG — Capital Gains")
        L.append("| Item | INR | Rate |"); L.append("|---|--:|---|")
        L.append(f"| LTCG 112A — sale value | {rupees(cg.get('ltcg_112a_sale',0))} | |")
        L.append(f"| Less: cost | {rupees(cg.get('ltcg_112a_cost',0))} | |")
        L.append(f"| LTCG 112A gross | {rupees(b['ltcg_112a_gain'])} | |")
        L.append(f"| Less: 112A exemption | {rupees(b['ltcg_112a_exempt'])} | ₹1,25,000 |")
        L.append(f"| **Taxable LTCG 112A** | **{rupees(b['ltcg_112a_taxable'])}** | {cg.get('ltcg_112a_rate',0.125)*100:.1f}% |")
        if b['stcg_111a']: L.append(f"| **STCG 111A** | **{rupees(b['stcg_111a'])}** | {cg.get('stcg_111a_rate',0.20)*100:.0f}% |")
        if b['ltcg_112']:  L.append(f"| **LTCG 112** | **{rupees(b['ltcg_112'])}** | {cg.get('ltcg_112_rate',0.125)*100:.1f}% |")
        if b['fcg_rows']:
            L.append(f"| **Foreign LTCG 112 (shares >24m)** | **{rupees(max(0,b['f_ltcg']))}** | {cg.get('foreign_ltcg_rate',0.125)*100:.1f}% |")
            L.append(f"| **Foreign STCG (shares ≤24m)** | **{rupees(max(0,b['f_stcg']))}** | slab |")
        L.append("\n*112A LTCG is exempt up to ₹1,25,000 but must still be REPORTED (AIS shows the redemption). "
                 "STCG 111A is 20% (w.e.f. 23-Jul-2024). Surcharge on 111A/112/112A is capped at 15%.*\n")
        if b['fcg_rows']:
            L.append("### Foreign shares (US/UK via INDmoney, IBKR, EquatePlus) — unlisted treatment")
            L.append("| Lot | Acquired | Sold | Months | Sale INR | Cost INR | Gain INR | Type |")
            L.append("|---|---|---|--:|--:|--:|--:|---|")
            for row in b['fcg_rows']:
                L.append(f"| {row['label']} | {row['acq_date']} | {row['sale_date']} | {row['holding_months']} | "
                         f"{rupees(row['sale_inr'])} | {rupees(row['cost_inr'])} | {rupees(row['gain'])} | {row['kind']} |")
            L.append("\n*Foreign shares are **unlisted** in India: held **>24 months → LTCG §112 @12.5%** (no indexation, "
                     "**no ₹1.25L exemption**); **≤24 months → STCG at slab** (NOT the 20% §111A rate). Convert sale/cost to "
                     "INR per Rule 115(1)(f). RSU cost = FMV at vesting (§49(2AA)).*\n")

    if b['fa_rows']:
        fe = spec['foreign_equity']
        L.append(f"## Schedule FA — Foreign Assets (Calendar Year {fe['calendar_year']})")
        L.append(f"**Entity:** {fe.get('entity','')} · **Country:** {fe.get('country','')} · "
                 f"**Held via:** {fe.get('custodian','')}\n")
        L.append("### Table A3 — Foreign Equity (per-lot rows)")
        L.append("| Date acquired | Units | Initial INR | Peak INR | Closing INR | Peak day |")
        L.append("|---|--:|--:|--:|--:|---|")
        for row in b['fa_rows']:
            L.append(f"| {row['acq_date']} | {row['units']} | {rupees(row['initial'])} | "
                     f"{rupees(row['peak'])} | {rupees(row['closing'])} | {row['peak_day']} |")
        L.append(f"| **TOTAL** | {b['fa_tot']['units']} | **{rupees(b['fa_tot']['initial'])}** | "
                 f"*not additive* | **{rupees(b['fa_tot']['closing'])}** | |\n")
        L.append(f"- Dividend **{rupees(b['div']['fa_inr'])}** (calendar-year) entered **once** (row 1); sale proceeds 0. "
                 "Never sum the peak column; never file a consolidated row.\n")
        pi = b['peak_info']
        L.append("### Table A2 — Foreign Custodial Account (file in addition to A3)")
        L.append(f"- Institution: {fe.get('custodian','')} · Account: {fe.get('account_number','')} · "
                 f"Status: {fe.get('owner_status','Beneficial owner')}")
        L.append(f"- **Account-level peak: {rupees(pi['account_peak'])}** (on {pi['account_peak_day']}) · "
                 f"Closing: {rupees(b['fa_tot']['closing'])} · Dividend credited (CY): {rupees(b['div']['fa_inr'])}\n")
        L.append("### How the peak was computed")
        L.append(f"Closing = total units × close price {pi['close_price_used']} (on {pi['close_date_used']}) "
                 f"× SBI TT-buy {pi['close_fx_used']}. **Peak = full daily scan** of "
                 "`units held × intraday HIGH × SBI TT-buy` over the whole calendar year — the peak-VALUE day "
                 "is often NOT the peak-PRICE day (a weaker rupee can win).\n")
        if b['div_rows']:
            L.append("### Dividends — Rule 115 (SBI TT-buy on last day of month before payment)")
            L.append("| Pay date | Gross FX | Rule-115 date | SBI TT-buy | INR | WHT FX | CY | FY |")
            L.append("|---|--:|---|--:|--:|--:|:-:|:-:|")
            for d in b['div_rows']:
                L.append(f"| {d['pay_date']} | {d['gross_fx']} | {d['rule115_date']} | {d['fx']} | "
                         f"{rupees(d['inr'])} | {d['wht_fx']} | {'Y' if d['in_cy'] else ''} | {'Y' if d['in_fy'] else ''} |")
            L.append(f"| **TOTAL (CY/FY)** | {b['div']['fa_fx']} | | | **{rupees(b['div']['fa_inr'])} / {rupees(b['div']['os_inr'])}** | | | |\n")

    L.append("## Tax computation — both regimes")
    L.append("| Line | New regime | Old regime |"); L.append("|---|--:|--:|")
    L.append(f"| Total income | {rupees(R['new']['total_income'])} | {rupees(R['old']['total_income'])} |")
    for key, lab in [('slab','Tax at slab'),('special_tax','Tax on special-rate income'),
                     ('rebate_87a','Less: rebate 87A'),('surcharge','Surcharge'),
                     ('cess','Cess'),('total_tax','**TOTAL TAX**')]:
        L.append(f"| {lab} | {rupees(R['new']['tax'][key])} | {rupees(R['old']['tax'][key])} |")
    if b['foreign_tax_paid']:
        L.append(f"| Less: Foreign Tax Credit (Form 67) | {rupees(R['new']['ftc'])} | {rupees(R['old']['ftc'])} |")
        L.append(f"| **Net tax after FTC** | **{rupees(R['new']['net_tax'])}** | **{rupees(R['old']['net_tax'])}** |")
    L.append(f"| Less: taxes paid (TDS+adv) | {rupees(R['new']['tds'])} | {rupees(R['old']['tds'])} |")
    L.append(f"| **Balance payable** | **{rupees(R['new']['balance'])}** | **{rupees(R['old']['balance'])}** |")
    L.append(f"| Est. 234B interest | {rupees(R['new']['interest_234b'])} | {rupees(R['old']['interest_234b'])} |")
    L.append(f"| **Pay before filing (SA)** | **{rupees(R['new']['pay_now'])}** | **{rupees(R['old']['pay_now'])}** |")
    L.append(f"\n**Cheaper regime: {b['cheaper'].upper()}.** "
             "Surcharge marginal relief is applied automatically at each threshold; surcharge on "
             "111A/112/112A capital gains and dividends is capped at 15%. 87A rebate excludes special-rate "
             "income (new-regime 60k with 12L→12.75L marginal relief). "
             "Pay any balance via Challan 280 (minor head 300, self-assessment) before filing.\n")

    if b['foreign_tax_paid']:
        L.append("## Foreign Tax Credit (DTAA) — Schedule FSI + TR + Form 67")
        L.append("| Item | INR |"); L.append("|---|--:|")
        L.append(f"| Doubly-taxed foreign income | {rupees(b['doubly_taxed_income'])} |")
        L.append(f"| Foreign tax paid/withheld | {rupees(b['foreign_tax_paid'])} |")
        L.append(f"| — of which foreign dividend WHT | {rupees(b['div']['os_wht_inr'])} |")
        L.append(f"| **FTC allowed ({b['cheaper']} regime, Rule 128 lower-of)** | **{rupees(R[b['cheaper']]['ftc'])}** |\n")
        L.append("**How FTC works:** US dividends are withheld at **25%** with a W-8BEN (India–US DTAA Art. 10; "
                 "30% without). You include the **gross** dividend in Indian income, then claim a credit u/s 90 + "
                 "**Rule 128** = the **lower of** the foreign tax paid and the Indian tax on that income (average-rate "
                 "method). You **must e-file Form 67 before/with the return** (outer limit: end of the AY) and report "
                 "**Schedule FSI** (foreign income + tax) and **Schedule TR** (relief). Convert the foreign tax to INR "
                 "with the SBI TT-buy rate on the last day of the month before payment (Rule 128).\n")

    if b['confidence']:
        L.append("## Confidence (preparer self-assessment)")
        L.append("| Schedule | Confidence |"); L.append("|---|--:|")
        for k, v in b['confidence'].items():
            L.append(f"| {k} | {v}% |")
        L.append(f"| **Overall (weakest link)** | **{b['overall_conf']}%** |\n")
        L.append("*≥95% = ready to file · 90–94% = re-check the flagged input · <90% = get a CA sign-off. "
                 "Override any value via the `confidence` map in your inputs after your own review.*\n")
        L.append("> It is intentionally **not a flat 100%**: the residual reflects three things the engine "
                 "**cannot** know in advance — (1) whether the **current-year** rates/limits have changed "
                 "(run the annual web-search protocol below), (2) the exact **interest u/s 234A/B/C**, which "
                 "depends on your actual payment dates, and (3) for FTC, that **Form 67 is filed in time** and "
                 "the DTAA article is read correctly. Close those three and every applicable schedule is at its stated %.\n")

    form_slug = ir['form'].replace('-', '').replace(' ', '')
    regime_line = ('Keep the **New regime** (115BAC default — do not opt out).' if b['cheaper'] == 'new'
                   else 'Choose the **Old regime** — ITR-1/2: tick "opting out of new regime" in the form; '
                        'ITR-3/4: e-file **Form 10-IEA** first and quote its acknowledgement number.')
    L.append("## How to file this return & verify it (no JSON upload)")
    L.append("**This skill does not generate an uploadable ITR JSON** — the e-filing portal validates "
             "its own schema and will not accept an external file. File by entering the figures, then "
             "verify what the portal computed:\n")
    L.append(f"1. Open the per-form workbook **`<out>.{form_slug}.xlsx` → `Filing_Guide`** sheet and type "
             "each value into the matching portal schedule (it is listed in portal-navigation order).")
    L.append(f"2. {regime_line}")
    step = 3
    if b['foreign_tax_paid']:
        L.append(f"{step}. **File Form 67 before you submit** the return (Rule 128) to claim the Foreign Tax Credit.")
        step += 1
    if schedule_al_required(b):
        L.append(f"{step}. **Fill Schedule AL** — AY2026-27 ITR-2 requires it because total income exceeds ₹1 crore.")
        step += 1
    L.append(f"{step}. Pay any balance via **Challan 280** (minor head 300, self-assessment) before filing.")
    step += 1
    L.append(f"{step}. At the portal's final / pre-submit stage choose **Download JSON** "
             "(the prepared return), then cross-check it against this working paper:")
    L.append("```")
    L.append("python scripts/verify_against_portal.py --portal <downloaded>.json --inputs inputs.json --offline")
    L.append("```")
    L.append("The verifier reads only the computed totals (`PartB-TI` / `PartB_TTI`) — **never your "
             "name / PAN / address / bank** — and prints a MATCH/DIFF table. Reconcile every DIFF "
             "before you submit.\n")

    fy = meta.get('financial_year', '') or 'the filing FY'
    L.append("## Verify every year before filing (official sources)")
    L.append(f"The figures below are **{fy} defaults**. Each Budget can change them — web-search the official "
             "number for your year and override via `regime_overrides` / input fields:")
    L.append("- **Slabs, 87A rebate, standard deduction, surcharge bands** — incometaxindia.gov.in → Finance Act / "
             "Circular for the year; also the e-filing portal tax calculator.")
    L.append("- **15% surcharge cap on 111A/112/112A + dividends; new-regime 25% overall cap** — Finance Act proviso.")
    L.append("- **112A exemption (₹1,25,000) and 12.5% rate; 111A 20%; 112 12.5%** — incometaxindia.gov.in "
             "\"income from capital gains\".")
    L.append("- **Leave encashment §10(10AA) cap (₹25,00,000)** — CBDT Notification 31/2023.")
    L.append("- **Foreign-share holding period (24m) & §112 12.5%; STCG at slab** — Finance (No.2) Act 2024.")
    L.append("- **US DTAA dividend rate (25%) + FTC Form 67 / Rule 128 deadline** — India–US DTAA Art. 10/25; "
             "Rule 128(9) (CBDT Notif 100/2022).")
    L.append("- **Schedule AL threshold** — AY2026-27 ITR-2 notified form (Notification 46/2026) says "
             "**total income > ₹1 crore**; older portal help/manuals may still show ₹50L, so verify the notified form / schema for your AY.")
    L.append("- **Which ITR form (1/2/3/4) + eligibility (₹50L limit, 2-house-property, LTCG-112A-in-ITR-1)** — the "
             "CBDT ITR-form notifications for the AY (AY2026-27 includes Notification 45/2026 for ITR-1/4 "
             "and Notification 46/2026 for ITR-2); the e-filing portal \"which ITR is applicable\" helper.\n")

    L.append("---\n*Slabs/surcharge/cess/87A are FY2025-26 defaults; override via `regime_overrides` for other years. "
             "234B/234C shown are estimates — the live utility computes the exact interest. Re-verify the current-year rules before filing.*")
    open(path, 'w', encoding='utf-8').write('\n'.join(L))

# ----------------------------------------------------------------------------------- CLI
if __name__ == '__main__':
    args = [a for a in sys.argv[1:]]
    if not args or args[0] in ('-h', '--help'):
        print(__doc__); sys.exit(0)
    inp = args[0]; offline = '--offline' in args
    out = 'TaxReturn'
    if '--out' in args: out = args[args.index('--out') + 1]
    build(inp, out, offline)
