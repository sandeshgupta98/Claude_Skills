# -*- coding: utf-8 -*-
"""
verify_against_portal.py - cross-check the engine's figures against the JSON you DOWNLOAD
from the income-tax e-filing portal after you have filled the ITR (final / pre-submit stage).

This skill deliberately does NOT generate an uploadable ITR JSON - the portal validates its own
schema and will not accept an arbitrary file. The correct loop is:

  1. Run build_return.py -> read MyReturn.<FORM>.xlsx "Filing_Guide" -> type the figures into the portal.
  2. At the final stage on the portal: "Download JSON" (the prepared return).
  3. Run THIS script to confirm the portal's computed figures match the engine, line by line.

It reads ONLY the numeric computation leaves it needs (PartB-TI / PartB-TTI totals). It never reads
or writes your name, PAN, Aadhaar, address, bank or any PersonalInfo - the report is PII-free.

Usage:
    python verify_against_portal.py --portal portal_download.json --inputs inputs.json [--offline]
    python verify_against_portal.py --portal portal_download.json              # portal figures only
    python verify_against_portal.py --portal portal_download.json --out VerifyReport

Requires: openpyxl (only if you keep the .xlsx output). Pure stdlib otherwise.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_return as engine  # noqa: E402


# --------------------------------------------------------------------------- portal JSON parsing
def load_form_node(portal):
    """Return (form_label, node) for the single ITR1/2/3/4 block, tolerant of wrappers."""
    root = portal.get('ITR', portal) if isinstance(portal, dict) else {}
    for k in ('ITR1', 'ITR2', 'ITR3', 'ITR4'):
        if isinstance(root, dict) and k in root:
            return 'ITR-' + k[-1], root[k]
    if isinstance(root, dict):
        for k, v in root.items():
            if isinstance(v, dict):
                return k, v
    return '?', root


def flatten(o, p='', out=None):
    """Flatten to {dotted.path: scalar}. Lists indexed as name[i]."""
    out = {} if out is None else out
    if isinstance(o, dict):
        for k, v in o.items():
            flatten(v, f'{p}.{k}' if p else k, out)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            flatten(v, f'{p}[{i}]', out)
    else:
        out[p] = o
    return out


def _last_seg(path):
    return path.split('.')[-1].split('[')[0]


def find_num(flat, candidates, must_contain=None):
    """First numeric leaf whose LAST path segment equals a candidate (in given priority order)
    and whose path contains `must_contain` (if set). Returns (value, path) or (None, None)."""
    for cand in candidates:
        for path, val in flat.items():
            if not isinstance(val, (int, float)) or isinstance(val, bool):
                continue
            if _last_seg(path).lower() == cand.lower():
                if must_contain and must_contain.lower() not in path.lower():
                    continue
                return float(val), path
    return None, None


# Each metric: (key, label, [portal candidates], must_contain, sign)
PORTAL_METRICS = [
    ('salary',     'Salary income (head)',          ['Salaries'],                    'PartB-TI', 1),
    ('hp',         'House Property income (head)',   ['IncomeFromHP'],                'PartB-TI', 1),
    ('business',   'Business/Profession income',    ['ProfBusinessGain', 'IncomeFromBusinessProf',
                                                     'TotalIncomeOfBP'],             None,       1),
    ('cg',         'Capital Gains (head total)',    ['TotalCapGains'],               'PartB-TI', 1),
    ('os',         'Other Sources (head total)',    ['TotIncFromOS'],                'PartB-TI', 1),
    ('gti',        'Gross Total Income',            ['GrossTotalIncome'],            'PartB-TI', 1),
    ('chvia',      'Chapter VI-A deductions',       ['DeductionsUnderScheduleVIA'],  'PartB-TI', 1),
    ('ti',         'Total Income',                  ['TotalIncome'],                 'PartB-TI', 1),
    ('tax_ti',     'Tax on total income (pre-87A)', ['TaxPayableOnTotInc'],          'PartB_TTI', 1),
    ('rebate',     'Rebate u/s 87A',                ['Rebate87A'],                   'PartB_TTI', 1),
    ('surcharge',  'Surcharge',                     ['TotalSurcharge', 'Surcharge'], 'PartB_TTI', 1),
    ('cess',       'Health & education cess',       ['EducationCess', 'HealthEduCess'], 'PartB_TTI', 1),
    ('gross_tax',  'Gross tax liability',           ['GrossTaxLiability'],           'PartB_TTI', 1),
    ('net_tax',    'Net tax liability (post-FTC)',  ['NetTaxLiability'],             'PartB_TTI', 1),
    ('taxes_paid', 'Taxes paid (TDS+adv+SA+TCS)',   ['TotalTaxesPaid'],              'PartB_TTI', 1),
    ('bal',        'Balance tax payable',           ['BalTaxPayable'],               'PartB_TTI', 1),
    ('refund',     'Refund due',                    ['RefundDue'],                   'PartB_TTI', 1),
]


def extract_portal(node):
    flat = flatten(node)
    out = {}
    for key, _label, cands, mc, _sign in PORTAL_METRICS:
        val, path = find_num(flat, cands, mc)
        out[key] = (val, path)
    return out


# --------------------------------------------------------------------------- engine figures
def engine_metrics(bundle, regime):
    R = bundle['results'][regime]
    cg_total = (max(0, bundle['ltcg_112a_gain']) + bundle['stcg_111a'] + bundle['ltcg_112']
                + max(0, bundle['f_ltcg']) + max(0, bundle['f_stcg']))
    gti = R['salary_income'] + R['hp_income'] + bundle['os_total'] + cg_total + R['biz_income']
    tax = R['tax']
    return {
        'salary': R['salary_income'], 'hp': R['hp_income'], 'business': R['biz_income'],
        'cg': cg_total, 'os': bundle['os_total'], 'gti': gti, 'chvia': R['chvi_a'],
        'ti': R['total_income'],
        'tax_ti': tax['slab'] + tax['special_tax'], 'rebate': tax['rebate_87a'],
        'surcharge': tax['surcharge'], 'cess': tax['cess'], 'gross_tax': tax['total_tax'],
        'net_tax': R['net_tax'], 'taxes_paid': R['tds'],
        'bal': max(0, R['balance']), 'refund': max(0, -R['balance']),
    }


def pick_regime(bundle, portal):
    """Match the regime the user actually filed: engine regime whose Total Income is closest to
    the portal's Total Income. Falls back to the cheaper regime if the portal TI is missing."""
    pti = portal.get('ti', (None, None))[0]
    if pti is None:
        return bundle['cheaper']
    best, bestd = bundle['cheaper'], None
    for r in ('new', 'old'):
        d = abs(bundle['results'][r]['total_income'] - pti)
        if bestd is None or d < bestd:
            best, bestd = r, d
    return best


# --------------------------------------------------------------------------- compare + report
def compare(bundle, portal, regime, tol=1.0):
    eng = engine_metrics(bundle, regime) if bundle else None
    rows = []
    for key, label, _c, _mc, _s in PORTAL_METRICS:
        pval, ppath = portal[key]
        eval_ = eng[key] if eng else None
        if pval is None and (eval_ in (None, 0) or eval_ is None):
            continue  # metric irrelevant to this return
        if eval_ is None:
            status, delta = 'portal-only', None
        elif pval is None:
            status, delta = 'NOT IN JSON', None
        else:
            delta = round(eval_ - pval)
            status = 'MATCH' if abs(delta) <= tol else 'DIFF -> REVIEW'
        rows.append({'label': label, 'engine': eval_, 'portal': pval,
                     'delta': delta, 'status': status, 'path': ppath or ''})
    return rows


def write_md(rows, form, regime, ay, path, show_paths=False):
    head = '| Figure | Engine (INR) | Portal (INR) | Delta | Status |' + (' Portal JSON path |' if show_paths else '')
    sep = '|---|--:|--:|--:|---|' + ('---|' if show_paths else '')
    L = [f'# Verify against portal JSON - {form}',
         f'**AY:** {ay or "-"} · **Regime matched:** {(regime or "-").upper()} · '
         '**Contains NO PII** (figures + JSON paths only).\n', head, sep]
    diffs = 0
    for r in rows:
        e = engine.rupees(r['engine']) if isinstance(r['engine'], (int, float)) else '-'
        p = engine.rupees(r['portal']) if isinstance(r['portal'], (int, float)) else '-'
        d = engine.rupees(r['delta']) if isinstance(r['delta'], (int, float)) else '-'
        if r['status'].startswith('DIFF'):
            diffs += 1
        line = f"| {r['label']} | {e} | {p} | {d} | {r['status']} |"
        if show_paths:
            line += f" `{r['path']}` |"
        L.append(line)
    L.append('')
    L.append(f"**Result: {'ALL MATCH' if diffs == 0 else str(diffs) + ' DIFFERENCE(S) - REVIEW'}.** "
             "A DIFF usually means a figure was typed differently on the portal, the wrong regime/"
             "form was selected, or the engine inputs need the current-year rule. Reconcile each "
             "DIFF before submitting.\n")
    L.append('> Mapping note: figures are read from the portal JSON computation leaves '
             '(`PartB-TI.*`, `PartB_TTI.*`); the `.xlsx` always lists the matched path, and `--show-paths` '
             'adds it here too. No PersonalInfo (name/PAN/address/bank) is ever read.')
    open(path, 'w', encoding='utf-8').write('\n'.join(L))


def write_xlsx(rows, form, regime, ay, path):
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill
    except Exception:
        return False
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = 'Verify'
    hdr = Font(bold=True, color='FFFFFF'); hfill = PatternFill('solid', fgColor='305496')
    ws.cell(1, 1, f'Verify {form} vs portal JSON  (AY {ay or "-"}, regime {(regime or "-").upper()}) - PII-free').font = Font(bold=True, size=12)
    cols = ['Figure', 'Engine (INR)', 'Portal (INR)', 'Delta', 'Status', 'Portal JSON path']
    for c, h in enumerate(cols, 1):
        cell = ws.cell(3, c, h); cell.font = hdr; cell.fill = hfill
    for i, r in enumerate(rows, 4):
        ws.cell(i, 1, r['label'])
        for c, k in ((2, 'engine'), (3, 'portal'), (4, 'delta')):
            cell = ws.cell(i, c, r[k] if isinstance(r[k], (int, float)) else '-')
            if isinstance(r[k], (int, float)):
                cell.number_format = engine.INDIAN_MONEY_FMT
        s = ws.cell(i, 5, r['status'])
        if r['status'].startswith('DIFF'):
            s.font = Font(bold=True, color='C00000')
        ws.cell(i, 6, r['path'])
    for col, w in zip('ABCDEF', [30, 16, 16, 12, 16, 60]):
        ws.column_dimensions[col].width = w
    wb.save(path); return True


def verify(portal_path, inputs_path=None, offline=False):
    portal = json.load(open(portal_path, encoding='utf-8'))
    form, node = load_form_node(portal)
    pmetrics = extract_portal(node)
    bundle = engine.build(inputs_path, 'unused', offline, write=False) if inputs_path else None
    regime = pick_regime(bundle, pmetrics) if bundle else None
    rows = compare(bundle, pmetrics, regime)
    ay = ''
    if inputs_path:
        ay = (json.load(open(inputs_path, encoding='utf-8')).get('meta', {}).get('assessment_year', ''))
    return rows, form, regime, ay


# --------------------------------------------------------------------------- CLI
if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or '-h' in a or '--help' in a:
        print(__doc__); sys.exit(0)
    portal_path = a[a.index('--portal') + 1] if '--portal' in a else a[0]
    inputs_path = a[a.index('--inputs') + 1] if '--inputs' in a else None
    out = a[a.index('--out') + 1] if '--out' in a else 'VerifyReport'
    offline = '--offline' in a
    rows, form, regime, ay = verify(portal_path, inputs_path, offline)
    write_md(rows, form, regime, ay, out + '.md', show_paths='--show-paths' in a)
    write_xlsx(rows, form, regime, ay, out + '.xlsx')
    ndiff = sum(1 for r in rows if r['status'].startswith('DIFF'))
    nmiss = sum(1 for r in rows if r['status'] == 'NOT IN JSON')
    print(f'\nVerified {form} ({(regime or "portal-only").upper()}): {len(rows)} figures, '
          f'{ndiff} DIFF, {nmiss} not-in-JSON -> {out}.md / {out}.xlsx')
    for r in rows:
        if r['status'] != 'MATCH':
            e = engine.rupees(r['engine']) if isinstance(r['engine'], (int, float)) else '-'
            p = engine.rupees(r['portal']) if isinstance(r['portal'], (int, float)) else '-'
            print(f"  [{r['status']:>12}] {r['label']:<32} engine {e:>14}  portal {p:>14}")
    sys.exit(1 if ndiff else 0)
